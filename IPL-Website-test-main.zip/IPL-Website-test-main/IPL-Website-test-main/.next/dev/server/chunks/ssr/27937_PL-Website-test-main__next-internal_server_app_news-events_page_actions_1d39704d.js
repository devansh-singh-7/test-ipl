module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/news-events/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=27937_PL-Website-test-main__next-internal_server_app_news-events_page_actions_1d39704d.js.map