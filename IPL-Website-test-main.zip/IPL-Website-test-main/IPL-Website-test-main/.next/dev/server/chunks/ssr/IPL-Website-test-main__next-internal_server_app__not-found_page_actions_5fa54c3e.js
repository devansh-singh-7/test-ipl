module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=IPL-Website-test-main__next-internal_server_app__not-found_page_actions_5fa54c3e.js.map