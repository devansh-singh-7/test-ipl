module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/our-team/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=IPL-Website-test-main__next-internal_server_app_our-team_page_actions_ab21660a.js.map