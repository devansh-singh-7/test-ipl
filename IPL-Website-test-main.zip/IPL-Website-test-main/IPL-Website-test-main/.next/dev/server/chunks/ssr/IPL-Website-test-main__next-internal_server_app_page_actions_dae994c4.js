module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=IPL-Website-test-main__next-internal_server_app_page_actions_dae994c4.js.map