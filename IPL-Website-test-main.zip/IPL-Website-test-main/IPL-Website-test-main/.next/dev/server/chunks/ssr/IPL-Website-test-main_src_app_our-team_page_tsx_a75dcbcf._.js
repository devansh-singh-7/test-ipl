module.exports = [
"[project]/IPL-Website-test-main/src/app/our-team/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OurTeam
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/shield.js [app-ssr] (ecmascript) <export default as Shield>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$linkedin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Linkedin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/linkedin.js [app-ssr] (ecmascript) <export default as Linkedin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/mail.js [app-ssr] (ecmascript) <export default as Mail>");
'use client';
;
;
;
;
const team = [
    {
        title: 'Board of Trustees',
        description: 'Governance & Oversight',
        members: [
            {
                name: 'Member Name 1',
                role: 'Trustee',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Trustee1',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 2',
                role: 'Trustee',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Trustee2',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 3',
                role: 'Trustee',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Trustee3',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 4',
                role: 'Trustee',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Trustee4',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 5',
                role: 'Trustee',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Trustee5',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 6',
                role: 'Trustee',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Trustee6',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 7',
                role: 'Trustee',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Trustee7',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'President',
        description: 'Leadership',
        members: [
            {
                name: 'KARUN. M',
                role: 'FOUNDER - PRESIDENT, TRUSTEE.',
                img: '/Images/_Founder_President_Trustee-2.png',
                email: 'iplmumbai12395@gmail.com',
                phone: '+91-9892035187',
                linkedin: '',
                link: '/about/ipl-presidents-blog'
            }
        ]
    },
    {
        title: 'General Secretary',
        description: 'Administration',
        members: [
            {
                name: 'Member Name',
                role: 'General Secretary',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=GS',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'Treasurer',
        description: 'Financial Management',
        members: [
            {
                name: 'Member Name',
                role: 'Treasurer',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Treasurer',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'Vice Presidents',
        description: 'Supporting Leadership',
        members: [
            {
                name: 'Member Name 1',
                role: 'Vice President',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=VP1',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 2',
                role: 'Vice President',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=VP2',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'Joint Secretaries',
        description: 'Administrative Support',
        members: [
            {
                name: 'Member Name 1',
                role: 'Joint Secretary',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=JS1',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 2',
                role: 'Joint Secretary',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=JS2',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'Committee Members',
        description: 'Strategic Planning & Execution',
        members: [
            {
                name: 'Bhaskar',
                role: 'Committee Member',
                img: '/Images/bhaskar.jpg',
                email: 'friendselectronics75@gmail.com',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 2',
                role: 'Committee Member',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=CM2',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 3',
                role: 'Committee Member',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=CM3',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 4',
                role: 'Committee Member',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=CM4',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 5',
                role: 'Committee Member',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=CM5',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 6',
                role: 'Committee Member',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=CM6',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 7',
                role: 'Committee Member',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=CM7',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'Coordinators',
        description: 'Regional Coordination',
        members: [
            {
                name: 'Member Name 1',
                role: 'Coordinator - New Delhi',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Coord1',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 2',
                role: 'Coordinator - Pudokotai',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Coord2',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 3',
                role: 'Depute Coordinator - Krishnagiri',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Coord3',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'Organisers',
        description: 'Event Organisation & Management',
        members: [
            {
                name: 'Member Name 1',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org1',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 2',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org2',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 3',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org3',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 4',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org4',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 5',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org5',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 6',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org6',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 7',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org7',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 8',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org8',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 9',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org9',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 10',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org10',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 11',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org11',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 12',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org12',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 13',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org13',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 14',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org14',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 15',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org15',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 16',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org16',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 17',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org17',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 18',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org18',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 19',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org19',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 20',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org20',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 21',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org21',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 22',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org22',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 23',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org23',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 24',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org24',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 25',
                role: 'Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=Org25',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    },
    {
        title: 'Overseas Organisers',
        description: 'International Operations',
        members: [
            {
                name: 'Member Name 1',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO1',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 2',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO2',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 3',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO3',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 4',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO4',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 5',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO5',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 6',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO6',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 7',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO7',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 8',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO8',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 9',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO9',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 10',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO10',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 11',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO11',
                email: '',
                phone: '',
                linkedin: ''
            },
            {
                name: 'Member Name 12',
                role: 'Overseas Organiser',
                img: 'https://api.dicebear.com/7.x/initials/svg?seed=OO12',
                email: '',
                phone: '',
                linkedin: ''
            }
        ]
    }
];
const Card = ({ person })=>{
    const handleClick = ()=>{
        if (person.link) {
            window.location.href = person.link;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `group bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-neutral-100 text-center relative overflow-hidden ${person.link ? 'cursor-pointer' : ''}`,
        onClick: handleClick,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-0 left-0 w-full h-1 bg-linear-to-r from-red-600 to-red-800 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                lineNumber: 160,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-56 h-56 mx-auto mb-4 rounded-xl p-1.5 bg-linear-to-br from-red-100 to-red-50 group-hover:from-red-600 group-hover:to-red-800 transition-colors duration-300",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full h-full rounded-lg overflow-hidden bg-white relative",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: person.img,
                        alt: `${person.name} photo`,
                        fill: true,
                        className: "object-cover transition-transform duration-500 group-hover:scale-110",
                        sizes: "224px"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                        lineNumber: 164,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                    lineNumber: 163,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                lineNumber: 162,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-lg font-bold text-neutral-900 mb-1",
                children: person.name
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                lineNumber: 174,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-red-700 font-medium mb-4 text-sm",
                children: person.role
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                lineNumber: 175,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center gap-3",
                children: person.linkedin || person.email ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        person.linkedin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: person.linkedin,
                            target: "_blank",
                            rel: "noreferrer",
                            onClick: (e)=>e.stopPropagation(),
                            className: "w-10 h-10 rounded-full bg-neutral-50 hover:bg-blue-600 text-neutral-600 hover:text-white flex items-center justify-center transition-all duration-300 shadow-sm hover:shadow-md",
                            "aria-label": "LinkedIn",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$linkedin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Linkedin$3e$__["Linkedin"], {
                                className: "w-4 h-4"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 189,
                                columnNumber: 33
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                            lineNumber: 181,
                            columnNumber: 29
                        }, ("TURBOPACK compile-time value", void 0)),
                        person.email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(person.email)}`,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            onClick: (e)=>e.stopPropagation(),
                            className: "w-10 h-10 rounded-full bg-neutral-50 hover:bg-red-700 text-neutral-600 hover:text-white flex items-center justify-center transition-all duration-300 shadow-sm hover:shadow-md",
                            "aria-label": "Email",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                className: "w-4 h-4"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 205,
                                columnNumber: 33
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                            lineNumber: 193,
                            columnNumber: 29
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "h-10"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                    lineNumber: 210,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                lineNumber: 177,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            person.phone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-neutral-600 text-sm mt-2",
                children: person.phone
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                lineNumber: 214,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
        lineNumber: 156,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
function OurTeam() {
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-neutral-50 min-h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative bg-transparent pt-12 md:pt-16 lg:pt-20 pb-8 border-b border-neutral-100 overflow-hidden",
                style: {
                    minHeight: '320px'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 z-0 pointer-events-none",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/Images/iplbanner.png",
                                alt: "Our team background",
                                className: "w-[85%] h-full opacity-40 object-contain mx-auto",
                                style: {
                                    objectPosition: 'center'
                                }
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 227,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    position: 'absolute',
                                    inset: 0,
                                    backgroundColor: 'rgba(0,0,0,0.04)'
                                }
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 233,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                        lineNumber: 226,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10 container-custom mx-auto text-center max-w-4xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-50 border border-red-100 mb-6 animate-fade-in",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                        className: "w-4 h-4 text-red-700"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                        lineNumber: 237,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm font-semibold text-red-800",
                                        children: t('ourteam.badge', 'Leadership & Volunteers')
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                        lineNumber: 238,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 236,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-4xl md:text-5xl lg:text-6xl font-extrabold text-neutral-900 mb-6 animate-slide-up",
                                children: t('ourteam.title', 'Our Team')
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 241,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xl text-neutral-600 leading-relaxed max-w-2xl mx-auto animate-slide-up",
                                style: {
                                    animationDelay: '0.1s'
                                },
                                children: t('ourteam.subtitle', 'The people who nurture the spirit of Love, Friendship, and Humanity')
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 245,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                        lineNumber: 235,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                lineNumber: 225,
                columnNumber: 13
            }, this),
            team.map((section, sectionIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "py-12 border-b border-neutral-100 last:border-b-0",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container-custom mx-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center mb-10",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-center gap-3 mb-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__["Shield"], {
                                            className: "w-6 h-6 text-red-700"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                            lineNumber: 257,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-3xl font-bold text-neutral-900",
                                            children: section.title
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                            lineNumber: 258,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                    lineNumber: 256,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 255,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `grid gap-6 justify-items-center ${section.members.length === 1 ? 'sm:grid-cols-1 max-w-sm mx-auto' : section.members.length === 2 ? 'sm:grid-cols-2 max-w-2xl mx-auto' : section.members.length <= 4 ? 'sm:grid-cols-2 lg:grid-cols-4' : 'sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'}`,
                                children: section.members.map((person, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "animate-slide-up",
                                        style: {
                                            animationDelay: `${i * 100}ms`
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Card, {
                                            person: person
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                            lineNumber: 265,
                                            columnNumber: 37
                                        }, this)
                                    }, i, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                        lineNumber: 264,
                                        columnNumber: 33
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                                lineNumber: 262,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                        lineNumber: 254,
                        columnNumber: 21
                    }, this)
                }, sectionIndex, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
                    lineNumber: 253,
                    columnNumber: 17
                }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/our-team/page.tsx",
        lineNumber: 223,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=IPL-Website-test-main_src_app_our-team_page_tsx_a75dcbcf._.js.map