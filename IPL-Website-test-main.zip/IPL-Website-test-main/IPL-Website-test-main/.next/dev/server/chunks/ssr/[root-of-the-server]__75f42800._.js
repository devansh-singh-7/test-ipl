module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/IPL-Website-test-main/src/i18n/translations.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const translations = {
    en: {
        nav: {
            home: 'Home',
            about: 'About',
            iplProfile: 'IPL Profile',
            history: 'History',
            presidentBlog: "IPL President's Blog",
            team: 'Our Team',
            organiser: 'Organiser',
            humanitarian: 'Humanitarian Services',
            news: 'News & Events',
            iplNews: 'IPL News',
            meet: 'Friendship Meet',
            contact: 'Contact'
        },
        header: {
            lang_en: 'EN',
            lang_ta: 'த',
            search_placeholder: 'Search...'
        },
        brand: {
            name: "Indian Penpals' League"
        },
        home: {
            hero_title: "Indian Penpals' League",
            hero_title_native: "இந்தியப் பேனாநண்பர் பேரவை",
            hero_sub: 'Love, Friendship & Humanity',
            hero_desc: 'A confederation of friends dedicated to Love, Friendship and Humanity',
            hero_desc_native: 'Hearts enriched through love, friendship and humanitarian thoughts removing barriers of caste, religion and politics',
            established: 'Established March 12, 1995',
            stats: {
                visitors: 'Visitors',
                activities: 'Humanitarian Activities',
                years: 'Years of Service',
                certificate: 'Tax Benefit Certificate'
            },
            welcome_title: 'Welcome to Indian Penpals\' League',
            founder_quote: 'Let us breathe friendship! Let us love our friends! Let us sow love, friendship, and humanity! Let us nurture and continue tirelessly! The journey of friendship...',
            founder_name: 'M. Karuna, Founder - President',
            about_intro: 'The Indian Penpals\' League (IPL) is a confederation of groups of friends in India and abroad. IPL had its inception in Mumbai on March 12, 1995, formed by like-minded pen-pals coming together to uphold three basic principles of Love, Friendship and Humanity, overcoming the barriers of caste, color, creed, religion, language and geographical bounds separating humankind.',
            about_registration: 'In the years of upcoming with its activities, the IPL got registered under the Bombay Societies Act, 1950 and grew up as a Social Welfare Trust. Thereafter, the IPL was registered under The Bombay Public Trust Act, bearing registration number',
            about_80g: 'At the request of the IPL, it was awarded with certificate under Section 80G by the Income Tax Department of Government of India, which gives Tax benefit to the donors who contribute towards our humanitarian activities.',
            read_more: 'Read More About Us',
            our_activities: 'Our Activities',
            activities_subtitle: 'Discover the various ways we spread love, friendship and humanity across communities',
            learn_more: 'Learn More',
            feature1_title: 'Humanitarian Services',
            feature1_desc: 'Hearts united through letters sharing love, friendship and humanitarian thoughts have evolved into social welfare activities and registered as a Social Welfare Trust providing humanitarian assistance.',
            feature2_title: 'Friendship Meet',
            feature2_desc: 'Friends who exchange ideas through letters meeting in person to feel the strength and glory of friendship - the blossoming tree from the seed of this thought is the Friendship Meet celebrations held successfully.',
            feature3_title: 'News & Events',
            feature3_desc: 'Stay updated with our latest activities, celebrations, and community events. Join us in our journey of spreading love and friendship across communities.',
            recent_activities: 'Recent Humanitarian Activities',
            recent_subtitle: 'Our latest efforts in serving the community',
            activity1_date: 'Dec 26, 2024',
            activity1_title: 'Medical Assistance, Mumbai',
            activity1_desc: 'Medical assistance provided by the League, Mumbai',
            activity2_date: 'Jan 11, 2024',
            activity2_title: 'Chennai Admin Meeting & Medical Assistance',
            activity2_desc: 'Chennai League Admin Meeting and Medical Assistance',
            activity3_date: 'Dec 2023',
            activity3_title: 'Education Fee Assistance, Bangalore',
            activity3_desc: 'Education fee assistance by the League, Bangalore',
            view_all: 'View All Activities',
            mother_teresa_quote: 'We feel what we are doing is just a drop in the ocean but the ocean would be less because of that missing drop',
            mother_teresa: 'Mother Teresa',
            // Carousel additions
            carousel1_title: 'IPL Community Moments',
            carousel2_title: 'Humanitarian Service',
            carousel3_title: 'Friendship Meet Highlights',
            carousel1_desc: 'Snapshots from our events and outreach',
            carousel2_desc: 'Medical, education, and welfare support efforts',
            carousel3_desc: 'Celebrating bonds that bring people together'
        },
        footer: {
            contact_us: 'Contact Us',
            quick_links: 'Quick Links',
            address: '103, Starview Apts., Opp. Corporate Park, V.N.Purav Marg, Chembur, Mumbai - 400071, India',
            email: 'Email',
            about_text: 'Love, Friendship & Humanity - A confederation of friends united to serve communities.',
            rights: 'All Rights Reserved',
            privacy: 'Privacy Policy',
            terms: 'Terms of Service'
        },
        common: {
            submit: 'Submit'
        },
        search: {
            placeholder: 'Search the site...',
            no_results: 'No matches found',
            popular: 'Popular Searches',
            clear: 'Clear',
            recent: 'Recent',
            suggestions: 'Suggestions',
            searching: 'Searching...',
            all_results: 'View all results'
        },
        ourteam: {
            badge: 'Leadership & Volunteers',
            title: 'Our Team',
            subtitle: 'The people who nurture the spirit of Love, Friendship, and Humanity',
            core_team: 'Core Team',
            core_desc: 'Guiding IPL with vision and commitment',
            advisors: 'Advisors',
            advisors_desc: 'Supporting IPL with experience and guidance'
        },
        meet: {
            hero_tamil: 'நட்புச் சங்கமம் - Where Letters Transform into Lasting Bonds',
            intro_p1: 'Friends who have been exchanging letters and thoughts meet in person to experience the strength and pride of friendship through our organized platform - the Friendship Meet (நட்புச் சங்கமம்).',
            intro_p2: 'IPL members participate in these Friendship Meets with their family members. The two-day events create a sense of family celebration that adds special value to friendship.',
            highlight1_title: 'Meet Pen Friends',
            highlight1_desc: 'Friends meet in person to strengthen long-lasting bonds.',
            highlight2_title: 'Family Gathering',
            highlight2_desc: 'Families join together and celebrate friendship as a value.',
            highlight3_title: 'Two-Day Event',
            highlight3_desc: 'Fun, culture, interaction and meaningful experiences.',
            highlight4_title: 'Memorable Moments',
            highlight4_desc: 'Moments that live on through memories and stories.',
            annual_heading: 'Annual Friendship Meets',
            view_details: 'View Details',
            cta_title: 'Join Our Next Friendship Meet',
            cta_desc: 'Experience the joy of meeting friends who share your passion for friendship and humanity',
            cta_button: 'Contact Us for Details',
            friends_day_title: 'International Friendship Day Celebrations',
            activities_highlight: 'Activities & Highlights',
            participants: 'Participants',
            stat_meets_held: 'Meets Held',
            stat_participants: 'Participants',
            stat_cities: 'Host Cities',
            stat_years: 'Years of Legacy',
            stat_active_members: 'Active Members',
            stat_regional_branches: 'Regional Branches',
            stat_countries: 'Countries Represented',
            past_meet_1_title: '27th Friendship Meet',
            past_meet_1_location: 'Kuttalam, Tenkasi',
            past_meet_1_desc: 'Held at TMNS Hall with grand cultural events.',
            past_meet_2_title: '26th Friendship Meet',
            past_meet_2_location: 'New Delhi',
            past_meet_2_desc: 'Special gathering at Shri Vittal Mandir Hall.',
            past_meet_3_title: '25th Silver Jubilee Meet',
            past_meet_3_location: 'Tirunelveli',
            past_meet_3_desc: 'Silver Jubilee celebration with historic attendance.',
            stats: {
                meets: 'Annual Meets',
                attendees: 'Attendees',
                cities: 'Cities',
                years: 'Years'
            }
        },
        profile: {
            hero: {
                title: 'IPL Profile',
                subtitle: 'Spreading Love, Friendship & Humanity Since 1995'
            },
            intro: {
                title: 'About Our Journey',
                desc: 'The Indian Penpals League (IPL) is a confederation of friends dedicated to love, friendship and humanity.'
            },
            inception: {
                title: 'Inception of the League',
                desc: 'Hearts enriched with love, friendship, and humanitarian thoughts, eliminating caste, religious, and political differences - this is the Indian Penpals League, a beautiful friendship world.'
            },
            growth: {
                title: 'பேரவையின் வளர்ச்சி',
                desc: 'Expanded across all districts of Tamil Nadu and states including Kerala, Karnataka, Goa, Delhi, Assam, and countries like France, Australia, UAE.'
            },
            humanitarian: {
                title: 'பேரவையின் சமூகநல செயல்பாடுகள்',
                desc: 'Registered as a Social Welfare Trust under Maharashtra State Government, providing humanitarian assistance to those in need.'
            },
            friendshipMeet: {
                title: 'நட்புச் சங்கம விழாக்கள் (Friendship Meet)'
            },
            notableGuests: {
                title: 'நட்புச்சங்கம விழா, பங்கேற்ற சான்றோர் பெருமக்கள்'
            },
            education: {
                title: 'கல்விப் பணி, மருத்துவ உதவி'
            },
            achievements: {
                title: 'Our Achievements',
                eyeCamps: 'Eye Examination Camps',
                meetings: 'Friendship Meets',
                states: 'States Reached',
                years: 'Years of Service'
            },
            cta: {
                title: 'Join Our Mission',
                desc: 'Be part of our journey to spread love, friendship and humanity',
                contact: 'Contact Us',
                services: 'Our Services'
            }
        },
        history: {
            hero: {
                title: 'History',
                subtitle: 'A Journey of Love, Friendship & Humanitarian Service'
            },
            intro: {
                title: 'பேரவை வழித்தடங்கள்',
                desc: 'A legacy of humanitarian service and cultural preservation spanning nearly three decades'
            },
            timeline: {
                title: 'Major Milestones'
            },
            milestones: {
                gujarat: '2001 - Gujarat Earthquake Relief',
                gujaratDesc: 'Established relief center and collected funds for earthquake victims (January 27 - February 2, 2001)',
                tsunami: '2005 - Tsunami Relief',
                tsunamiDesc: 'Provided direct assistance to tsunami victims across coastal Tamil Nadu, distributing food, clothing and relief materials',
                paris: '2007 - Paris Recognition',
                parisDesc: 'Special guest at Mahakavi Bharathiyar 125th Anniversary in Paris, representing Mumbai Tamil organizations',
                gandhi: '2011 - Gandhi Statue Inauguration',
                gandhiDesc: 'Attended Mahatma Gandhi Statue inauguration in Paris, honored by Aubervilliers Mayor'
            },
            gujarat: {
                title: 'Gujarat Earthquake Relief',
                subtitle: 'Gujarat Earthquake Relief',
                desc: 'Established Gujarat earthquake relief center (January 27 - February 2, 2001), collected relief funds and handed them over to the Mumbai District Collector.'
            },
            tsunami: {
                title: 'Tsunami Relief Operations',
                subtitle: 'Tsunami Relief',
                desc: 'During the tsunami disaster, traveled along the coast from Colachel to Manakudy in Kanyakumari district (January 12, 2005) and directly provided rice, lentils, food grains, and clothing to the affected people. Provided welfare assistance to 200 people in Thottilpadu village alone.'
            },
            publications: {
                title: 'Literary Contributions',
                adhigalai: '"அதிகாலை" - Morning',
                idhayam: '"இதயத்துடிப்பு" - Heartbeat',
                karaiaerum: '"கரையேறும் அலைகள்" - Shore-bound Waves',
                unarvugal: '"உணர்வுகள்" - Feelings',
                seppadu: '"செப்பேடு" - Copper Plate',
                kamarajar: '"காமராஜர் காவியம்" - Kamarajar Epic (1050 pages)',
                kamarajarHighlight: 'Epic Poetry',
                kamarajarDesc: 'Fully supported Mumbai poet Senthoor Nagarajan in creating the monumental 1050-page epic poetry book "Kamarajar Kaviyam," organizing a grand release function, conducting research seminars, and introducing it to the Tamil literary world.',
                author1: 'Theni Poet Vetrivel',
                author2: 'Mumbai Poet Senthoor Nagarajan',
                author3: 'Mumbai Poet Irajakai Nilavan',
                author4: 'Mumbai Poet M. S. Rajan Martin',
                author5: 'Hosur Poet Karumalai Tamilazhan',
                author6: 'Mumbai Poet Senthoor Nagarajan'
            },
            international: {
                title: 'International Recognition',
                paris2007: 'Paris - Bharathiyar 125th Anniversary (2007)',
                paris2007Desc: 'The only Mumbai Tamil organization invited as a special guest to the 125th anniversary of Mahakavi Bharathiyar organized by France Tamil Sangam in Paris on November 4, 2007.',
                paris2011: 'Paris - Gandhi Statue Inauguration (2011)',
                paris2011Desc: 'The only Mumbai Tamil organization invited as a special guest to the "Mahatma Gandhi Statue Inauguration" organized by Aubervilliers Tamil Cultural Forum in Paris on November 11, 2011. A historic moment when a memento was presented and greetings were offered to the Mayor of Aubervilliers Municipal Corporation.',
                srilanka: 'Sri Lanka - Tamil Magazines Conference',
                srilankaDesc: 'Invited and participated as a special guest at the 6th conference of Tamil Little Magazines Association held in Sri Lanka.'
            },
            global: {
                title: 'Global Tamil Network',
                desc: 'A Mumbai Tamil organization that maintains friendship with numerous internationally operating Tamil organizations, unites Tamils globally, participates in Tamil cultural events, and is fully committed to nurturing the mother tongue.'
            },
            cta: {
                title: 'Learn More About IPL',
                desc: 'Discover our journey and join our mission',
                profile: 'View Profile',
                events: 'See Events'
            }
        },
        blog: {
            hero: {
                title: "IPL President's Blog",
                subtitle: 'Updates, Achievements & Reflections from Our President'
            },
            intro: {
                title: 'தலைவரின் வலைபதிவு',
                desc: 'Latest updates and reflections from our President on IPL activities and achievements'
            },
            featured: {
                title: 'Featured Posts'
            },
            allPosts: {
                title: 'All Posts'
            },
            readMore: 'Read More',
            pagination: {
                previous: 'Previous',
                next: 'Next'
            },
            posts: {
                silverJubilee: {
                    title: "IPL's Silver Jubilee Year: 1995 - 2020",
                    desc: 'Celebrating 25 years of love, friendship and humanitarian service'
                },
                friendship27: {
                    title: '27th Friendship Meet',
                    desc: '27வது நட்புச் சங்கமம் - Annual gathering of friends from across India and abroad'
                },
                pongal2024: {
                    title: 'தமிழர் திருநாள் 2024 நல்வாழ்த்துக்கள்',
                    desc: 'Pongal Festival Greetings 2024'
                },
                souvenir2023: {
                    title: 'IPL Souvenir Collections - 2023',
                    desc: 'Cover photo of IPL Souvenir Collections for the year 2023'
                },
                isroVisit: {
                    title: 'Meeting with ISRO Chairman',
                    desc: 'IPL President Mr. M. Karun met with former ISRO Chairman'
                },
                agm19: {
                    title: '19th AGM Notice - May 2022',
                    desc: 'Notice for the 19th Annual General Meeting of Indian Penpals League'
                },
                secretaryWedding: {
                    title: 'General Secretary Wedding Anniversary',
                    desc: 'Wedding anniversary greetings to General Secretary J. John Kennedy'
                },
                calendar2022: {
                    title: 'IPL Calendar 2022 Published',
                    desc: 'IPL Calendar 2022 released at Head Office'
                },
                cmLetter: {
                    title: 'Letter to Chief Minister - Job Assistance',
                    desc: 'Request for government relief assistance for IPL member family'
                },
                hajTravel: {
                    title: 'Letter to CM - Haj Travel Request',
                    desc: 'Letter to Chief Minister of Tamil Nadu to include Chennai Airport for Haj Holy Travelers'
                },
                diaspora: {
                    title: 'Tamil Diaspora Welfare Board Appreciation',
                    desc: 'Appreciation to Tamil Nadu Chief Minister for announcing Tamil Diaspora Welfare Board'
                },
                lifetimeAward: {
                    title: 'Lifetime Achievement Award',
                    desc: 'Mr. M. Karun receives Lifetime Achievement Award for social service contributions'
                },
                chancellor: {
                    title: 'Meeting with University Chancellor',
                    desc: 'IPL President meeting with University Chancellor - 2018'
                },
                airport: {
                    title: 'Chennai Airport Letter - February 2021',
                    desc: 'Correspondence with Chennai Airport General Manager'
                },
                pongal2020: {
                    title: 'தமிழர் திருநாள் 2020 நல்வாழ்த்துக்கள்',
                    desc: 'Pongal Festival Greetings 2020'
                },
                covidRelief: {
                    title: 'COVID-19 Relief Fund Contribution',
                    desc: 'Chief Minister Relief Fund contribution by VIT Founder-President'
                },
                chessAcademy: {
                    title: 'IPL Chess Academy - At a Glance',
                    desc: 'Overview of IPL Chess Academy initiatives'
                },
                souvenir2019: {
                    title: 'IPL Souvenir to VIP - 2019',
                    desc: 'IPL Souvenir presented to VIP guests in 2019'
                }
            },
            highlights: {
                title: 'Notable Highlights',
                award: {
                    title: 'Lifetime Achievement Award'
                },
                isro: {
                    title: 'ISRO Chairman Meeting'
                },
                calendar: {
                    title: 'Annual Calendar Publication'
                },
                jubilee: {
                    title: 'Silver Jubilee Celebration'
                }
            },
            cta: {
                title: 'Stay Updated',
                desc: 'Follow our latest activities and achievements',
                news: 'Latest News',
                contact: 'Contact Us'
            }
        },
        contact: {
            badge: 'Get In Touch',
            subtitle: 'We would love to hear from you. Reach out and we will respond soon.',
            info_intro: 'We are happy to help. Use the form and we will get back to you promptly.',
            success_message: 'Thanks — your message has been sent.',
            form_errors_heading: 'There are problems with your submission',
            cooldown: 'Please wait...',
            sending: 'Sending...',
            error_name_required: 'Please enter your name',
            error_email_required: 'Please enter your email',
            error_email_invalid: 'Please enter a valid email address',
            error_subject_required: 'Please enter a subject',
            error_subject_short: 'Subject is too short',
            error_subject_long: 'Subject is too long',
            error_message_required: 'Please enter a message',
            error_message_short: 'Message is too short',
            error_submit: 'Something went wrong. Please try again later.',
            map_title: 'Office location map',
            get_in_touch: 'Get In Touch',
            send_message: 'Send Us a Message',
            address_title: 'Address',
            phone_title: 'Phone',
            hours_title: 'Office Hours',
            hours_detail: 'Monday - Saturday: 10:00 AM - 6:00 PM',
            form_name: 'Your Name',
            form_name_placeholder: 'Enter your name',
            form_email: 'Email Address',
            form_email_placeholder: 'Enter your email',
            form_subject: 'Subject',
            form_subject_placeholder: 'Enter subject',
            form_message: 'Message',
            form_message_placeholder: 'Enter your message',
            form_submit: 'Send Message',
            visit_us: 'Visit Us',
            visit_desc: 'We welcome you to visit our office in Mumbai. Please call ahead to schedule an appointment.',
            office_address: 'Our Office',
            directions: 'Directions',
            directions_text: 'Near Chembur station, opposite Corporate Park',
            open_in_maps: 'Open in Google Maps',
            getting_here: 'Getting Here',
            by_train: 'By Train',
            train_details: 'Chembur Station - 5 min walk',
            by_bus: 'By Bus',
            bus_details: 'Multiple bus routes available',
            by_car: 'By Car',
            car_details: 'Parking available nearby'
        },
        humanitarian: {
            subtitle: 'Serving Humanity with Love and Compassion',
            service1_title: 'Medical Assistance',
            service1_desc: 'Providing medical aid, health camps, and support to those in need',
            service2_title: 'Education Support',
            service2_desc: 'Scholarships and educational assistance for deserving students',
            service3_title: 'Food & Clothing',
            service3_desc: 'Distribution of essential supplies to affected communities',
            service4_title: 'Livelihood Support',
            service4_desc: 'Helping families with tools and resources for self-sufficiency',
            service5_title: 'Blood Donation',
            service5_desc: 'Organizing blood donation camps to save lives',
            service6_title: 'Community Service',
            service6_desc: 'Various social welfare activities across India',
            impact_title: 'Our Impact',
            families_helped: 'Families Helped',
            donate_title: 'Support Our Mission',
            donate_desc: 'Your contribution helps us serve more communities in need',
            tax_benefit: 'Tax benefits available under Section 80G'
        },
        about: {
            title: 'About Us',
            subtitle: 'Our Journey of Love, Friendship and Humanity',
            mission: 'Our Mission',
            registration_title: 'Registration & Recognition',
            reg_societies: 'Bombay Societies Act, 1950',
            reg_societies_detail: 'Registered as a Social Welfare Trust',
            reg_trust: 'Bombay Public Trust Act',
            reg_trust_detail: 'Registration #F23778',
            reg_80g: 'Section 80G Certificate',
            reg_80g_detail: 'Tax benefit for donors',
            reg_welfare: 'Social Welfare Trust',
            reg_welfare_detail: 'Serving communities since 1995',
            core_values: 'Our Core Values',
            value1_title: 'Love',
            value1_desc: 'Spreading unconditional love across all communities',
            value2_title: 'Friendship',
            value2_desc: 'Building bridges through meaningful friendships',
            value3_title: 'Humanity',
            value3_desc: 'Serving humanity with compassion and dedication',
            journey: 'Our Journey',
            milestone1: 'IPL founded in Mumbai on March 12, 1995 by pen-pals united by love, friendship and humanity',
            milestone2: 'Registered under Bombay Societies Act, 1950 and Bombay Public Trust Act',
            milestone3: 'Awarded Section 80G certificate and expanded humanitarian services across India and abroad',
            join_us: 'Join Us in Our Mission',
            join_desc: 'Be part of a community that believes in the power of friendship and humanity'
        },
        news: {
            badge: 'Latest Updates',
            title: 'News & Events',
            subtitle: "Discover the latest happenings, milestones, and celebrations from the Indian Penpals' League community",
            search_placeholder: 'Search events...',
            view_grid: 'Grid',
            view_timeline: 'Timeline',
            featured: 'Featured Events',
            featured_sub: 'Highlighting recent impactful activities',
            new_badge: 'NEW',
            more_info: 'More Info',
            view_details: 'View Details',
            all_events: 'All Events',
            all_events_sub: 'Browse events in grid or timeline view. Use search to filter results by title, description or location.'
        },
        pagination: {
            prev: 'Previous',
            next: 'Next'
        },
        meet: {
            badge: 'Annual Celebration',
            title: 'Friendship Meet',
            subtitle_native: 'நட்புச் சங்கமம்',
            subtitle: 'Where letters transform into lasting bonds and pen friends become family',
            what_title: 'What is Friendship Meet?',
            what_desc: 'An annual gathering where pen friends across the world meet in person to celebrate the bonds formed through letters.',
            past_title: 'Annual Friendship Meets',
            past_sub: 'Explore our journey through the years',
            badge_small: 'Annual Meet',
            upcoming: 'UPCOMING',
            highlight1: {
                title: 'Meet Pen Friends',
                desc: "Connect with friends you've been writing to for years"
            },
            highlight2: {
                title: 'Family Gathering',
                desc: 'Bring your family and celebrate together'
            },
            highlight3: {
                title: 'Cultural Exchange',
                desc: 'Experience diverse cultures and traditions'
            },
            highlight4: {
                title: 'Memorable Moments',
                desc: 'Create lasting memories and friendships'
            },
            // Specific meet entries
            28: {
                title: '28th Friendship Meet',
                date: '24 MAY 2025',
                location: 'To be announced',
                desc: 'The 28th Annual Friendship Meet bringing together pen friends from across India and abroad'
            },
            27: {
                title: '27th Friendship Meet',
                date: '25 MAY 2024',
                location: 'Kuttalam, Tenkasi District',
                desc: '27th Annual Friendship Meet held at TMNS Hall, Kuttalam'
            },
            26: {
                title: '26th Friendship Meet',
                date: '20 MAY 2023',
                location: 'New Delhi',
                desc: 'Shri Vittal Mandir Hall, Ramakrishnapuram, New Delhi'
            }
        }
    },
    ta: {
        nav: {
            home: 'முகப்பு',
            about: 'எங்களைப் பற்றி',
            iplProfile: 'ஐபிஎல் சுருக்கம்',
            history: 'வரலாறு',
            presidentBlog: 'தலைவரின் வலைபதிவு',
            team: 'எங்கள் குழு',
            humanitarian: 'மனிதநேய சேவைகள்',
            news: 'செய்திகள் & நிகழ்வுகள்',
            iplNews: 'ஐபிஎல் செய்திகள்',
            meet: 'நட்புச் சங்கமம்',
            contact: 'தொடர்பு கொள்ள'
        },
        header: {
            lang_en: 'EN',
            lang_ta: 'த',
            search_placeholder: 'தேடு...'
        },
        brand: {
            name: 'இந்தியப் பேனாநண்பர் பேரவை'
        },
        home: {
            hero_title: 'இந்தியப் பேனாநண்பர் பேரவை',
            hero_title_native: 'இந்தியப் பேனாநண்பர் பேரவை',
            hero_sub: 'அன்பு, நட்பு, மனிதநேயம்',
            hero_desc: 'அன்பு, நட்பு மற்றும் மனிதநேயத்திற்காக அர்ப்பணிக்கப்பட்ட நண்பர்களின் கூட்டமைப்பு',
            hero_desc_native: 'அன்பு, நட்பு, மனிதநேய சிந்தனைகளைக் கருவாகக் கொண்டு சாதி, சமய, அரசியல் வேறுபாடுகளை அகற்றி இதயங்களை வளப்படுத்தும்',
            established: 'ஸ்தாபிக்கப்பட்டது மார்ச் 12, 1995',
            stats: {
                visitors: 'பார்வையாளர்கள்',
                activities: 'மனிதநேய செயல்பாடுகள்',
                years: 'சேவை ஆண்டுகள்',
                certificate: 'வரி சலுகை சான்றிதழ்'
            },
            welcome_title: 'இந்தியப் பேனாநண்பர் பேரவைக்கு வரவேற்கிறோம்',
            founder_quote: 'நட்பை சுவாசிப்போம்! நண்பர்களை நேசிப்போம்! அன்பு, நட்பு, மனிதநேயம் விதைப்போம்! வளர்ப்போம்! தொய்வின்றி தொடர்வோம்! நட்புப் பயணத்தை...',
            founder_name: 'மா. கருண், நிறுவனர் - தலைவர்',
            about_intro: 'இந்தியப் பேனாநண்பர் பேரவை (IPL) இந்தியாவிலும் வெளிநாடுகளிலும் உள்ள நண்பர்களின் குழுக்களின் கூட்டமைப்பாகும். IPL மார்ச் 12, 1995 அன்று மும்பையில் தோற்றுவிக்கப்பட்டது, ஒரே மனப்பான்மையுள்ள பேனாநண்பர்கள் அன்பு, நட்பு மற்றும் மனிதநேயம் என்ற மூன்று அடிப்படைக் கொள்கைகளை நிலைநிறுத்த ஒன்றிணைந்தனர், சாதி, நிறம், மதம், மொழி மற்றும் புவியியல் எல்லைகளின் தடைகளை கடந்து மனிதகுலத்தை பிரிக்கிறது.',
            about_registration: 'அதன் செயல்பாடுகளுடன் வரும் ஆண்டுகளில், IPL பம்பாய் சங்கங்கள் சட்டம், 1950 இன் கீழ் பதிவு செய்யப்பட்டு சமூக நல அறக்கட்டளையாக வளர்ந்தது. அதன்பிறகு, IPL பம்பாய் பொது அறக்கட்டளை சட்டத்தின் கீழ் பதிவு செய்யப்பட்டது, பதிவு எண்',
            about_80g: 'IPL இன் கோரிக்கையின் பேரில், இந்திய அரசாங்கத்தின் வருமான வரித் துறையால் பிரிவு 80G இன் கீழ் சான்றிதழ் வழங்கப்பட்டது, இது நன்கொடையாளர்களுக்கு வரி சலுகை அளிக்கிறது.',
            read_more: 'எங்களைப் பற்றி மேலும் படிக்கவும்',
            our_activities: 'எங்கள் செயல்பாடுகள்',
            activities_subtitle: 'சமூகங்கள் முழுவதும் அன்பு, நட்பு மற்றும் மனிதநேயத்தை பரப்பும் பல்வேறு வழிகளை கண்டறியுங்கள்',
            learn_more: 'மேலும் அறிக',
            feature1_title: 'மனிதநேய சேவைகள்',
            feature1_desc: 'எழுத்தால் இணைந்த இதயங்கள் அன்பு, நட்பு, மனிதநேயச் சிந்தனைகளைக் கடிதங்கள் மூலம் பகிர்ந்துகொண்ட நிலையில், சமூகநல செயல்பாடுகள் என்று வளர்ச்சி பெற்று சமூக நல அறக்கட்டளையாகப் பதிவு செய்யப்பட்டு மனிதநேய உதவிகளும் வழங்கப்பட்டு வருகிறது.',
            feature2_title: 'நட்புச் சங்கமம்',
            feature2_desc: 'கடிதங்கள் மூலம் கருத்துகளைப் பரிமாறும் நண்பர்கள் நேரில் சந்தித்து நட்பின் உறுதியையும், பெருமையையும் உணர களம் அமைக்க வேண்டும் என்ற எண்ண விதையின் ஆலவிருட்சமே, தொடர்ந்து சிறப்புடன் நடைபெற்று வரும் நட்புச் சங்கம விழாக்கள்.',
            feature3_title: 'நண்பர்கள் தினம்',
            feature3_desc: 'மானுட ஏற்ற தாழ்வுகளை மீறியொரு கல்வெட்டாய் விளங்கும் இந்த நட்புப் பாசறை துவங்கிய 12 மார்ச், நண்பர்கள் தினம் என வெகு விமரிசையாக சமூக நல நிகழ்வுகளுடன் ஆண்டுதோறும் இந்தியப் பேனா நண்பர் பேரவையால் தொடர்ந்து கொண்டாடப்படுகிறது.',
            recent_activities: 'சமீபத்திய மனிதநேய செயல்பாடுகள்',
            recent_subtitle: 'சமூகத்திற்கு சேவை செய்வதில் எங்கள் சமீபத்திய முயற்சிகள்',
            activity1_date: '26 டிச 2024',
            activity1_title: 'மருத்துவ உதவி, மும்பை',
            activity1_desc: 'பேரவை சார்பாக வழங்கப்பட்ட மருத்துவ உதவி, மும்பை',
            activity2_date: '11 ஜன 2024',
            activity2_title: 'சென்னை நிர்வாகிகள் சந்திப்பு மற்றும் மருத்துவ உதவி',
            activity2_desc: 'சென்னை பேரவை நிர்வாகிகள் சந்திப்பு மற்றும் மருத்துவ உதவி',
            activity3_date: 'டிச 2023',
            activity3_title: 'கல்விக் கட்டண உதவி, பெங்களூரு',
            activity3_desc: 'பேரவை சார்பாக கல்விக் கட்டண உதவி, பெங்களூரு',
            view_all: 'அனைத்து செயல்பாடுகளையும் காண்க',
            mother_teresa_quote: 'நாம் செய்வது கடலில் ஒரு துளி மட்டுமே என்று நாம் நினைக்கிறோம், ஆனால் அந்த துளி இல்லாமல் கடல் குறைவாக இருக்கும்',
            mother_teresa: 'அன்னை தெரசா',
            carousel1_title: 'IPL சமூக தருணங்கள்',
            carousel2_title: 'மனிதநேய சேவை',
            carousel3_title: 'நட்புச் சங்கமம் சிறப்புகள்',
            carousel1_desc: 'எங்கள் நிகழ்வுகள் மற்றும் சமூக சேவைகளின் ஒளிப்படங்கள்',
            carousel2_desc: 'மருத்துவம், கல்வி மற்றும் நலத் திட்ட உதவிகள்',
            carousel3_desc: 'மக்களை ஒன்றிணைக்கும் பந்தங்களை கொண்டாடுதல்'
        },
        footer: {
            contact_us: 'எங்களை தொடர்பு கொள்ளுங்கள்',
            quick_links: 'விரைவு இணைப்புகள்',
            address: '103, ஸ்டார்வியூ அபார்ட்மெண்ட்ஸ், கார்ப்பரேட் பார்க் எதிரில், வி.என்.புரவ் மார்க், செம்பூர், மும்பை - 400071, இந்தியா',
            email: 'மின்னஞ்சல்',
            about_text: 'அன்பு, நட்பு மற்றும் மனிதநேயம் - சமூகங்களுக்கு சேவை செய்ய ஒன்றிணைந்த நண்பர்களின் கூட்டமைப்பு.',
            rights: 'அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை',
            privacy: 'தனியுரிமைக் கொள்கை',
            terms: 'சேவை விதிமுறைகள்'
        },
        common: {
            submit: 'சமர்ப்பிக்க'
        },
        search: {
            placeholder: 'தளத்தில் தேட...',
            no_results: 'பொருத்தங்கள் இல்லை',
            popular: 'பிரபலமான தேடல்கள்',
            clear: 'அழிக்க',
            recent: 'சமீபத்திய',
            suggestions: 'பரிந்துரைகள்',
            searching: 'தேடுகிறது...',
            all_results: 'அனைத்து முடிவுகளும்'
        }
    },
    ourteam: {
        badge: 'முன்னணியினர் & தன்னார்வலர்கள்',
        title: 'எங்கள் குழு',
        subtitle: 'அன்பு, நட்பு மற்றும் மனிதநேயத்தின் உணர்வை வளர்க்கும் மனிதர்கள்',
        core_team: 'முதன்மை குழு',
        core_desc: 'தெளிவான நோக்கத்துடன் IPL-ஐ வழிநடத்தல்',
        advisors: 'ஆலோசகர்கள்',
        advisors_desc: 'அனுபவம் மற்றும் வழிகாட்டுதலுடன் IPL-ஐ ஆதரித்தல்'
    },
    meet: {
        hero_tamil: 'நட்புச் சங்கமம் - எழுத்துக்கள் நெடுங்கால பந்தங்களாக மாறும் இடம்',
        intro_p1: 'கருத்துகளையும் கடிதங்களையும் பரிமாறிக் கொண்ட நண்பர்கள் நேரில் சந்தித்து, எங்கள் ஒழுங்கமைக்கப்பட்ட தளத்தின் மூலம் — நட்புச் சங்கமம் — நட்பின் வலிமையையும் பெருமையையும் அனுபவிக்கிறார்கள்.',
        intro_p2: 'IPL உறுப்பினர்கள் தங்கள் குடும்பத்தினருடன் இந்த நட்புச் சங்கமங்களில் பங்கேற்கிறார்கள். இரண்டு நாள் நிகழ்வுகள் குடும்ப விழா உணர்வை உருவாக்கி நட்பிற்கு சிறப்பு மதிப்பை சேர்க்கிறது.',
        highlight1_title: 'பேனா நண்பர்களைச் சந்திக்கவும்',
        highlight1_desc: 'நெடுங்கால பந்தங்களை வலுப்படுத்த நண்பர்கள் நேரில் சந்திக்கிறார்கள்.',
        highlight2_title: 'குடும்ப ஒன்று கூடல்',
        highlight2_desc: 'குடும்பங்கள் ஒன்று சேர்ந்து நட்பை ஒரு மதிப்பாகக் கொண்டாடுகின்றன.',
        highlight3_title: 'இரண்டு நாள் நிகழ்வு',
        highlight3_desc: 'மகிழ்ச்சி, கலாசாரம், தொடர்பு மற்றும் அர்த்தமுள்ள அனுபவங்கள்.',
        highlight4_title: 'நினைவில் நிற்கும் தருணங்கள்',
        highlight4_desc: 'நினைவுகளும் கதைகளும் மூலம் வாழும் தருணங்கள்.',
        annual_heading: 'ஆண்டுதோறும் நட்புச் சங்கமம்',
        view_details: 'விவரங்களைப் பார்க்க',
        cta_title: 'அடுத்த நட்புச் சங்கமத்தில் சேருங்கள்',
        cta_desc: 'நட்பு மற்றும் மனிதநேயம் மீது உங்கள் ஆர்வத்தை பகிரும் நண்பர்களை சந்திக்கும் மகிழ்ச்சியை அனுபவிக்கவும்',
        cta_button: 'விவரங்களுக்கு எங்களை தொடர்பு கொள்ளுங்கள்'
    },
    contact: {
        badge: 'தொடர்பில் இருங்கள்',
        subtitle: 'உங்களிடம் இருந்து கேட்க மகிழ்ச்சி. தொடர்புகொள்ளுங்கள்; விரைவில் பதிலளிப்போம்.',
        info_intro: 'உதவ தயாராக இருக்கிறோம். இந்த படிவத்தைப் பயன்படுத்துங்கள்; விரைவில் தொடர்பு கொள்கிறோம்.',
        success_message: 'நன்றி — உங்கள் செய்தி அனுப்பப்பட்டுள்ளது.',
        form_errors_heading: 'உங்கள் சமர்ப்பிப்பில் சில பிரச்சினைகள் உள்ளன',
        cooldown: 'சற்று காத்திருக்கவும்...',
        sending: 'அனுப்புகிறது...',
        error_name_required: 'தயவுசெய்து உங்கள் பெயரை உள்ளிடவும்',
        error_email_required: 'தயவுசெய்து உங்கள் மின்னஞ்சலை உள்ளிடவும்',
        error_email_invalid: 'சரியான மின்னஞ்சலை உள்ளிடவும்',
        error_subject_required: 'தயவுசெய்து பொருளை உள்ளிடவும்',
        error_subject_short: 'பொருள் மிகக் குறுகியது',
        error_subject_long: 'பொருள் மிக நீளமாக உள்ளது',
        error_message_required: 'தயவுசெய்து செய்தியை உள்ளிடவும்',
        error_message_short: 'செய்தி மிகக் குறுகியது',
        error_submit: 'ஏதோ தவறு ஏற்பட்டது. பின்னர் மீண்டும் முயற்சிக்கவும்.',
        map_title: 'அலுவலக இடம் வரைபடம்',
        get_in_touch: 'தொடர்பில் இருங்கள்',
        send_message: 'எங்களுக்கு செய்தி அனுப்புங்கள்',
        address_title: 'முகவரி',
        phone_title: 'தொலைபேசி',
        hours_title: 'அலுவலக நேரம்',
        hours_detail: 'திங்கள் - சனி: காலை 10:00 - மாலை 6:00',
        form_name: 'உங்கள் பெயர்',
        form_name_placeholder: 'உங்கள் பெயரை உள்ளிடவும்',
        form_email: 'மின்னஞ்சல் முகவரி',
        form_email_placeholder: 'உங்கள் மின்னஞ்சலை உள்ளிடவும்',
        form_subject: 'பொருள்',
        form_subject_placeholder: 'பொருளை உள்ளிடவும்',
        form_message: 'செய்தி',
        form_message_placeholder: 'உங்கள் செய்தியை உள்ளிடவும்',
        form_submit: 'செய்தியை அனுப்பவும்',
        visit_us: 'எங்களை சந்திக்கவும்',
        visit_desc: 'மும்பையில் உள்ள எங்கள் அலுவலகத்திற்கு வருவதை நாங்கள் வரவேற்கிறோம். சந்திப்பை ஏற்பாடு செய்ய முன்கூட்டியே அழைக்கவும்.',
        office_address: 'எங்கள் அலுவலகம்',
        directions: 'வழிகாட்டுதல்கள்',
        directions_text: 'செம்பூர் நிலையத்திற்கு அருகில், கார்ப்பரேட் பார்க் எதிரில்',
        open_in_maps: 'Google Maps இல் திறக்கவும்',
        getting_here: 'இங்கே எப்படி வருவது',
        by_train: 'ரயில் மூலம்',
        train_details: 'செம்பூர் நிலையம் - 5 நிமிட நடை',
        by_bus: 'பேருந்து மூலம்',
        bus_details: 'பல பேருந்து வழித்தடங்கள் கிடைக்கின்றன',
        by_car: 'கார் மூலம்',
        car_details: 'அருகில் பார்க்கிங் கிடைக்கும்'
    },
    humanitarian: {
        subtitle: 'அன்பு மற்றும் இரக்கத்துடன் மனிதகுலத்திற்கு சேவை செய்தல்',
        service1_title: 'மருத்துவ உதவி',
        service1_desc: 'தேவைப்படுபவர்களுக்கு மருத்துவ உதவி, சுகாதார முகாம்கள் மற்றும் ஆதரவு வழங்குதல்',
        service2_title: 'கல்வி உதவி',
        service2_desc: 'தகுதியான மாணவர்களுக்கு உதவித்தொகை மற்றும் கல்வி உதவி',
        service3_title: 'உணவு மற்றும் ஆடை',
        service3_desc: 'பாதிக்கப்பட்ட சமூகங்களுக்கு அத்தியாவசிய பொருட்கள் விநியோகம்',
        service4_title: 'வாழ்வாதார உதவி',
        service4_desc: 'குடும்பங்களுக்கு சுயசார்புக்கான கருவிகள் மற்றும் வளங்கள் வழங்குதல்',
        service5_title: 'இரத்த தானம்',
        service5_desc: 'உயிர்களை காப்பாற்ற இரத்த தான முகாம்களை ஏற்பாடு செய்தல்',
        service6_title: 'சமூக சேவை',
        service6_desc: 'இந்தியா முழுவதும் பல்வேறு சமூக நல நடவடிக்கைகள்',
        impact_title: 'எங்கள் தாக்கம்',
        families_helped: 'குடும்பங்களுக்கு உதவியது',
        donate_title: 'எங்கள் பணியை ஆதரிக்கவும்',
        donate_desc: 'உங்கள் பங்களிப்பு தேவைப்படும் மேலும் பல சமூகங்களுக்கு சேவை செய்ய உதவுகிறது',
        tax_benefit: 'பிரிவு 80ஜி இன் கீழ் வரி சலுகைகள் கிடைக்கும்'
    },
    about: {
        title: 'எங்களைப் பற்றி',
        subtitle: 'அன்பு, நட்பு மற்றும் மனிதநேயத்தின் எங்கள் பயணம்',
        mission: 'எங்கள் நோக்கம்',
        registration_title: 'பதிவு மற்றும் அங்கீகாரம்',
        reg_societies: 'பம்பாய் சங்கங்கள் சட்டம், 1950',
        reg_societies_detail: 'சமூக நல அறக்கட்டளையாக பதிவு செய்யப்பட்டது',
        reg_trust: 'பம்பாய் பொது அறக்கட்டளை சட்டம்',
        reg_trust_detail: 'பதிவு எண் #F23778',
        reg_80g: 'பிரிவு 80ஜி சான்றிதழ்',
        reg_80g_detail: 'நன்கொடையாளர்களுக்கு வரி சலுகை',
        reg_welfare: 'சமூக நல அறக்கட்டளை',
        reg_welfare_detail: '1995 முதல் சமூகங்களுக்கு சேவை செய்து வருகிறது',
        core_values: 'எங்கள் முக்கிய மதிப்புகள்',
        value1_title: 'அன்பு',
        value1_desc: 'அனைத்து சமூகங்களிலும் நிபந்தனையற்ற அன்பை பரப்புதல்',
        value2_title: 'நட்பு',
        value2_desc: 'அர்த்தமுள்ள நட்பு மூலம் பாலங்களை கட்டுதல்',
        value3_title: 'மனிதநேயம்',
        value3_desc: 'இரக்கம் மற்றும் அர்ப்பணிப்புடன் மனிதகுலத்திற்கு சேவை செய்தல்',
        journey: 'எங்கள் பயணம்',
        milestone1: '1995 மார்ச் 12 அன்று மும்பையில் அன்பு, நட்பு மற்றும் மனிதநேயத்தால் ஒன்றிணைந்த பேனா நண்பர்களால் IPL நிறுவப்பட்டது',
        milestone2: 'பம்பாய் சங்கங்கள் சட்டம், 1950 மற்றும் பம்பாய் பொது அறக்கட்டளை சட்டத்தின் கீழ் பதிவு செய்யப்பட்டது',
        milestone3: 'பிரிவு 80ஜி சான்றிதழ் வழங்கப்பட்டு இந்தியா மற்றும் வெளிநாடுகளில் மனிதநேய சேவைகள் விரிவுபடுத்தப்பட்டன',
        join_us: 'எங்கள் பணியில் இணையுங்கள்',
        join_desc: 'நட்பு மற்றும் மனிதநேயத்தின் சக்தியை நம்பும் சமூகத்தின் ஒரு பகுதியாக இருங்கள்'
    },
    news: {
        badge: 'சமீபத்திய புதுப்பிப்புகள்',
        title: 'செய்திகள் & நிகழ்வுகள்',
        subtitle: 'IPL சமூகத்தின் சமீபத்திய நிகழ்வுகள், மைல் கற்கள் மற்றும் கொண்டாட்டங்கள்',
        search_placeholder: 'நிகழ்வுகளை தேடு...',
        view_grid: 'கட்டம்',
        view_timeline: 'நாட்காட்டி',
        featured: 'சிறப்பு நிகழ்வுகள்',
        featured_sub: 'சமீபத்திய தாக்கமுள்ள நிகழ்வுகள்',
        new_badge: 'புதியது',
        more_info: 'மேலும் தகவல்',
        view_details: 'விவரங்களைப் பார்க்க',
        all_events: 'அனைத்து நிகழ்வுகள்',
        all_events_sub: 'கட்டம் அல்லது நாட்காட்டி காட்சியில் உலாவவும். தலைப்பு, விளக்கம் அல்லது இடம் மூலம் வடிகட்டவும்.'
    },
    pagination: {
        prev: 'முந்தையது',
        next: 'அடுத்தது'
    },
    meet: {
        badge: 'ஆண்டுதோறும் விழா',
        title: 'நட்புச் சங்கமம்',
        subtitle_native: 'நட்புச் சங்கமம்',
        subtitle: 'எழுத்துக்கள் நெடுங்கால பந்தங்களாக மாறும் இடம்',
        what_title: 'நட்புச் சங்கமம் என்றால் என்ன?',
        what_desc: 'உலகம் முழுதும் உள்ள பேனா நண்பர்கள் நேரில் சந்தித்து, கடிதங்களால் உருவான பந்தங்களை கொண்டாடும் ஆண்டு திருவிழா.',
        past_title: 'ஆண்டுதோறும் நட்புச் சங்கமங்கள்',
        past_sub: 'ஆண்டாண்டு பயணத்தை ஆராயுங்கள்',
        badge_small: 'ஆண்டு சங்கமம்',
        upcoming: 'வரவிருக்கும்',
        highlight1: {
            title: 'பேனா நண்பர்களைச் சந்திக்க',
            desc: 'ஆண்டுகளாக நீங்கள் எழுதி வரும் நண்பர்களை சந்திக்கவும்'
        },
        highlight2: {
            title: 'குடும்ப ஒன்று கூடல்',
            desc: 'குடும்பத்துடன் சேர்ந்து கொண்டாடுங்கள்'
        },
        highlight3: {
            title: 'கலாசார பரிமாற்றம்',
            desc: 'பல்வேறு பண்பாட்டு மரபுகளை அனுபவிக்கவும்'
        },
        highlight4: {
            title: 'நினைவில் நிற்கும் தருணங்கள்',
            desc: 'நினைவுகளையும் நட்புகளையும் உருவாக்குங்கள்'
        },
        28: {
            title: '28ஆம் நட்புச் சங்கமம்',
            date: '24 மே 2025',
            location: 'பின்னர் அறிவிக்கப்படும்',
            desc: 'இந்தியாவிலும் வெளிநாடுகளிலும் உள்ள நண்பர்களை ஒன்றிணைக்கும் 28ஆம் ஆண்டு சங்கமம்'
        },
        27: {
            title: '27ஆம் நட்புச் சங்கமம்',
            date: '25 மே 2024',
            location: 'குட்டாலம், தென்காசி',
            desc: 'TMNS மண்டபம், குட்டாலத்தில் நடைபெற்ற 27ஆம் ஆண்டு சங்கமம்'
        },
        26: {
            title: '26ஆம் நட்புச் சங்கமம்',
            date: '20 மே 2023',
            location: 'புதுதில்லி',
            desc: 'ஸ்ரீ வித்தல் மந்திர் மண்டபம், ராமகிருஷ்ணபுரம், புதுதில்லி'
        },
        friends_day_title: 'சர்வதேச நண்பர்கள் தின கொண்டாட்டங்கள்',
        activities_highlight: 'செயல்பாடுகள் & சிறப்பம்சங்கள்',
        participants: 'பங்கேற்பாளர்கள்',
        stat_meets_held: 'நடத்தப்பட்ட சந்திப்புகள்',
        stat_participants: 'பங்கேற்பாளர்கள்',
        stat_cities: 'நடைபெற்ற நகரங்கள்',
        stat_years: 'பாரம்பரிய ஆண்டுகள்',
        stat_active_members: 'செயலில் உள்ள உறுப்பினர்கள்',
        stat_regional_branches: 'மண்டல கிளைகள்',
        stat_countries: 'பிரதிநிதித்துவப்படுத்தும் நாடுகள்',
        past_meet_1_title: '27வது நட்புச் சங்கமம்',
        past_meet_1_location: 'குட்டாலம், தென்காசி',
        past_meet_1_desc: 'TMNS மண்டபத்தில் பிரம்மாண்டமான கலாச்சார நிகழ்வுகளுடன் நடைபெற்றது.',
        past_meet_2_title: '26வது நட்புச் சங்கமம்',
        past_meet_2_location: 'புதுதில்லி',
        past_meet_2_desc: 'ஸ்ரீ வித்தல் மந்திர் மண்டபத்தில் சிறப்பு கூட்டம்.',
        past_meet_3_title: '25வது வெள்ளி விழா சந்திப்பு',
        past_meet_3_location: 'திருநெல்வேலி',
        past_meet_3_desc: 'வரலாற்று சிறப்புமிக்க வருகையுடன் வெள்ளி விழா கொண்டாட்டம்.',
        stats: {
            meets: 'ஆண்டு சந்திப்புகள்',
            attendees: 'பங்கேற்பாளர்கள்',
            cities: 'நகரங்கள்',
            years: 'ஆண்டுகள்'
        }
    },
    profile: {
        hero: {
            title: 'ஐபிஎல் சுருக்கம்',
            subtitle: '1995 முதல் அன்பு, நட்பு மற்றும் மனிதநேயத்தை பரப்புகிறோம்'
        },
        intro: {
            title: 'எங்கள் பயணத்தைப் பற்றி',
            desc: 'இந்தியப் பேனாநண்பர் பேரவை என்பது அன்பு, நட்பு மற்றும் மனிதநேயத்திற்காக அர்ப்பணிக்கப்பட்ட நண்பர்களின் கூட்டமைப்பு.'
        },
        inception: {
            title: 'பேரவையின் துவக்கம்',
            desc: 'அன்பு, நட்பு, மனிதநேய சிந்தனைகளால் செழுமையடைந்த இதயங்கள், சாதி, மத மற்றும் அரசியல் வேறுபாடுகளை நீக்குகின்றன.'
        },
        growth: {
            title: 'பேரவையின் வளர்ச்சி',
            desc: 'தமிழகத்தின் அனைத்து மாவட்டங்கள் மற்றும் கேரளா, கர்நாடகா, கோவா, டெல்லி, அஸ்ஸாம் மாநிலங்கள் மற்றும் பிரான்ஸ், ஆஸ்திரேலியா, யுஏஇ போன்ற நாடுகளில் விரிவடைந்தது.'
        },
        humanitarian: {
            title: 'பேரவையின் சமூகநல செயல்பாடுகள்',
            desc: 'மராட்டிய மாநில அரசின் கீழ் சமூக நல அறக்கட்டளையாக பதிவு செய்யப்பட்டு, தேவைப்படுவோருக்கு மனிதநேய உதவிகளை வழங்குகிறது.'
        },
        friendshipMeet: {
            title: 'நட்புச் சங்கம விழாக்கள் (Friendship Meet)'
        },
        notableGuests: {
            title: 'நட்புச்சங்கம விழா, பங்கேற்ற சான்றோர் பெருமக்கள்'
        },
        education: {
            title: 'கல்விப் பணி, மருத்துவ உதவி'
        },
        achievements: {
            title: 'எங்கள் சாதனைகள்',
            eyeCamps: 'கண் பரிசோதனை முகாம்கள்',
            meetings: 'நட்புச் சங்கமங்கள்',
            states: 'மாநிலங்கள்',
            years: 'ஆண்டுகள் சேவை'
        },
        cta: {
            title: 'எங்கள் நோக்கத்தில் சேருங்கள்',
            desc: 'அன்பு, நட்பு மற்றும் மனிதநேயத்தை பரப்பும் எங்கள் பயணத்தில் பங்கேற்க',
            contact: 'எங்களைத் தொடர்பு கொள்ளுங்கள்',
            services: 'எங்கள் சேவைகள்'
        }
    },
    history: {
        hero: {
            title: 'வரலாறு',
            subtitle: 'அன்பு, நட்பு மற்றும் மனிதநேய சேவையின் பயணம்'
        },
        intro: {
            title: 'பேரவை வழித்தடங்கள்',
            desc: 'ஏறக்குறைய மூன்று தசாப்தங்களாக மனிதநேய சேவை மற்றும் கலாசார பாதுகாப்பின் பாரம்பரியம்'
        },
        timeline: {
            title: 'முக்கிய மைல்கற்கள்'
        },
        milestones: {
            gujarat: '2001 - குஜராத் பூகம்ப நிவாரணம்',
            gujaratDesc: 'பூகம்ப பாதிக்கப்பட்டவர்களுக்கு நிவாரண மையம் அமைத்து நிதி திரட்டியது (ஜனவரி 27 - பிப்ரவரி 2, 2001)',
            tsunami: '2005 - சுனாமி நிவாரணம்',
            tsunamiDesc: 'தமிழகக் கடலோர பகுதிகளில் சுனாமி பாதிக்கப்பட்டவர்களுக்கு உணவு, உடை மற்றும் நிவாரண பொருட்களை நேரடியாக வழங்கியது',
            paris: '2007 - பாரிஸ் அங்கீகாரம்',
            parisDesc: 'பாரிஸில் மகாகவி பாரதியார் 125வது ஆண்டு விழாவில் சிறப்பு விருந்தினர், மும்பை தமிழ் அமைப்புகளைப் பிரதிநிதித்துவம்',
            gandhi: '2011 - காந்தி சிலை திறப்பு',
            gandhiDesc: 'பாரிஸில் மகாத்மா காந்தி சிலை திறப்பு விழாவில் பங்கேற்று, ஆபர்வில்லியர்ஸ் மேயரால் கெளரவிக்கப்பட்டது'
        },
        gujarat: {
            title: 'குஜராத் பூகம்ப நிவாரணம்'
        },
        tsunami: {
            title: 'சுனாமி நிவாரண நடவடிக்கைகள்'
        },
        publications: {
            title: 'இலக்கிய பங்களிப்புகள்',
            adhigalai: '"அதிகாலை" - காலை',
            idhayam: '"இதயத்துடிப்பு" - இதயத் துடிப்பு',
            karaiaerum: '"கரையேறும் அலைகள்" - கரையை நோக்கிய அலைகள்',
            unarvugal: '"உணர்வுகள்" - உணர்ச்சிகள்',
            seppadu: '"செப்பேடு" - செப்புத்தகடு',
            kamarajar: '"காமராஜர் காவியம்" - காமராஜர் காவியம் (1050 பக்கங்கள்)'
        },
        international: {
            title: 'சர்வதேச அங்கீகாரம்',
            paris2007: 'பாரிஸ் - பாரதியார் 125வது ஆண்டு விழா (2007)',
            paris2011: 'பாரிஸ் - காந்தி சிலை திறப்பு (2011)',
            srilanka: 'இலங்கை - தமிழ் இதழ்கள் மாநாடு'
        },
        global: {
            title: 'உலகளாவிய தமிழ் வலையமைப்பு'
        },
        cta: {
            title: 'ஐபிஎல் பற்றி மேலும் அறிக',
            desc: 'எங்கள் பயணத்தை கண்டுபிடித்து எங்கள் நோக்கத்தில் சேருங்கள்',
            profile: 'சுருக்கத்தைப் பார்க்க',
            events: 'நிகழ்வுகளைப் பார்க்க'
        }
    },
    blog: {
        hero: {
            title: 'ஐபிஎல் தலைவரின் வலைபதிவு',
            subtitle: 'எங்கள் தலைவரிடமிருந்து புதுப்பிப்புகள், சாதனைகள் மற்றும் சிந்தனைகள்'
        },
        intro: {
            title: 'தலைவரின் வலைபதிவு',
            desc: 'ஐபிஎல் செயல்பாடுகள் மற்றும் சாதனைகள் குறித்த எங்கள் தலைவரின் சமீபத்திய புதுப்பிப்புகள் மற்றும் சிந்தனைகள்'
        },
        featured: {
            title: 'சிறப்பு இடுகைகள்'
        },
        allPosts: {
            title: 'அனைத்து இடுகைகள்'
        },
        readMore: 'மேலும் படிக்க',
        pagination: {
            previous: 'முந்தையது',
            next: 'அடுத்தது'
        },
        posts: {
            silverJubilee: {
                title: 'ஐபிஎல் வெள்ளி விழா ஆண்டு: 1995 - 2020',
                desc: 'அன்பு, நட்பு மற்றும் மனிதநேய சேவையின் 25 ஆண்டுகளைக் கொண்டாடுதல்'
            },
            friendship27: {
                title: '27ஆம் நட்புச் சங்கமம்',
                desc: '27வது நட்புச் சங்கமம் - இந்தியா மற்றும் வெளிநாடுகளிலிருந்து நண்பர்களின் ஆண்டு கூட்டம்'
            },
            pongal2024: {
                title: 'தமிழர் திருநாள் 2024 நல்வாழ்த்துக்கள்',
                desc: 'பொங்கல் திருநாள் வாழ்த்துக்கள் 2024'
            },
            souvenir2023: {
                title: 'ஐபிஎல் நினைவு தொகுப்புகள் - 2023',
                desc: '2023 ஆம் ஆண்டு ஐபிஎல் நினைவு தொகுப்புகளின் அட்டைப் படம்'
            },
            isroVisit: {
                title: 'இஸ்ரோ தலைவர் சந்திப்பு',
                desc: 'ஐபிஎல் தலைவர் திரு. மா. கருண் முன்னாள் இஸ்ரோ தலைவரைச் சந்தித்தார்'
            },
            agm19: {
                title: '19வது பொதுக்குழு அறிவிப்பு - மே 2022',
                desc: 'இந்தியப் பேனாநண்பர் பேரவையின் 19வது ஆண்டு பொதுக் கூட்ட அறிவிப்பு'
            },
            secretaryWedding: {
                title: 'பொதுச்செயலாளர் இல்ல விழா',
                desc: 'பொதுச்செயலாளர் ஜெ. ஜான் கென்னடிக்கு இல்ல விழா வாழ்த்துக்கள்'
            },
            calendar2022: {
                title: 'ஐபிஎல் நாட்காட்டி 2022 வெளியீடு',
                desc: 'தலைமை அலுவலகத்தில் ஐபிஎல் நாட்காட்டி 2022 வெளியிடப்பட்டது'
            },
            cmLetter: {
                title: 'முதலமைச்சருக்கு கடிதம் - வேலை உதவி',
                desc: 'ஐபிஎல் உறுப்பினர் குடும்பத்திற்கு அரசு நிவாரண உதவி கோரிக்கை'
            },
            hajTravel: {
                title: 'முதலமைச்சருக்கு கடிதம் - ஹஜ் பயண கோரிக்கை',
                desc: 'ஹஜ் புனிதப் பயணிகளுக்கு சென்னை விமான நிலையத்தை சேர்க்குமாறு தமிழக முதலமைச்சருக்கு கடிதம்'
            },
            diaspora: {
                title: 'புலம்பெயர் தமிழர் நல வாரியம் பாராட்டு',
                desc: 'புலம்பெயர் தமிழர் நல வாரியத்தை அறிவித்த தமிழக முதலமைச்சருக்கு பாராட்டு'
            },
            lifetimeAward: {
                title: 'வாழ்நாள் சாதனையாளர் விருது',
                desc: 'சமூக சேவை பங்களிப்புகளுக்காக திரு. மா. கருண் வாழ்நாள் சாதனையாளர் விருது பெறுகிறார்'
            },
            chancellor: {
                title: 'பல்கலைக்கழக வேந்தர் சந்திப்பு',
                desc: 'பல்கலைக்கழக வேந்தருடன் ஐபிஎல் தலைவர் சந்திப்பு - 2018'
            },
            airport: {
                title: 'சென்னை விமான நிலையம் கடிதம் - பிப்ரவரி 2021',
                desc: 'சென்னை விமான நிலைய பொது மேலாளருடன் கடித தொடர்பு'
            },
            pongal2020: {
                title: 'தமிழர் திருநாள் 2020 நல்வாழ்த்துக்கள்',
                desc: 'பொங்கல் திருநாள் வாழ்த்துக்கள் 2020'
            },
            covidRelief: {
                title: 'கோவிட்-19 நிவாரண நிதி பங்களிப்பு',
                desc: 'விஐடி நிறுவனர்-தலைவரால் முதலமைச்சர் நிவாரண நிதி பங்களிப்பு'
            },
            chessAcademy: {
                title: 'ஐபிஎல் செஸ் அகாடமி - ஒரு பார்வை',
                desc: 'ஐபிஎல் செஸ் அகாடமி முன்முயற்சிகளின் கண்ணோட்டம்'
            },
            souvenir2019: {
                title: 'விஐபிக்கு ஐபிஎல் நினைவுப் பரிசு - 2019',
                desc: '2019 இல் விஐபி விருந்தினர்களுக்கு வழங்கப்பட்ட ஐபிஎல் நினைவுப் பரிசு'
            }
        },
        highlights: {
            title: 'குறிப்பிடத்தக்க சிறப்பம்சங்கள்',
            award: {
                title: 'வாழ்நாள் சாதனையாளர் விருது'
            },
            isro: {
                title: 'இஸ்ரோ தலைவர் சந்திப்பு'
            },
            calendar: {
                title: 'ஆண்டு நாட்காட்டி வெளியீடு'
            },
            jubilee: {
                title: 'வெள்ளி விழா கொண்டாட்டம்'
            }
        },
        cta: {
            title: 'புதுப்பித்த நிலையில் இருங்கள்',
            desc: 'எங்கள் சமீபத்திய செயல்பாடுகள் மற்றும் சாதனைகளைப் பின்பற்றவும்',
            news: 'சமீபத்திய செய்திகள்'
        }
    }
};
const __TURBOPACK__default__export__ = translations;
}),
"[project]/IPL-Website-test-main/src/i18n/translations.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Re-export existing JS translations with a permissive type to enable gradual typing.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
// Import the JS dictionary (allowed via allowJs in tsconfig)
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - JS module without types
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$i18n$2f$translations$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/i18n/translations.js [app-ssr] (ecmascript)");
;
const dict = __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$i18n$2f$translations$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = dict;
}),
"[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TranslationProvider",
    ()=>TranslationProvider,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useTranslation",
    ()=>useTranslation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$i18n$2f$translations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/i18n/translations.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
const TranslationContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const TranslationProvider = ({ children })=>{
    // Use a stable, deterministic initial language for SSR + first client render
    const [lang, setLang] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('en');
    // After mount, read persisted preference and update. This avoids SSR/client mismatch.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        try {
            const stored = localStorage.getItem('ipl_lang');
            if (stored) {
                setTimeout(()=>setLang(stored), 0);
            }
        } catch  {}
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        try {
            localStorage.setItem('ipl_lang', String(lang));
        } catch  {}
        try {
            if (typeof document !== 'undefined') {
                const el = document.documentElement;
                el.setAttribute('lang', String(lang));
                el.classList.toggle('lang-ta', String(lang) === 'ta');
            }
        } catch  {}
    }, [
        lang
    ]);
    const t = (key, fallback)=>{
        if (!key) return '';
        const parts = key.split('.');
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let cur = __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$i18n$2f$translations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"][String(lang)];
        for (const p of parts){
            if (!cur) break;
            cur = cur[p];
        }
        if (cur == null) return fallback ?? key;
        return String(cur);
    };
    const setLanguage = (l)=>setLang(l);
    const toggleLanguage = ()=>{
        setLang((s)=>{
            if (s === 'en') return 'ta';
            return 'en';
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TranslationContext.Provider, {
        value: {
            lang,
            setLanguage,
            toggleLanguage,
            t
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx",
        lineNumber: 69,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const useTranslation = ()=>{
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(TranslationContext);
    if (!ctx) {
        // This makes hook usage outside the provider clear in development while keeping runtime safe.
        throw new Error('useTranslation must be used within a TranslationProvider');
    }
    return ctx;
};
const __TURBOPACK__default__export__ = TranslationContext;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/IPL-Website-test-main/src/data/searchIndex.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildSearchIndex",
    ()=>buildSearchIndex,
    "scoreEntries",
    ()=>scoreEntries,
    "searchSuggestions",
    ()=>searchSuggestions
]);
// Accent/diacritic normalization for robust matching
const normalize = (str)=>str.toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[\u0300-\u036f]/g, '');
function buildSearchIndex() {
    // News/events (static subset; consider dynamic import later)
    const news = [
        {
            id: 136,
            date: '22 DEC',
            year: '2024',
            title: 'Chennai Regional Branch Friends Meeting',
            location: 'Moovarasampettai, Chennai',
            description: 'Chennai Regional Branch Friends Meeting'
        },
        {
            id: 135,
            date: '25 MAY',
            year: '2024',
            title: '27th Friendship Meet',
            location: 'Kuttalam',
            description: '27th Friendship Meet at TMNS Hall, Kuttalam, Tenkasi District'
        },
        {
            id: 134,
            date: '03 MAR',
            year: '2024',
            title: 'IPL Chess Academy Festival',
            location: 'Pavoorchathiram',
            description: 'IPL Chess Academy - Chess Festival, Pavoorchathiram'
        },
        {
            id: 133,
            date: '24 FEB',
            year: '2024',
            title: 'Kanyakumari District Branch Friends Meeting',
            location: 'Kanyakumari',
            description: 'Kanyakumari District Branch Friends Meeting at Devadas Sweet Home Hall'
        },
        {
            id: 132,
            date: '11 FEB',
            year: '2024',
            title: "27th Friendship Meet - President's Announcement",
            location: 'India',
            description: "Indian Penpals' League, Mumbai"
        },
        {
            id: 131,
            date: '20 JAN',
            year: '2024',
            title: 'Krishnagiri Regional Branch Friends Meeting',
            location: 'Hosur',
            description: 'St. John Bosco Girls Higher Secondary School - Hosur'
        },
        {
            id: 130,
            date: '12 JAN',
            year: '2024',
            title: 'Tamil Nadu Government NRI Tamil Day Celebration',
            location: 'Tamil Nadu',
            description: 'Tamil Nadu Government NRI Tamil Day - Award to IPL President'
        },
        {
            id: 129,
            date: '30 DEC',
            year: '2023',
            title: 'IPL Chess Tournament',
            location: 'Mumbai',
            description: 'Chess tournament organized by IPL Chess Academy with Mumbai District Chess Association'
        },
        {
            id: 128,
            date: '17 DEC',
            year: '2023',
            title: 'Cash Prize for Tamil Nadu Kho-Kho Players',
            location: 'Tamil Nadu',
            description: 'National Kho-Kho Championship - Cash prizes for Tamil Nadu women players'
        },
        {
            id: 125,
            date: '19 DEC',
            year: '2023',
            title: 'Thiruvalluvar Statue Inauguration',
            location: 'Paris, France',
            description: 'Thiruvalluvar Statue Inauguration - Cergy, Paris, France'
        },
        {
            id: 127,
            date: '16 JUL',
            year: '2023',
            title: 'Chennai District Branch Friends Discussion',
            location: 'Chennai',
            description: 'Distribution of school uniforms and educational materials by Chennai District Branch'
        },
        {
            id: 124,
            date: '25 JUN',
            year: '2023',
            title: 'Thirukkural as Indian National Book - International Conference',
            location: 'New Delhi',
            description: 'International Conference on Thirukkural as Indian National Book - New Delhi'
        },
        {
            id: 126,
            date: '26 JUN',
            year: '2023',
            title: 'IPL Chess Academy Tournament',
            location: 'Pavoorchathiram, Tenkasi',
            description: 'IPL Chess Academy tournament, Pavoorchathiram, Tenkasi District'
        }
    ].map((n)=>({
            title: n.title,
            subtitle: `${n.date} ${n.year} • ${n.location}`,
            href: `/news-events?highlight=${n.title.replace(/[^a-z0-9]+/gi, '-')}`,
            keywords: [
                n.description,
                n.location,
                n.date,
                n.year,
                'news',
                'event'
            ]
        }));
    const meets = [
        {
            title: '28th Friendship Meet',
            subtitle: '2025 • Upcoming',
            href: '/friendship-meet',
            keywords: [
                'friendship',
                'meet',
                'upcoming',
                'annual',
                '28th',
                'நட்பு',
                'சங்கமம்'
            ]
        },
        {
            title: '27th Friendship Meet',
            subtitle: '2024 • Kuttalam',
            href: '/friendship-meet',
            keywords: [
                'friendship',
                'meet',
                '2024',
                'kuttalam',
                '27th'
            ]
        },
        {
            title: '26th Friendship Meet',
            subtitle: '2023 • New Delhi',
            href: '/friendship-meet',
            keywords: [
                'friendship',
                'meet',
                '2023',
                'delhi',
                '26th'
            ]
        },
        {
            title: 'International Friendship Day',
            subtitle: 'Friends Day Celebrations',
            href: '/friendship-meet',
            keywords: [
                'friends',
                'day',
                'international',
                'august',
                'celebration',
                'நட்பு தினம்'
            ]
        }
    ];
    const humanitarian = [
        {
            title: 'Medical Assistance',
            subtitle: 'Humanitarian Service',
            href: '/humanitarian-services',
            keywords: [
                'medical',
                'assistance',
                'humanitarian',
                'support',
                'health'
            ]
        },
        {
            title: 'Educational Support',
            subtitle: 'Humanitarian Service',
            href: '/humanitarian-services',
            keywords: [
                'education',
                'students',
                'scholarship',
                'school'
            ]
        },
        {
            title: 'Food & Clothing',
            subtitle: 'Humanitarian Service',
            href: '/humanitarian-services',
            keywords: [
                'food',
                'clothing',
                'donation',
                'relief'
            ]
        },
        {
            title: 'Livelihood Support',
            subtitle: 'Humanitarian Service',
            href: '/humanitarian-services',
            keywords: [
                'livelihood',
                'support',
                'family',
                'employment'
            ]
        },
        {
            title: 'Blood Donation',
            subtitle: 'Humanitarian Service',
            href: '/humanitarian-services',
            keywords: [
                'blood',
                'donation',
                'camp',
                'lives'
            ]
        },
        {
            title: 'Community Service',
            subtitle: 'Humanitarian Service',
            href: '/humanitarian-services',
            keywords: [
                'community',
                'service',
                'welfare',
                'social'
            ]
        }
    ];
    const staticPages = [
        {
            title: 'About Us',
            subtitle: 'Organisation Info',
            href: '/about/ipl-profile',
            keywords: [
                'about',
                'journey',
                'values',
                'mission',
                'organization'
            ]
        },
        {
            title: 'IPL Profile',
            subtitle: 'About Us',
            href: '/about/ipl-profile',
            keywords: [
                'profile',
                'inception',
                'league',
                'achievements',
                'பேரவை'
            ]
        },
        {
            title: 'History',
            subtitle: 'Our Journey',
            href: '/about/history',
            keywords: [
                'history',
                'milestones',
                'journey',
                'legacy',
                'வரலாறு'
            ]
        },
        {
            title: "IPL President's Blog",
            subtitle: 'Updates & Reflections',
            href: '/about/ipl-presidents-blog',
            keywords: [
                'president',
                'blog',
                'updates',
                'achievements',
                'தலைவர்'
            ]
        },
        {
            title: 'Contact',
            subtitle: 'Reach Out',
            href: '/contact',
            keywords: [
                'contact',
                'email',
                'phone',
                'mumbai',
                'address'
            ]
        },
        {
            title: 'Our Team',
            subtitle: 'Leadership & Volunteers',
            href: '/our-team',
            keywords: [
                'team',
                'leadership',
                'volunteers',
                'trustees',
                'committee'
            ]
        },
        {
            title: 'Homepage',
            subtitle: 'Indian Penpals\' League',
            href: '/',
            keywords: [
                'home',
                'league',
                'indian',
                'penpals',
                'love',
                'friendship',
                'humanity'
            ]
        },
        {
            title: 'News & Events',
            subtitle: 'Latest Updates',
            href: '/news-events',
            keywords: [
                'news',
                'events',
                'updates',
                'activities',
                'செய்திகள்'
            ]
        },
        {
            title: 'Humanitarian Services',
            subtitle: 'Community Support',
            href: '/humanitarian-services',
            keywords: [
                'humanitarian',
                'services',
                'community',
                'help',
                'மனிதநேய சேவைகள்'
            ]
        }
    ];
    return [
        ...news,
        ...meets,
        ...humanitarian,
        ...staticPages
    ];
}
function scoreEntries(entries, query) {
    const qNorm = normalize(query);
    return entries.map((e)=>{
        const hay = normalize(e.title + ' ' + (e.subtitle || '') + ' ' + e.keywords.join(' '));
        let score = 0;
        if (hay.includes(qNorm)) score += 5;
        if (normalize(e.title).startsWith(qNorm)) score += 5;
        if (normalize(e.title) === qNorm) score += 10;
        // keyword weighting
        e.keywords.forEach((k)=>{
            if (normalize(k).includes(qNorm)) score += 2;
        });
        return {
            ...e,
            score
        };
    }).filter((e)=>e.score && e.score > 0).sort((a, b)=>b.score - a.score);
}
function searchSuggestions(query, limit = 8) {
    if (!query.trim()) return [];
    return scoreEntries(buildSearchIndex(), query).slice(0, limit);
}
}),
"[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-ssr] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$data$2f$searchIndex$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/data/searchIndex.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
const GlobalSearchInner = ({ className = '', placeholder, autoFocus = false, onSelect, variant = 'default' })=>{
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const initial = (searchParams.get('q') || '').trim();
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initial);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(-1);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (autoFocus && inputRef.current) inputRef.current.focus();
    }, [
        autoFocus
    ]);
    const suggestions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (!query.trim()) return [];
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$data$2f$searchIndex$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["searchSuggestions"])(query, 8);
    }, [
        query
    ]);
    const commitSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((value)=>{
        const val = value.trim();
        if (!val) {
            // Clear parameter only if already on results page
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            setOpen(false);
            setActiveIndex(-1);
            return;
        }
        // If not on results page, redirect to unified results page with query
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        // Already on results page: update query param in place
        const params = new URLSearchParams(window.location.search);
        params.set('q', val);
        router.replace(`/news-events?${params.toString()}`);
        setQuery(val);
        setOpen(false);
        setActiveIndex(-1);
    }, [
        router
    ]);
    const handleSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((href, title)=>{
        // Navigate directly to the selected page
        if (onSelect) {
            onSelect(href, title);
        }
        router.push(href);
        setQuery('');
        setOpen(false);
        setActiveIndex(-1);
    }, [
        onSelect,
        router
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const onClickAway = (e)=>{
            if (!containerRef.current) return;
            if (!containerRef.current.contains(e.target)) setOpen(false);
        };
        document.addEventListener('mousedown', onClickAway);
        return ()=>document.removeEventListener('mousedown', onClickAway);
    }, []);
    const highlight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((text)=>{
        const qLower = query.toLowerCase();
        const idx = text.toLowerCase().indexOf(qLower);
        if (idx === -1 || !query) return text;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                text.slice(0, idx),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("mark", {
                    className: "bg-red-100 text-red-700 rounded px-0.5",
                    children: text.slice(idx, idx + query.length)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                    lineNumber: 97,
                    columnNumber: 29
                }, ("TURBOPACK compile-time value", void 0)),
                text.slice(idx + query.length)
            ]
        }, void 0, true);
    }, [
        query
    ]);
    const baseInputClasses = variant === 'mobile' ? 'w-full pl-11 pr-4 py-3 rounded-xl bg-red-700/40 text-white placeholder-white/70 border border-white/10 hover:border-white/20 focus:ring-2 focus:ring-white/40 outline-none' : variant === 'hero' ? 'w-full pl-11 pr-4 py-3 rounded-full bg-white border border-neutral-200 shadow-sm focus:border-red-600 focus:ring-2 focus:ring-red-100 outline-none text-sm transition' : 'w-56 xl:w-64 pl-9 pr-10 py-2.5 rounded-full bg-white/10 border border-white/20 text-sm text-white placeholder-white/70 hover:border-white/30 focus:bg-white/15 focus:ring-2 focus:ring-white/30 focus:border-white/40 shadow-sm transition-all outline-none';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: `relative ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                className: `absolute ${variant === 'mobile' ? 'left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/70' : variant === 'hero' ? 'left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400' : 'left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/70'} pointer-events-none`
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ref: inputRef,
                value: query,
                onChange: (e)=>{
                    const newValue = e.target.value;
                    setQuery(newValue);
                    setOpen(newValue.trim().length > 0);
                    setActiveIndex(-1);
                },
                onFocus: ()=>{
                    if (query.trim().length > 0) {
                        setOpen(true);
                    }
                },
                onKeyDown: (e)=>{
                    if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        setActiveIndex((i)=>Math.min(suggestions.length - 1, i + 1));
                    } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        setActiveIndex((i)=>Math.max(-1, i - 1));
                    } else if (e.key === 'Enter') {
                        if (activeIndex >= 0 && suggestions[activeIndex]) {
                            handleSelect(suggestions[activeIndex].href, suggestions[activeIndex].title);
                        } else {
                            commitSearch(query);
                        }
                    } else if (e.key === 'Escape') {
                        setOpen(false);
                    }
                },
                placeholder: placeholder || t('search.placeholder', 'Search the site...'),
                className: baseInputClasses,
                autoComplete: "off"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            open && query.trim().length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: `absolute left-0 right-0 ${variant === 'mobile' ? 'mt-3' : 'mt-2'} bg-white border border-neutral-200 rounded-xl shadow-2xl overflow-hidden z-[100] text-sm animate-fade-in max-h-96 overflow-y-auto`,
                role: "listbox",
                children: suggestions.length > 0 ? suggestions.map((s, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        role: "option",
                        "aria-selected": activeIndex === i,
                        tabIndex: -1,
                        onMouseDown: (e)=>e.preventDefault(),
                        onClick: ()=>handleSelect(s.href, s.title),
                        className: `px-4 py-3 cursor-pointer flex flex-col gap-0.5 ${activeIndex === i ? 'bg-red-50' : 'hover:bg-neutral-50'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-semibold text-neutral-900 leading-tight",
                                children: highlight(s.title)
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                                lineNumber: 157,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0)),
                            s.subtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-neutral-500 text-xs flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                        className: "w-3 h-3 text-red-600"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                                        lineNumber: 160,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    " ",
                                    highlight(s.subtitle)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                                lineNumber: 159,
                                columnNumber: 19
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, s.href + i, true, {
                        fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                        lineNumber: 148,
                        columnNumber: 15
                    }, ("TURBOPACK compile-time value", void 0))) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    className: "px-4 py-6 text-center text-sm text-neutral-500 flex flex-col gap-2",
                    role: "option",
                    "aria-selected": "false",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-medium text-neutral-700",
                            children: t('search.no_results', 'No matches found')
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                            lineNumber: 167,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-neutral-400",
                            children: [
                                t('search.suggestions', 'Suggestions'),
                                ": ",
                                t('search.clear', 'Clear'),
                                " / ",
                                t('search.popular', 'Popular Searches')
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                            lineNumber: 168,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                    lineNumber: 166,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                lineNumber: 145,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
        lineNumber: 109,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const GlobalSearch = (props)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: props.className || '',
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "text",
                    placeholder: props.placeholder || 'Search...',
                    disabled: true,
                    className: "w-full opacity-50"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                    lineNumber: 182,
                    columnNumber: 11
                }, void 0)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
                lineNumber: 181,
                columnNumber: 9
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
            lineNumber: 180,
            columnNumber: 7
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(GlobalSearchInner, {
            ...props
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
            lineNumber: 191,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx",
        lineNumber: 179,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = GlobalSearch;
}),
"[project]/IPL-Website-test-main/src/components/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/menu.js [app-ssr] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/globe.js [app-ssr] (ecmascript) <export default as Globe>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$components$2f$ui$2f$GlobalSearch$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const Header = ()=>{
    const { lang, toggleLanguage, t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const [mobileMenuOpen, setMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [scrolled, setScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [scrollProgress, setScrollProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [expandedMobileMenu, setExpandedMobileMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleScroll = ()=>{
            setScrolled(window.scrollY > 20);
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = winScroll / height * 100;
            setScrollProgress(scrolled);
        };
        window.addEventListener('scroll', handleScroll);
        return ()=>window.removeEventListener('scroll', handleScroll);
    }, []);
    const navLinks = [
        {
            path: '/',
            label: 'nav.home'
        },
        {
            path: '/about',
            label: 'nav.about',
            hasDropdown: true,
            dropdownItems: [
                {
                    path: '/about/ipl-profile',
                    label: 'nav.iplProfile'
                },
                {
                    path: '/about/history',
                    label: 'nav.history'
                },
                {
                    path: '/about/ipl-presidents-blog',
                    label: 'nav.presidentBlog'
                }
            ]
        },
        {
            path: '/our-team',
            label: 'nav.team'
        },
        {
            path: '/humanitarian-services',
            label: 'nav.humanitarian'
        },
        {
            path: '/news-events',
            label: 'nav.news',
            hasDropdown: true,
            dropdownItems: [
                {
                    path: '/news-events',
                    label: 'nav.iplNews'
                },
                {
                    path: '/friendship-meet',
                    label: 'nav.meet'
                }
            ]
        },
        {
            path: '/contact',
            label: 'nav.contact'
        }
    ];
    const isActive = (path)=>pathname === path;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white w-full py-3 border-b border-zinc-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative h-10 md:h-16 w-full md:w-auto flex justify-center md:justify-start",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/Images/header/1.png",
                                alt: "Indian Penpals League Tamil",
                                className: "h-full w-auto object-contain"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                lineNumber: 71,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                            lineNumber: 70,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative h-10 md:h-16 w-full md:w-auto flex justify-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/Images/header/2.png",
                                alt: "Indian Penpals League English",
                                className: "h-full w-auto object-contain"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                lineNumber: 78,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative h-10 md:h-16 w-full md:w-auto flex justify-center md:justify-end",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/Images/header/3.png",
                                alt: "80G Certified",
                                className: "h-full w-auto object-contain"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                lineNumber: 85,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                            lineNumber: 84,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                    lineNumber: 69,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: `sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-red-900/95 backdrop-blur-md shadow-lg py-2' : 'bg-red-800 py-4'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-0 left-0 h-1 bg-yellow-400 transition-all duration-150 ease-out",
                        style: {
                            width: `${scrollProgress}%`
                        }
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                        lineNumber: 98,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container mx-auto px-4 flex items-center justify-between gap-2 max-w-screen-2xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                className: "hidden lg:flex items-center gap-1 flex-nowrap shrink min-w-0 flex-1 justify-center",
                                children: navLinks.map((link)=>link.hasDropdown ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative group/dropdown h-full flex items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: `
                    relative px-3 py-2 text-xs xl:text-sm font-medium transition-all duration-300 shrink whitespace-nowrap max-w-[110px] xl:max-w-none group cursor-pointer bg-transparent border-0
                    ${isActive(link.path) ? 'text-white' : 'text-white/80 hover:text-white'}
                  `,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `
                      absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-400 rounded-full transition-all duration-300 ease-out
                      ${isActive(link.path) ? 'w-4/5 opacity-100 shadow-sm shadow-yellow-400/50' : 'w-0 opacity-0 group-hover/dropdown:w-4/5 group-hover/dropdown:opacity-100'}
                    `
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                        lineNumber: 120,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `
                      absolute inset-0 rounded-lg transition-all duration-300
                      ${isActive(link.path) ? 'bg-white/10 shadow-inner' : 'bg-transparent group-hover/dropdown:bg-white/5'}
                    `
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                        lineNumber: 129,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "relative z-10 flex items-center gap-1",
                                                        children: [
                                                            t(link.label),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                                className: "w-3 h-3 transition-transform duration-300 group-hover/dropdown:rotate-180"
                                                            }, void 0, false, {
                                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                                lineNumber: 139,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                        lineNumber: 137,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                lineNumber: 111,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute top-full left-0 pt-2 opacity-0 scale-95 invisible group-hover/dropdown:opacity-100 group-hover/dropdown:scale-100 group-hover/dropdown:visible transition-all duration-200 ease-out",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-white rounded-lg shadow-2xl border border-neutral-200 py-1 min-w-[220px]",
                                                    children: link.dropdownItems?.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                            href: item.path,
                                                            className: "block px-4 py-3 text-sm text-neutral-700 hover:bg-red-50 hover:text-red-700 transition-colors font-medium",
                                                            children: t(item.label)
                                                        }, item.path, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                            lineNumber: 146,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)))
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                    lineNumber: 144,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                lineNumber: 143,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, link.path, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                        lineNumber: 110,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: link.path,
                                        className: `
                  relative px-3 py-2 text-xs xl:text-sm font-medium transition-all duration-300 shrink whitespace-nowrap overflow-hidden text-ellipsis max-w-[110px] xl:max-w-none group
                  ${isActive(link.path) ? 'text-white' : link.path === '/contact' ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-red-900 hover:from-yellow-300 hover:to-yellow-400 hover:scale-105 hover:shadow-lg hover:shadow-yellow-400/30 rounded-full font-bold px-4' : 'text-white/80 hover:text-white'}
                `,
                                        children: [
                                            link.path !== '/contact' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `
                      absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-400 rounded-full transition-all duration-300 ease-out
                      ${isActive(link.path) ? 'w-4/5 opacity-100 shadow-sm shadow-yellow-400/50' : 'w-0 opacity-0 group-hover:w-4/5 group-hover:opacity-100'}
                    `
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                lineNumber: 172,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            link.path !== '/contact' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `
                      absolute inset-0 rounded-lg transition-all duration-300
                      ${isActive(link.path) ? 'bg-white/10 shadow-inner' : 'bg-transparent group-hover:bg-white/5'}
                    `
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                lineNumber: 183,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "relative z-10",
                                                children: t(link.label)
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                lineNumber: 192,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, link.path, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                        lineNumber: 158,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                lineNumber: 107,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1.5 relative z-50 shrink-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "hidden xl:flex items-center group relative shrink-0",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$components$2f$ui$2f$GlobalSearch$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "default",
                                            placeholder: t('header.search_placeholder', 'Search...'),
                                            onSelect: ()=>setMobileMenuOpen(false)
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                            lineNumber: 202,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                        lineNumber: 201,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleLanguage,
                                        className: "flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-white transition-all duration-300 group shrink-0",
                                        title: "Switch Language",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__["Globe"], {
                                                className: "w-3.5 h-3.5 text-white/80 group-hover:text-white group-hover:rotate-12 transition-all duration-300"
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                lineNumber: 215,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-bold uppercase min-w-6 text-center",
                                                children: lang
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                lineNumber: 216,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                        lineNumber: 210,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setMobileMenuOpen(!mobileMenuOpen),
                                        className: "lg:hidden p-2 rounded-full text-white hover:bg-white/10 transition-colors active:scale-95",
                                        "aria-label": "Toggle mobile menu",
                                        children: mobileMenuOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                            className: "w-6 h-6"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                            lineNumber: 227,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                            className: "w-6 h-6"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                            lineNumber: 227,
                                            columnNumber: 61
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                        lineNumber: 222,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `
          lg:hidden fixed inset-0 z-40 bg-linear-to-b from-red-900 to-red-950 text-white backdrop-blur-xl transition-all duration-500 ease-in-out
          ${mobileMenuOpen ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-full pointer-events-none'}
        `,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col h-full pt-24 pb-10 px-6 overflow-y-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-8",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$components$2f$ui$2f$GlobalSearch$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "mobile",
                                        placeholder: t('header.search_placeholder', 'Search...'),
                                        onSelect: ()=>setMobileMenuOpen(false)
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                        lineNumber: 242,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                    lineNumber: 241,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                    className: "flex flex-col gap-2 flex-1",
                                    children: navLinks.map((link, idx)=>link.hasDropdown ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "animate-in slide-in-from-right-8 fade-in duration-500",
                                            style: {
                                                animationDelay: `${idx * 50}ms`
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setExpandedMobileMenu(expandedMobileMenu === link.path ? null : link.path),
                                                    className: `
                      w-full flex items-center justify-between px-5 py-4 rounded-2xl text-lg font-medium transition-all
                      ${isActive(link.path) ? 'bg-white text-red-900 shadow-lg' : 'text-white/90 hover:bg-white/5 border border-transparent hover:border-white/10'}
                    `,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: t(link.label)
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                            lineNumber: 262,
                                                            columnNumber: 23
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                            className: `w-5 h-5 transition-transform duration-300 ${expandedMobileMenu === link.path ? 'rotate-180' : ''}`
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                            lineNumber: 263,
                                                            columnNumber: 23
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                    lineNumber: 253,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                expandedMobileMenu === link.path && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-2 ml-4 space-y-2",
                                                    children: link.dropdownItems?.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                            href: item.path,
                                                            onClick: ()=>setMobileMenuOpen(false),
                                                            className: `
                            block px-5 py-3 rounded-xl text-base font-medium transition-all
                            ${isActive(item.path) ? 'bg-white/20 text-white' : 'text-white/80 hover:bg-white/10'}
                          `,
                                                            children: t(item.label)
                                                        }, item.path, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                            lineNumber: 268,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0)))
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                                    lineNumber: 266,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, link.path, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                            lineNumber: 252,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: link.path,
                                            onClick: ()=>setMobileMenuOpen(false),
                                            className: `
                    block px-5 py-4 rounded-2xl text-lg font-medium transition-all animate-in slide-in-from-right-8 fade-in duration-500
                    ${isActive(link.path) ? 'bg-white text-red-900 shadow-lg scale-[1.02]' : 'text-white/90 hover:bg-white/5 border border-transparent hover:border-white/10'}
                  `,
                                            style: {
                                                animationDelay: `${idx * 50}ms`
                                            },
                                            children: t(link.label)
                                        }, link.path, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                            lineNumber: 286,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                    lineNumber: 249,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-8 pt-8 border-t border-white/10 text-center text-white/40 text-sm",
                                    children: [
                                        "© ",
                                        new Date().getFullYear(),
                                        " Indian Penpals' League"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                                    lineNumber: 304,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                        lineNumber: 233,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/components/Header.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = Header;
}),
"[project]/IPL-Website-test-main/src/components/Footer.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/mail.js [app-ssr] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/phone.js [app-ssr] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-ssr] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/facebook.js [app-ssr] (ecmascript) <export default as Facebook>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/twitter.js [app-ssr] (ecmascript) <export default as Twitter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/instagram.js [app-ssr] (ecmascript) <export default as Instagram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$linkedin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Linkedin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/linkedin.js [app-ssr] (ecmascript) <export default as Linkedin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
'use client';
;
;
;
;
const Footer = ()=>{
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTranslation"])();
    const currentYear = new Date().getFullYear();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "bg-neutral-900 text-neutral-300 pt-12 sm:pt-16 md:pt-20 pb-8 sm:pb-10",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container-custom mx-auto px-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10 md:gap-12 mb-12 sm:mb-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4 sm:space-y-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    className: "block group",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/Images/image copy.png",
                                        alt: "Indian Penpals' League",
                                        className: "h-12 sm:h-14 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                        lineNumber: 21,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 20,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-neutral-400 leading-relaxed text-sm sm:text-base",
                                    children: t('footer.about_text', 'Love, Friendship & Humanity — A confederation of friends united to serve communities.')
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 27,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-4",
                                    children: [
                                        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__["Facebook"],
                                        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__["Twitter"],
                                        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__["Instagram"],
                                        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$linkedin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Linkedin$3e$__["Linkedin"]
                                    ].map((Icon, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "#",
                                            className: "w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-400 hover:bg-red-700 hover:text-white transition-all duration-300 hover:-translate-y-1",
                                            "aria-label": `Social media link ${i + 1}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                lineNumber: 38,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, i, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                            lineNumber: 32,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 30,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-white font-bold text-base sm:text-lg mb-4 sm:mb-6",
                                    children: t('nav.about', 'About Us')
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 46,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "space-y-3",
                                    children: [
                                        {
                                            to: '/about/ipl-profile',
                                            label: 'nav.iplProfile'
                                        },
                                        {
                                            to: '/about/history',
                                            label: 'nav.history'
                                        },
                                        {
                                            to: '/about/ipl-presidents-blog',
                                            label: 'nav.presidentBlog'
                                        },
                                        {
                                            to: '/our-team',
                                            label: 'nav.team'
                                        },
                                        {
                                            to: '/humanitarian-services',
                                            label: 'nav.humanitarian'
                                        }
                                    ].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: link.to,
                                                className: "flex items-center gap-2 text-neutral-400 hover:text-red-400 transition-colors group text-sm",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                        className: "w-3 h-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all"
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                        lineNumber: 60,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    t(link.label)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                lineNumber: 56,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, link.to, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                            lineNumber: 55,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 47,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                            lineNumber: 45,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-white font-bold text-base sm:text-lg mb-4 sm:mb-6",
                                    children: t('nav.news', 'News & Events')
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "space-y-3",
                                    children: [
                                        {
                                            to: '/news-events',
                                            label: 'nav.iplNews'
                                        },
                                        {
                                            to: '/friendship-meet',
                                            label: 'nav.meet'
                                        },
                                        {
                                            to: '/contact',
                                            label: 'nav.contact'
                                        }
                                    ].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: link.to,
                                                className: "flex items-center gap-2 text-neutral-400 hover:text-red-400 transition-colors group text-sm",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                        className: "w-3 h-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all"
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                        lineNumber: 82,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    t(link.label)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                lineNumber: 78,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, link.to, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                            lineNumber: 77,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 71,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-white font-bold text-base sm:text-lg mb-4 sm:mb-6",
                                    children: t('footer.contact_us', 'Contact Us')
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 92,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                    className: "w-5 h-5 text-red-600 shrink-0 mt-1"
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                    lineNumber: 95,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-neutral-400 text-sm leading-relaxed",
                                                    children: [
                                                        "103, Starview Apts., Opp. Corporate Park,",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                            lineNumber: 97,
                                                            columnNumber: 60
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        "V.N.Purav Marg, Chembur,",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                            lineNumber: 98,
                                                            columnNumber: 43
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        "Mumbai - 400071, India"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                            lineNumber: 94,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                    className: "w-5 h-5 text-red-600 shrink-0"
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                    lineNumber: 103,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "tel:+919892035187",
                                                    className: "text-neutral-400 hover:text-red-300 transition-colors text-sm",
                                                    children: "+91 9892035187"
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                    lineNumber: 104,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                            lineNumber: 102,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                    className: "w-5 h-5 text-red-600 shrink-0"
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                    lineNumber: 109,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "mailto:iplmumbai12395@gmail.com",
                                                    className: "text-neutral-400 hover:text-red-300 transition-colors text-sm break-all",
                                                    children: "iplmumbai12395@gmail.com"
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                                    lineNumber: 110,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                            lineNumber: 108,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 93,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                            lineNumber: 91,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pt-8 border-t border-neutral-800 flex flex-col md:flex-row items-center justify-between gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-500 text-sm text-center md:text-left",
                            children: [
                                "© ",
                                currentYear,
                                " Indian Penpals' League. ",
                                t('footer.rights', 'All Rights Reserved'),
                                "."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                            lineNumber: 120,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-6 text-sm text-neutral-500",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    className: "hover:text-white transition-colors",
                                    children: t('nav.home', 'Home')
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 124,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/contact",
                                    className: "hover:text-white transition-colors",
                                    children: t('nav.contact', 'Contact')
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                                    lineNumber: 125,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                            lineNumber: 123,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
                    lineNumber: 119,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/IPL-Website-test-main/src/components/Footer.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Footer;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__75f42800._.js.map