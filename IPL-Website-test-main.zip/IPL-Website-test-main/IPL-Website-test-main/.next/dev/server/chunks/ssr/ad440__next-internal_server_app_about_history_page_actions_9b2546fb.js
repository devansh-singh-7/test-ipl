module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/about/history/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ad440__next-internal_server_app_about_history_page_actions_9b2546fb.js.map