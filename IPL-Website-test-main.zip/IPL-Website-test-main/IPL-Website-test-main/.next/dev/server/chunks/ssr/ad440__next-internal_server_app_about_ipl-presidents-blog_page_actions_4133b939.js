module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/about/ipl-presidents-blog/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ad440__next-internal_server_app_about_ipl-presidents-blog_page_actions_4133b939.js.map