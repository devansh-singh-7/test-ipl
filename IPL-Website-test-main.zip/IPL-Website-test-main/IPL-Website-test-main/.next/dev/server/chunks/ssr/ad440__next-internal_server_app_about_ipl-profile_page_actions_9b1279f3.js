module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/about/ipl-profile/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ad440__next-internal_server_app_about_ipl-profile_page_actions_9b1279f3.js.map