module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/friendship-meet/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ad440__next-internal_server_app_friendship-meet_page_actions_08db5459.js.map