module.exports = [
"[project]/IPL-Website-test-main/.next-internal/server/app/humanitarian-services/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ad440__next-internal_server_app_humanitarian-services_page_actions_3efc92fb.js.map