globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/37e5c_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0c6914c5._.js",
    "static/chunks/37e5c_next_dist_compiled_react-dom_0b6d7e55._.js",
    "static/chunks/37e5c_next_dist_compiled_react-server-dom-turbopack_afa62141._.js",
    "static/chunks/37e5c_next_dist_compiled_next-devtools_index_14c236d5.js",
    "static/chunks/37e5c_next_dist_compiled_cae6c787._.js",
    "static/chunks/37e5c_next_dist_client_e25d376a._.js",
    "static/chunks/37e5c_next_dist_907caf49._.js",
    "static/chunks/37e5c_@swc_helpers_cjs_64bc6208._.js",
    "static/chunks/IPL-Website-test-main_a0ff3932._.js",
    "static/chunks/turbopack-IPL-Website-test-main_731011a4._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];