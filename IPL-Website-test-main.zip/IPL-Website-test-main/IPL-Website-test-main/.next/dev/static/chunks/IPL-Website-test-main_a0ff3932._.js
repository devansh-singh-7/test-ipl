(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0c6914c5._.js",
  "static/chunks/37e5c_next_dist_compiled_react-dom_0b6d7e55._.js",
  "static/chunks/37e5c_next_dist_compiled_react-server-dom-turbopack_afa62141._.js",
  "static/chunks/37e5c_next_dist_compiled_next-devtools_index_14c236d5.js",
  "static/chunks/37e5c_next_dist_compiled_cae6c787._.js",
  "static/chunks/37e5c_next_dist_client_e25d376a._.js",
  "static/chunks/37e5c_next_dist_907caf49._.js",
  "static/chunks/37e5c_@swc_helpers_cjs_64bc6208._.js"
],
    source: "entry"
});
