(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>IPLProfilePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript) <export default as Globe>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript) <export default as CheckCircle>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function IPLProfilePage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(124);
    if ($[0] !== "2e90b1b110af9d31a86e54e38aa205c0ecbb04f69f9ba0bfb4e9ada954987885") {
        for(let $i = 0; $i < 124; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2e90b1b110af9d31a86e54e38aa205c0ecbb04f69f9ba0bfb4e9ada954987885";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [
            {
                title: "Eye Camps",
                titleTa: "\u0B95\u0BA3\u0BCD \u0BAE\u0BC1\u0B95\u0BBE\u0BAE\u0BCD\u0B95\u0BB3\u0BCD",
                count: "31+",
                icon: "\uD83D\uDC41\uFE0F",
                color: "from-blue-500 to-cyan-600"
            },
            {
                title: "Friendship Meets",
                titleTa: "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
                count: "28+",
                icon: "\uD83E\uDD1D",
                color: "from-red-500 to-rose-600"
            },
            {
                title: "States Reached",
                titleTa: "\u0BAE\u0BBE\u0BA8\u0BBF\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
                count: "15+",
                icon: "\uD83D\uDDFA\uFE0F",
                color: "from-emerald-500 to-teal-600"
            },
            {
                title: "Years of Service",
                titleTa: "\u0B9A\u0BC7\u0BB5\u0BC8 \u0B86\u0BA3\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD",
                count: "30+",
                icon: "\uD83C\uDF89",
                color: "from-amber-500 to-orange-600"
            }
        ];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const achievements = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [
            {
                title: "Bombay Societies Act, 1950",
                detail: "Registered as a Social Welfare Trust",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"]
            },
            {
                title: "Bombay Public Trust Act",
                detail: "Registration #F23778",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"]
            },
            {
                title: "Section 80G Certificate",
                detail: "Tax benefit for donors",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"]
            },
            {
                title: "Social Welfare Trust",
                detail: "Serving communities since 1995",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"]
            }
        ];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const registrations = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [
            {
                year: "1995",
                location: "Mumbai (Inauguration)",
                locationTa: "\u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8 (\u0BA4\u0BC1\u0BB5\u0B95\u0BCD\u0B95 \u0BB5\u0BBF\u0BB4\u0BBE)"
            },
            {
                year: "1996",
                location: "Thanjavur",
                locationTa: "\u0BA4\u0B9E\u0BCD\u0B9A\u0BBE\u0BB5\u0BC2\u0BB0\u0BCD"
            },
            {
                year: "1997",
                location: "Kolar Gold Fields",
                locationTa: "\u0B95\u0BCB\u0BB2\u0BBE\u0BB0\u0BCD \u0BA4\u0B99\u0BCD\u0B95 \u0BB5\u0BAF\u0BB2\u0BCD"
            },
            {
                year: "1998",
                location: "Chennai",
                locationTa: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8"
            },
            {
                year: "1999",
                location: "Karur",
                locationTa: "\u0B95\u0BB0\u0BC2\u0BB0\u0BCD"
            },
            {
                year: "2000",
                location: "Senkam",
                locationTa: "\u0B9A\u0BC6\u0B99\u0BCD\u0B95\u0BAE\u0BCD"
            },
            {
                year: "2010",
                location: "Coimbatore",
                locationTa: "\u0B95\u0BCB\u0BB5\u0BC8"
            },
            {
                year: "2019",
                location: "Namakkal",
                locationTa: "\u0BA8\u0BBE\u0BAE\u0B95\u0BCD\u0B95\u0BB2\u0BCD"
            },
            {
                year: "2023",
                location: "New Delhi",
                locationTa: "\u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF"
            },
            {
                year: "2024",
                location: "Kuttalam",
                locationTa: "\u0B95\u0BC1\u0B9F\u0BCD\u0B9F\u0BBE\u0BB2\u0BAE\u0BCD"
            }
        ];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const friendshipMeets = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            minHeight: "280px"
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 z-0 pointer-events-none",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: "/Images/iplbanner.png",
                    alt: "IPL Profile background",
                    className: "w-[85%] h-full opacity-40 object-contain mx-auto",
                    style: {
                        objectPosition: "center"
                    }
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 133,
                    columnNumber: 68
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: "absolute",
                        inset: 0,
                        backgroundColor: "rgba(0,0,0,0.04)"
                    }
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 135,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 133,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-red-100 shadow-sm mb-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                    className: "w-4 h-4 text-red-700"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 146,
                    columnNumber: 127
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-semibold tracking-wider uppercase text-red-800",
                    children: "About IPL"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 146,
                    columnNumber: 169
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 146,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== t) {
        t6 = t("profile.hero.title", "IPL Profile");
        $[7] = t;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-4xl sm:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6 leading-tight",
            children: t6
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 161,
            columnNumber: 10
        }, this);
        $[9] = t6;
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== t) {
        t8 = t("profile.hero.subtitle", "Spreading Love, Friendship & Humanity Since 1995");
        $[11] = t;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg sm:text-xl text-neutral-600 max-w-2xl mx-auto leading-relaxed",
            children: t8
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 177,
            columnNumber: 10
        }, this);
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center gap-4 mt-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-px w-16 bg-gradient-to-r from-transparent to-red-300"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 185,
                    columnNumber: 72
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-red-700 font-semibold",
                    children: "Est. March 12, 1995"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 185,
                    columnNumber: 146
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-px w-16 bg-gradient-to-l from-transparent to-red-300"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 185,
                    columnNumber: 217
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 185,
            columnNumber: 11
        }, this);
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] !== t7 || $[17] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative bg-transparent pt-8 sm:pt-12 md:pt-16 lg:pt-20 pb-6 sm:pb-8 overflow-hidden",
            style: t3,
            children: [
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative z-10 container-custom mx-auto text-center px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-4xl mx-auto",
                        children: [
                            t5,
                            t7,
                            t9,
                            t10
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 192,
                        columnNumber: 205
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 192,
                    columnNumber: 132
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 192,
            columnNumber: 11
        }, this);
        $[16] = t7;
        $[17] = t9;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-16 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 md:grid-cols-4 gap-6",
                        children: achievements.map(_IPLProfilePageAchievementsMap)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 201,
                        columnNumber: 122
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 201,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 201,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 201,
            columnNumber: 11
        }, this);
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    let t13;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-red-50 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 208,
                columnNumber: 105
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[20] = t13;
    } else {
        t13 = $[20];
    }
    let t14;
    if ($[21] !== t) {
        t14 = t("profile.inception.title", "Inception of the League");
        $[21] = t;
        $[22] = t14;
    } else {
        t14 = $[22];
    }
    let t15;
    if ($[23] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t13,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
                    children: t14
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 223,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        $[23] = t14;
        $[24] = t15;
    } else {
        t15 = $[24];
    }
    let t16;
    if ($[25] !== t) {
        t16 = t("profile.inception.desc", "Hearts enriched with love, friendship, and humanitarian thoughts, eliminating caste, religious, and political differences - this is the Indian Penpals League, a beautiful friendship world.");
        $[25] = t;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-neutral-700 leading-relaxed mb-6",
            children: t16
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 239,
            columnNumber: 11
        }, this);
        $[27] = t16;
        $[28] = t17;
    } else {
        t17 = $[28];
    }
    let t18;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6 bg-red-50 rounded-2xl border-l-4 border-red-600",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-neutral-700 italic leading-relaxed",
                children: "அன்பு, நட்பு, மனிதநேய சிந்தனைகளால் செழுமையடைந்த இதயங்கள், சாதி, மத மற்றும் அரசியல் வேறுபாடுகளை நீக்கி - இது இந்தியப் பேனாநண்பர் பேரவை, ஒரு அழகான நட்புலகம்."
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 247,
                columnNumber: 80
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 247,
            columnNumber: 11
        }, this);
        $[29] = t18;
    } else {
        t18 = $[29];
    }
    let t19;
    if ($[30] !== t17) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-3xl p-8 sm:p-12 shadow-sm border border-neutral-100",
            children: [
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 254,
            columnNumber: 11
        }, this);
        $[30] = t17;
        $[31] = t19;
    } else {
        t19 = $[31];
    }
    let t20;
    if ($[32] !== t15 || $[33] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto",
                    children: [
                        t15,
                        t19
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 262,
                    columnNumber: 92
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 262,
                columnNumber: 52
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 262,
            columnNumber: 11
        }, this);
        $[32] = t15;
        $[33] = t19;
        $[34] = t20;
    } else {
        t20 = $[34];
    }
    let t21;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-14 h-14 bg-amber-50 rounded-xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__["Globe"], {
                className: "w-7 h-7 text-amber-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 271,
                columnNumber: 106
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[35] = t21;
    } else {
        t21 = $[35];
    }
    let t22;
    if ($[36] !== t) {
        t22 = t("profile.growth.title", "\u0BAA\u0BC7\u0BB0\u0BB5\u0BC8\u0BAF\u0BBF\u0BA9\u0BCD \u0BB5\u0BB3\u0BB0\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF");
        $[36] = t;
        $[37] = t22;
    } else {
        t22 = $[37];
    }
    let t23;
    if ($[38] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-6",
            children: t22
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 286,
            columnNumber: 11
        }, this);
        $[38] = t22;
        $[39] = t23;
    } else {
        t23 = $[39];
    }
    let t24;
    let t25;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-neutral-600 leading-relaxed mb-6",
            children: 'With the noble vision that "good friends create a good nation," the league has grown tremendously across India and abroad.'
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 295,
            columnNumber: 11
        }, this);
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-700 leading-relaxed italic",
            children: "நல்ல நண்பர்கள் உருவானால் நல்ல நாடு தானாகவே உருவாகும் என்ற உயரிய நோக்கத்தின் அசுரவளர்ச்சியாய் தமிழகத்தின் அனைத்து மாவட்டங்களிலும் விரிந்துள்ளது."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 296,
            columnNumber: 11
        }, this);
        $[40] = t24;
        $[41] = t25;
    } else {
        t24 = $[40];
        t25 = $[41];
    }
    let t26;
    if ($[42] !== t23) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t21,
                t23,
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 305,
            columnNumber: 11
        }, this);
        $[42] = t23;
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    let t27;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-xl font-bold text-neutral-900 mb-6",
            children: "Presence In"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 313,
            columnNumber: 11
        }, this);
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-gradient-to-br from-amber-50 to-orange-50 rounded-3xl p-8 border border-amber-100",
            children: [
                t27,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-2 gap-4",
                    children: [
                        "Tamil Nadu",
                        "Kerala",
                        "Karnataka",
                        "Goa",
                        "New Delhi",
                        "Assam",
                        "France",
                        "Australia",
                        "UAE"
                    ].map(_IPLProfilePageAnonymous)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 320,
                    columnNumber: 118
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 320,
            columnNumber: 11
        }, this);
        $[45] = t28;
    } else {
        t28 = $[45];
    }
    let t29;
    if ($[46] !== t26) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid md:grid-cols-2 gap-12 items-center",
                        children: [
                            t26,
                            t28
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 327,
                        columnNumber: 122
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 327,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 327,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 327,
            columnNumber: 11
        }, this);
        $[46] = t26;
        $[47] = t29;
    } else {
        t29 = $[47];
    }
    let t30;
    if ($[48] !== t) {
        t30 = t("about.registration_title", "Registration & Recognition");
        $[48] = t;
        $[49] = t30;
    } else {
        t30 = $[49];
    }
    let t31;
    if ($[50] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold mb-4",
            children: t30
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 343,
            columnNumber: 11
        }, this);
        $[50] = t30;
        $[51] = t31;
    } else {
        t31 = $[51];
    }
    let t32;
    if ($[52] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-400 max-w-xl mx-auto",
            children: "Officially registered and recognized for our humanitarian work."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 351,
            columnNumber: 11
        }, this);
        $[52] = t32;
    } else {
        t32 = $[52];
    }
    let t33;
    if ($[53] !== t31) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t31,
                t32
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 358,
            columnNumber: 11
        }, this);
        $[53] = t31;
        $[54] = t33;
    } else {
        t33 = $[54];
    }
    let t34;
    if ($[55] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid sm:grid-cols-2 gap-6",
            children: registrations.map(_IPLProfilePageRegistrationsMap)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 366,
            columnNumber: 11
        }, this);
        $[55] = t34;
    } else {
        t34 = $[55];
    }
    let t35;
    if ($[56] !== t33) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-900 text-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: [
                        t33,
                        t34
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 373,
                    columnNumber: 104
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 373,
                columnNumber: 64
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 373,
            columnNumber: 11
        }, this);
        $[56] = t33;
        $[57] = t35;
    } else {
        t35 = $[57];
    }
    let t36;
    if ($[58] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-white rounded-2xl shadow-sm mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 381,
                columnNumber: 114
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 381,
            columnNumber: 11
        }, this);
        $[58] = t36;
    } else {
        t36 = $[58];
    }
    let t37;
    if ($[59] !== t) {
        t37 = t("profile.humanitarian.title", "\u0BAA\u0BC7\u0BB0\u0BB5\u0BC8\u0BAF\u0BBF\u0BA9\u0BCD \u0B9A\u0BAE\u0BC2\u0B95\u0BA8\u0BB2 \u0B9A\u0BC6\u0BAF\u0BB2\u0BCD\u0BAA\u0BBE\u0B9F\u0BC1\u0B95\u0BB3\u0BCD");
        $[59] = t;
        $[60] = t37;
    } else {
        t37 = $[60];
    }
    let t38;
    if ($[61] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
            children: t37
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 396,
            columnNumber: 11
        }, this);
        $[61] = t37;
        $[62] = t38;
    } else {
        t38 = $[62];
    }
    let t39;
    if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-600 max-w-2xl mx-auto",
            children: "Humanitarian Services that touch lives across communities."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 404,
            columnNumber: 11
        }, this);
        $[63] = t39;
    } else {
        t39 = $[63];
    }
    let t40;
    if ($[64] !== t38) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t36,
                t38,
                t39
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 411,
            columnNumber: 11
        }, this);
        $[64] = t38;
        $[65] = t40;
    } else {
        t40 = $[65];
    }
    let t41;
    if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: "எழுத்தால் இணைந்த இதயங்கள் அன்பு, நட்பு, மனிதநேயச் சிந்தனைகளைக் கடிதங்கள் மூலம் பகிர்ந்து கொண்ட நிலையில் பேரவை சமூக நல அறக்கட்டளையாகப் பதிவு செய்யப்பட்டு மனிதநேய உதவிகள் வழங்கப்படுகிறது."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 419,
            columnNumber: 11
        }, this);
        $[66] = t41;
    } else {
        t41 = $[66];
    }
    let t42;
    if ($[67] === Symbol.for("react.memo_cache_sentinel")) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid sm:grid-cols-2 gap-4 not-prose",
            children: [
                "Eye Examination Camps (31+)",
                "ENT Medical Camps",
                "Cancer Awareness Camps",
                "AIDS Awareness Programs",
                "Education Fee Assistance",
                "Medical Aid Support"
            ].map(_IPLProfilePageAnonymous2)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 426,
            columnNumber: 11
        }, this);
        $[67] = t42;
    } else {
        t42 = $[67];
    }
    let t43;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-3xl p-8 sm:p-12 shadow-lg border border-neutral-100",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "prose prose-lg max-w-none text-neutral-700 leading-relaxed space-y-6",
                children: [
                    t41,
                    t42,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-6 bg-amber-50 rounded-2xl border border-amber-200",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-700 m-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    className: "text-amber-800",
                                    children: "Partnership with Aditya Jyot Eye Hospital:"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                                    lineNumber: 433,
                                    columnNumber: 298
                                }, this),
                                " In collaboration with the world-renowned hospital under the guidance of Padma Shri Dr. S. Natarajan, 31 eye examination camps have been conducted in Mumbai slum areas."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                            lineNumber: 433,
                            columnNumber: 262
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 433,
                        columnNumber: 193
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 433,
                columnNumber: 97
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 433,
            columnNumber: 11
        }, this);
        $[68] = t43;
    } else {
        t43 = $[68];
    }
    let t44;
    if ($[69] !== t40) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-gradient-to-br from-red-50 to-orange-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: [
                        t40,
                        t43
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 440,
                    columnNumber: 121
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 440,
                columnNumber: 81
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 440,
            columnNumber: 11
        }, this);
        $[69] = t40;
        $[70] = t44;
    } else {
        t44 = $[70];
    }
    let t45;
    if ($[71] === Symbol.for("react.memo_cache_sentinel")) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-red-50 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 448,
                columnNumber: 105
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 448,
            columnNumber: 11
        }, this);
        $[71] = t45;
    } else {
        t45 = $[71];
    }
    let t46;
    if ($[72] !== t) {
        t46 = t("profile.friendshipMeet.title", "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE \u0BB5\u0BBF\u0BB4\u0BBE\u0B95\u0BCD\u0B95\u0BB3\u0BCD");
        $[72] = t;
        $[73] = t46;
    } else {
        t46 = $[73];
    }
    let t47;
    if ($[74] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
            children: t46
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 463,
            columnNumber: 11
        }, this);
        $[74] = t46;
        $[75] = t47;
    } else {
        t47 = $[75];
    }
    let t48;
    if ($[76] === Symbol.for("react.memo_cache_sentinel")) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-600 max-w-2xl mx-auto",
            children: "28+ successful Friendship Meets across India since 1995."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 471,
            columnNumber: 11
        }, this);
        $[76] = t48;
    } else {
        t48 = $[76];
    }
    let t49;
    if ($[77] !== t47) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t45,
                t47,
                t48
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 478,
            columnNumber: 11
        }, this);
        $[77] = t47;
        $[78] = t49;
    } else {
        t49 = $[78];
    }
    let t50;
    if ($[79] === Symbol.for("react.memo_cache_sentinel")) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4",
            children: friendshipMeets.map(_IPLProfilePageFriendshipMeetsMap)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 486,
            columnNumber: 11
        }, this);
        $[79] = t50;
    } else {
        t50 = $[79];
    }
    let t51;
    if ($[80] === Symbol.for("react.memo_cache_sentinel")) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-neutral-50 rounded-3xl p-8 sm:p-12 border border-neutral-100",
            children: [
                t50,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 text-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: "/friendship-meet",
                        className: "inline-flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-full font-semibold hover:bg-red-700 transition-colors",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                                lineNumber: 493,
                                columnNumber: 295
                            }, this),
                            "View All Friendship Meets"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 493,
                        columnNumber: 131
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 493,
                    columnNumber: 97
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 493,
            columnNumber: 11
        }, this);
        $[80] = t51;
    } else {
        t51 = $[80];
    }
    let t52;
    if ($[81] !== t49) {
        t52 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: [
                        t49,
                        t51
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 500,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 500,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 500,
            columnNumber: 11
        }, this);
        $[81] = t49;
        $[82] = t52;
    } else {
        t52 = $[82];
    }
    let t53;
    if ($[83] === Symbol.for("react.memo_cache_sentinel")) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-purple-50 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                className: "w-8 h-8 text-purple-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 508,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 508,
            columnNumber: 11
        }, this);
        $[83] = t53;
    } else {
        t53 = $[83];
    }
    let t54;
    if ($[84] !== t) {
        t54 = t("profile.notableGuests.title", "Notable Guests");
        $[84] = t;
        $[85] = t54;
    } else {
        t54 = $[85];
    }
    let t55;
    if ($[86] !== t54) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t53,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
                    children: t54
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 523,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 523,
            columnNumber: 11
        }, this);
        $[86] = t54;
        $[87] = t55;
    } else {
        t55 = $[87];
    }
    let t56;
    if ($[88] === Symbol.for("react.memo_cache_sentinel")) {
        t56 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-neutral-700 leading-relaxed mb-8",
            children: "சரித்திர சாதனையாக நடைபெற்று வரும் நட்புச்சங்கம விழாக்களில் பல்வேறு துறைச் சான்றோர் பெருமக்கள் சிறப்பு விருந்தினராகப் பங்கேற்றுள்ளனர்."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 531,
            columnNumber: 11
        }, this);
        $[88] = t56;
    } else {
        t56 = $[88];
    }
    let t57;
    if ($[89] === Symbol.for("react.memo_cache_sentinel")) {
        t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-3xl p-8 sm:p-12 shadow-sm border border-neutral-100",
            children: [
                t56,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid sm:grid-cols-2 gap-4",
                    children: [
                        {
                            name: "R. R. Gopal",
                            title: "Nakkheeran - Journalism Pioneer"
                        },
                        {
                            name: "V. G. Santhosham",
                            title: "Chevalier"
                        },
                        {
                            name: "T. M. Soundararajan",
                            title: "Legendary Playback Singer"
                        },
                        {
                            name: "S. V. Sekar",
                            title: "Actor & Comedian"
                        },
                        {
                            name: "A. L. Srinivasan",
                            title: "Radio Drama Legend"
                        },
                        {
                            name: "S. V. Subramanian",
                            title: "Distinguished Guest"
                        }
                    ].map(_IPLProfilePageAnonymous3)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 538,
                    columnNumber: 102
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 538,
            columnNumber: 11
        }, this);
        $[89] = t57;
    } else {
        t57 = $[89];
    }
    let t58;
    if ($[90] !== t55) {
        t58 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto",
                    children: [
                        t55,
                        t57
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 563,
                    columnNumber: 92
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 563,
                columnNumber: 52
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 563,
            columnNumber: 11
        }, this);
        $[90] = t55;
        $[91] = t58;
    } else {
        t58 = $[91];
    }
    let t59;
    if ($[92] !== t) {
        t59 = t("profile.cta.title", "Join Our Mission");
        $[92] = t;
        $[93] = t59;
    } else {
        t59 = $[93];
    }
    let t60;
    if ($[94] !== t59) {
        t60 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold mb-6",
            children: t59
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 579,
            columnNumber: 11
        }, this);
        $[94] = t59;
        $[95] = t60;
    } else {
        t60 = $[95];
    }
    let t61;
    if ($[96] !== t) {
        t61 = t("profile.cta.desc", "Be part of our journey to spread love, friendship and humanity");
        $[96] = t;
        $[97] = t61;
    } else {
        t61 = $[97];
    }
    let t62;
    if ($[98] !== t61) {
        t62 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xl text-red-100 mb-10 leading-relaxed",
            children: t61
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 595,
            columnNumber: 11
        }, this);
        $[98] = t61;
        $[99] = t62;
    } else {
        t62 = $[99];
    }
    let t63;
    if ($[100] !== t) {
        t63 = t("profile.cta.contact", "Contact Us");
        $[100] = t;
        $[101] = t63;
    } else {
        t63 = $[101];
    }
    let t64;
    if ($[102] !== t63) {
        t64 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/contact",
            className: "px-8 py-4 bg-white text-red-700 rounded-full font-bold shadow-xl hover:bg-amber-50 hover:scale-105 transition-all duration-300",
            children: t63
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 611,
            columnNumber: 11
        }, this);
        $[102] = t63;
        $[103] = t64;
    } else {
        t64 = $[103];
    }
    let t65;
    if ($[104] !== t) {
        t65 = t("profile.cta.services", "Our Services");
        $[104] = t;
        $[105] = t65;
    } else {
        t65 = $[105];
    }
    let t66;
    if ($[106] !== t65) {
        t66 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/humanitarian-services",
            className: "px-8 py-4 bg-transparent text-white border-2 border-white/50 rounded-full font-bold hover:bg-white/10 hover:border-white transition-all duration-300",
            children: t65
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 627,
            columnNumber: 11
        }, this);
        $[106] = t65;
        $[107] = t66;
    } else {
        t66 = $[107];
    }
    let t67;
    if ($[108] !== t64 || $[109] !== t66) {
        t67 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row gap-4 justify-center",
            children: [
                t64,
                t66
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 635,
            columnNumber: 11
        }, this);
        $[108] = t64;
        $[109] = t66;
        $[110] = t67;
    } else {
        t67 = $[110];
    }
    let t68;
    if ($[111] !== t60 || $[112] !== t62 || $[113] !== t67) {
        t68 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-gradient-to-br from-red-700 to-red-800",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-3xl mx-auto text-center text-white",
                    children: [
                        t60,
                        t62,
                        t67
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 644,
                    columnNumber: 120
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 644,
                columnNumber: 80
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 644,
            columnNumber: 11
        }, this);
        $[111] = t60;
        $[112] = t62;
        $[113] = t67;
        $[114] = t68;
    } else {
        t68 = $[114];
    }
    let t69;
    if ($[115] !== t11 || $[116] !== t20 || $[117] !== t29 || $[118] !== t35 || $[119] !== t44 || $[120] !== t52 || $[121] !== t58 || $[122] !== t68) {
        t69 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "min-h-screen bg-neutral-50",
            children: [
                t11,
                t12,
                t20,
                t29,
                t35,
                t44,
                t52,
                t58,
                t68
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 654,
            columnNumber: 11
        }, this);
        $[115] = t11;
        $[116] = t20;
        $[117] = t29;
        $[118] = t35;
        $[119] = t44;
        $[120] = t52;
        $[121] = t58;
        $[122] = t68;
        $[123] = t69;
    } else {
        t69 = $[123];
    }
    return t69;
}
_s(IPLProfilePage, "vu2xTFBfHkv41zWfADiErp1aWcA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = IPLProfilePage;
function _IPLProfilePageAnonymous3(guest, i_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-4 p-4 bg-purple-50 rounded-xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                    className: "w-5 h-5 text-purple-700"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 670,
                    columnNumber: 176
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 670,
                columnNumber: 89
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-bold text-neutral-900",
                        children: guest.name
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 670,
                        columnNumber: 232
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-neutral-500",
                        children: guest.title
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 670,
                        columnNumber: 290
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 670,
                columnNumber: 227
            }, this)
        ]
    }, i_1, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 670,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageFriendshipMeetsMap(meet, index_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-xl p-4 text-center shadow-sm border border-neutral-100 hover:shadow-md hover:-translate-y-1 transition-all duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-2xl font-bold text-red-700 block mb-1",
                children: meet.year
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 673,
                columnNumber: 178
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs text-neutral-500",
                children: meet.location
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 673,
                columnNumber: 257
            }, this)
        ]
    }, index_1, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 673,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageAnonymous2(service, i_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-3 p-4 bg-red-50 rounded-xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                className: "w-5 h-5 text-red-600"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 676,
                columnNumber: 86
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-neutral-700 font-medium",
                children: service
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 676,
                columnNumber: 134
            }, this)
        ]
    }, i_0, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 676,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageRegistrationsMap(item_0, index_0) {
    const Icon = item_0.icon;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center flex-shrink-0",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                        className: "w-6 h-6 text-red-400"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 680,
                        columnNumber: 293
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 680,
                    columnNumber: 194
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-bold text-white mb-1",
                            children: item_0.title
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                            lineNumber: 680,
                            columnNumber: 345
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-400 text-sm",
                            children: item_0.detail
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                            lineNumber: 680,
                            columnNumber: 414
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 680,
                    columnNumber: 340
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 680,
            columnNumber: 154
        }, this)
    }, index_0, false, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 680,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageAnonymous(place, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                className: "w-4 h-4 text-amber-600"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 683,
                columnNumber: 59
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-neutral-700 text-sm font-medium",
                children: place
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 683,
                columnNumber: 104
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 683,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageAchievementsMap(item, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center p-6 bg-neutral-50 rounded-2xl border border-neutral-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-4xl mb-3",
                children: item.icon
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 686,
                columnNumber: 172
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-2",
                children: item.count
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 686,
                columnNumber: 220
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm text-neutral-500 font-medium",
                children: item.title
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 686,
                columnNumber: 308
            }, this)
        ]
    }, index, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 686,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "IPLProfilePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Heart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
            key: "mvr1a0"
        }
    ]
];
const Heart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("heart", __iconNode);
;
 //# sourceMappingURL=heart.js.map
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Heart",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript)");
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Award
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
            key: "1yiouv"
        }
    ],
    [
        "circle",
        {
            cx: "12",
            cy: "8",
            r: "6",
            key: "1vp47v"
        }
    ]
];
const Award = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("award", __iconNode);
;
 //# sourceMappingURL=award.js.map
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript) <export default as Award>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Award",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript)");
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Users
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
            key: "1yyitq"
        }
    ],
    [
        "path",
        {
            d: "M16 3.128a4 4 0 0 1 0 7.744",
            key: "16gr8j"
        }
    ],
    [
        "path",
        {
            d: "M22 21v-2a4 4 0 0 0-3-3.87",
            key: "kshegd"
        }
    ],
    [
        "circle",
        {
            cx: "9",
            cy: "7",
            r: "4",
            key: "nufk8"
        }
    ]
];
const Users = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("users", __iconNode);
;
 //# sourceMappingURL=users.js.map
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Users",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript)");
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Calendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M8 2v4",
            key: "1cmpym"
        }
    ],
    [
        "path",
        {
            d: "M16 2v4",
            key: "4m81vk"
        }
    ],
    [
        "rect",
        {
            width: "18",
            height: "18",
            x: "3",
            y: "4",
            rx: "2",
            key: "1hopcy"
        }
    ],
    [
        "path",
        {
            d: "M3 10h18",
            key: "8toen8"
        }
    ]
];
const Calendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("calendar", __iconNode);
;
 //# sourceMappingURL=calendar.js.map
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Calendar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript)");
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Star
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
            key: "r04s7s"
        }
    ]
];
const Star = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("star", __iconNode);
;
 //# sourceMappingURL=star.js.map
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Star",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript)");
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>CircleCheckBig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M21.801 10A10 10 0 1 1 17 3.335",
            key: "yps3ct"
        }
    ],
    [
        "path",
        {
            d: "m9 11 3 3L22 4",
            key: "1pflzl"
        }
    ]
];
const CircleCheckBig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("circle-check-big", __iconNode);
;
 //# sourceMappingURL=circle-check-big.js.map
}),
"[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript) <export default as CheckCircle>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CheckCircle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=IPL-Website-test-main_f5c40dd3._.js.map