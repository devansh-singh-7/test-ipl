(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/data/humanitarian-events.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "humanitarianEvents",
    ()=>humanitarianEvents
]);
const humanitarianEvents = [
    {
        id: 1,
        title: 'Medical Assistance, Mumbai',
        description: 'Free medical checkup and medicine distribution',
        fullDescription: 'IPL organized a comprehensive medical camp providing free health checkups, diagnostic tests, and essential medicines to underprivileged communities in Mumbai. Our team of volunteer doctors and nurses provided healthcare services to over 200 individuals.',
        date: 'Dec 26, 2024',
        location: 'Mumbai, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'mum',
        image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=60',
        category: 'medical'
    },
    {
        id: 2,
        title: 'Chennai Admin Meeting & Medical Assistance',
        description: 'Medical support combined with administrative coordination',
        fullDescription: 'The Chennai chapter organized an administrative meeting combined with medical assistance outreach. We coordinated regional activities and provided medical support to local communities, ensuring better healthcare access.',
        date: 'Jan 11, 2024',
        location: 'Chennai, Tamil Nadu, India',
        country: 'in',
        state: 'tn',
        district: 'chn',
        image: 'https://images.unsplash.com/photo-1631217314830-4db5b0a55d51?auto=format&fit=crop&w=1200&q=60',
        category: 'medical'
    },
    {
        id: 3,
        title: 'Education Fee Assistance, Bangalore',
        description: 'Scholarship and fee support for underprivileged students',
        fullDescription: 'IPL distributed education fee assistance to 50+ deserving students in Bangalore. This initiative helped ensure that talented but financially constrained children could continue their education without interruption.',
        date: 'Dec 2023',
        location: 'Bangalore, Karnataka, India',
        country: 'in',
        state: 'ka',
        district: 'bng',
        image: 'https://images.unsplash.com/photo-1427504494785-cdaa41e4c5c0?auto=format&fit=crop&w=1200&q=60',
        category: 'education'
    },
    {
        id: 4,
        title: 'School Uniform Distribution - Delhi',
        description: 'Free uniforms for school children',
        fullDescription: 'Distributed school uniforms to 150 children from underprivileged families in Delhi. This helped improve school attendance and boost the confidence of children to attend school regularly.',
        date: 'Nov 2023',
        location: 'Delhi, India',
        country: 'in',
        state: 'dl',
        district: 'cen',
        image: 'https://images.unsplash.com/photo-1503454537688-e0c4feb565a2?auto=format&fit=crop&w=1200&q=60',
        category: 'clothing'
    },
    {
        id: 5,
        title: 'Relief Distribution - Flood Affected Areas',
        description: 'Emergency aid to flood victims',
        fullDescription: 'Provided emergency relief materials including food, water, blankets, and medical supplies to families affected by floods. Our team worked 24/7 to ensure affected families received immediate assistance.',
        date: 'Oct 2023',
        location: 'Pune, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'pune',
        image: 'https://images.unsplash.com/photo-1532996122724-8f3c2cd83c5d?auto=format&fit=crop&w=1200&q=60',
        category: 'relief'
    },
    {
        id: 6,
        title: 'Community Shelter Program',
        description: 'Providing safe housing for homeless',
        fullDescription: 'Established temporary shelters for homeless individuals during winter months. Provided blankets, meals, and basic amenities to ensure dignity and safety for vulnerable populations.',
        date: 'Sep 2023',
        location: 'Coimbatore, Tamil Nadu, India',
        country: 'in',
        state: 'tn',
        district: 'cm',
        image: 'https://images.unsplash.com/photo-1559027615-cd2628902d4a?auto=format&fit=crop&w=1200&q=60',
        category: 'shelter'
    },
    {
        id: 7,
        title: 'Medical Camp - Tirunelveli',
        description: 'Health awareness and free checkups',
        fullDescription: 'Organized a full-day medical camp with specialty doctors providing free consultations and treatments. Conducted health awareness sessions on hygiene, nutrition, and disease prevention.',
        date: 'Aug 2023',
        location: 'Tirunelveli, Tamil Nadu, India',
        country: 'in',
        state: 'tn',
        district: 'tir',
        image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=60',
        category: 'medical'
    },
    {
        id: 8,
        title: 'Skill Training Program - Nashik',
        description: 'Vocational training for youth employment',
        fullDescription: 'Conducted skill development workshops training 100+ youth in various vocational skills including tailoring, computer basics, and entrepreneurship. Helped participants secure employment or start their own ventures.',
        date: 'Jul 2023',
        location: 'Nashik, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'nas',
        image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=60',
        category: 'education'
    },
    {
        id: 9,
        title: 'Water & Sanitation Project',
        description: 'Clean water supply installation',
        fullDescription: 'Installed water purification systems and sanitation facilities in 5 villages. Educated communities on water conservation and proper hygiene practices. Over 1000 people benefited from this initiative.',
        date: 'Jun 2023',
        location: 'Krishnagiri, Tamil Nadu, India',
        country: 'in',
        state: 'tn',
        district: 'kri',
        image: 'https://images.unsplash.com/photo-1532996122724-8f3c2cd83c5d?auto=format&fit=crop&w=1200&q=60',
        category: 'relief'
    },
    {
        id: 10,
        title: 'Orphanage Support Program',
        description: 'Monthly care packages for orphans',
        fullDescription: 'Provided regular support to local orphanages including food, educational materials, clothing, and medical care. Organized recreational activities and mentorship programs for children.',
        date: 'May 2023',
        location: 'Nagpur, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'nag',
        image: 'https://images.unsplash.com/photo-1559027615-cd2628902d4a?auto=format&fit=crop&w=1200&q=60',
        category: 'relief'
    },
    {
        id: 11,
        title: 'Women Empowerment Workshop',
        description: 'Self-defense and business training',
        fullDescription: 'Conducted comprehensive workshops on self-defense, financial literacy, and small business development. Empowered 80 women to start their own micro-enterprises with initial capital support.',
        date: 'Apr 2023',
        location: 'Belagavi, Karnataka, India',
        country: 'in',
        state: 'ka',
        district: 'bel',
        image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=60',
        category: 'education'
    },
    {
        id: 12,
        title: 'Health Awareness Campaign',
        description: 'Disease prevention and wellness education',
        fullDescription: 'Launched a comprehensive health awareness campaign covering topics like diabetes, hypertension, and reproductive health. Reached 5000+ people through seminars and door-to-door campaigns.',
        date: 'Mar 2023',
        location: 'Udupi, Karnataka, India',
        country: 'in',
        state: 'ka',
        district: 'udu',
        image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=60',
        category: 'medical'
    },
    {
        id: 13,
        title: 'Library & Reading Room Setup',
        description: 'Establishing learning centers in villages',
        fullDescription: 'Set up reading rooms and mini libraries in 8 villages with over 2000 books in local languages. Conducted reading sessions and mentoring programs to promote literacy among children.',
        date: 'Feb 2023',
        location: 'Tumakuru, Karnataka, India',
        country: 'in',
        state: 'ka',
        district: 'tum',
        image: 'https://images.unsplash.com/photo-1507842217343-583f20270319?auto=format&fit=crop&w=1200&q=60',
        category: 'education'
    },
    {
        id: 14,
        title: 'Elder Care Support',
        description: 'Medical assistance and companionship for seniors',
        fullDescription: 'Provided comprehensive care support to elderly citizens including medical checkups, medication management, and regular home visits. Also organized recreational activities to combat loneliness.',
        date: 'Jan 2023',
        location: 'East Delhi, Delhi, India',
        country: 'in',
        state: 'dl',
        district: 'eas',
        image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=60',
        category: 'medical'
    },
    {
        id: 15,
        title: 'Environmental Cleanup Drive',
        description: 'Community cleanliness and tree planting',
        fullDescription: 'Organized environmental awareness campaign with community cleanup drives and tree planting initiatives. Planted 500+ trees and involved 300+ volunteers in making communities cleaner and greener.',
        date: 'Dec 2022',
        location: 'West Delhi, Delhi, India',
        country: 'in',
        state: 'dl',
        district: 'wes',
        image: 'https://images.unsplash.com/photo-1532996122724-8f3c2cd83c5d?auto=format&fit=crop&w=1200&q=60',
        category: 'relief'
    },
    {
        id: 16,
        title: 'Disability Support Initiative',
        description: 'Assistive devices and rehabilitation',
        fullDescription: 'Distributed assistive devices to differently-abled individuals and provided rehabilitation services. Helped 40+ individuals gain mobility and independence through wheelchairs, crutches, and hearing aids.',
        date: 'Nov 2022',
        location: 'North Delhi, Delhi, India',
        country: 'in',
        state: 'dl',
        district: 'nor',
        image: 'https://images.unsplash.com/photo-1559027615-cd2628902d4a?auto=format&fit=crop&w=1200&q=60',
        category: 'relief'
    },
    {
        id: 17,
        title: 'Mental Health Awareness Program',
        description: 'Counseling and psychological support',
        fullDescription: 'Conducted mental health awareness sessions and provided free counseling services to community members. Trained peer supporters to help reduce stigma around mental health issues.',
        date: 'Oct 2022',
        location: 'Mumbai, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'mum',
        image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=60',
        category: 'medical'
    },
    {
        id: 18,
        title: 'Food Security Program',
        description: 'Distribution of subsidized food items',
        fullDescription: 'Distributed essential food items including rice, pulses, and fortified flour to 200+ families below poverty line. Partnered with local vendors to ensure fresh and quality products.',
        date: 'Sep 2022',
        location: 'Pune, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'pune',
        image: 'https://images.unsplash.com/photo-1532996122724-8f3c2cd83c5d?auto=format&fit=crop&w=1200&q=60',
        category: 'relief'
    },
    {
        id: 19,
        title: 'Sports Equipment Donation',
        description: 'Supporting youth sports development',
        fullDescription: 'Donated sports equipment and uniforms to 15 schools in rural areas. Sponsored coaching and organized inter-school sports tournaments to promote physical fitness and teamwork.',
        date: 'Aug 2022',
        location: 'Nagpur, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'nag',
        image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=1200&q=60',
        category: 'education'
    },
    {
        id: 20,
        title: 'Digital Literacy Initiative',
        description: 'Computer training for rural communities',
        fullDescription: 'Conducted computer literacy classes for 150+ adults and children in rural areas. Provided basic training on internet usage, online safety, and digital payment systems for financial inclusion.',
        date: 'Jul 2022',
        location: 'Nashik, Maharashtra, India',
        country: 'in',
        state: 'mh',
        district: 'nas',
        image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=60',
        category: 'education'
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/IPL-Website-test-main/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hand$2d$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HandHeart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/hand-heart.js [app-client] (ecmascript) <export default as HandHeart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$quote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Quote$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/quote.js [app-client] (ecmascript) <export default as Quote>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$data$2f$humanitarian$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/data/humanitarian-events.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
// Images referenced from public folder
const img1 = '/Images/carousel-1.jpg';
const img2 = '/Images/carousel-2.jpg';
const img3 = '/Images/carousel-3.jpg';
const ImageCarousel = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(49);
    if ($[0] !== "083d5785c71a11666ecc0295689aeb54449224783ebcb8ef352aaa92b470196e") {
        for(let $i = 0; $i < 49; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "083d5785c71a11666ecc0295689aeb54449224783ebcb8ef352aaa92b470196e";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isTransitioning, setIsTransitioning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t0;
    if ($[1] !== t) {
        t0 = t("home.carousel1_title", "IPL Community Moments");
        $[1] = t;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    if ($[3] !== t0) {
        t1 = {
            src: img1,
            alt: t0
        };
        $[3] = t0;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== t) {
        t2 = t("home.carousel2_title", "Humanitarian Service");
        $[5] = t;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    let t3;
    if ($[7] !== t2) {
        t3 = {
            src: img2,
            alt: t2
        };
        $[7] = t2;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== t) {
        t4 = t("home.carousel3_title", "Friendship Meet Highlights");
        $[9] = t;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== t4) {
        t5 = {
            src: img3,
            alt: t4
        };
        $[11] = t4;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] !== t1 || $[14] !== t3 || $[15] !== t5) {
        t6 = [
            t1,
            t3,
            t5
        ];
        $[13] = t1;
        $[14] = t3;
        $[15] = t5;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    const images = t6;
    let t7;
    if ($[17] !== isTransitioning) {
        t7 = (nextIndex)=>{
            if (isTransitioning) {
                return;
            }
            setIsTransitioning(true);
            setCurrentIndex(nextIndex);
            setTimeout(()=>setIsTransitioning(false), 500);
        };
        $[17] = isTransitioning;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    const changeIndex = t7;
    let t8;
    if ($[19] !== changeIndex || $[20] !== currentIndex || $[21] !== images.length) {
        t8 = ()=>{
            const next = currentIndex === 0 ? images.length - 1 : currentIndex - 1;
            changeIndex(next);
        };
        $[19] = changeIndex;
        $[20] = currentIndex;
        $[21] = images.length;
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    const goToPrevious = t8;
    let t9;
    if ($[23] !== changeIndex || $[24] !== currentIndex || $[25] !== images.length) {
        t9 = ()=>{
            const next_0 = currentIndex === images.length - 1 ? 0 : currentIndex + 1;
            changeIndex(next_0);
        };
        $[23] = changeIndex;
        $[24] = currentIndex;
        $[25] = images.length;
        $[26] = t9;
    } else {
        t9 = $[26];
    }
    const goToNext = t9;
    let t10;
    let t11;
    if ($[27] !== images.length) {
        t10 = ()=>{
            const timer = setInterval(()=>{
                setCurrentIndex((prev)=>prev === images.length - 1 ? 0 : prev + 1);
            }, 5000);
            return ()=>clearInterval(timer);
        };
        t11 = [
            images.length
        ];
        $[27] = images.length;
        $[28] = t10;
        $[29] = t11;
    } else {
        t10 = $[28];
        t11 = $[29];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t10, t11);
    let t12;
    if ($[30] !== currentIndex || $[31] !== images || $[32] !== t) {
        t12 = images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `absolute inset-0 transition-opacity duration-700 ease-in-out ${index === currentIndex ? "opacity-100" : "opacity-0"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-linear-to-t from-black/80 via-black/20 to-transparent z-10"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 165,
                        columnNumber: 186
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: img.src,
                        alt: img.alt ?? "",
                        fill: true,
                        sizes: "100vw",
                        className: "object-cover transform transition-transform duration-[10s] hover:scale-110",
                        priority: index === 0
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 165,
                        columnNumber: 284
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-0 left-0 right-0 p-4 sm:p-6 md:p-8 z-20 text-white transform transition-all duration-500 translate-y-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold mb-2 sm:mb-3 drop-shadow-lg",
                                children: img.alt
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 165,
                                columnNumber: 599
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm sm:text-base md:text-lg text-neutral-200 max-w-2xl drop-shadow-md line-clamp-2 sm:line-clamp-none",
                                children: index === 0 ? t("home.carousel1_desc", "Snapshots from our events and outreach") : index === 1 ? t("home.carousel2_desc", "Medical, education, and welfare support efforts") : t("home.carousel3_desc", "Celebrating bonds that bring people together")
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 165,
                                columnNumber: 711
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 165,
                        columnNumber: 463
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, index, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 165,
                columnNumber: 38
            }, ("TURBOPACK compile-time value", void 0)));
        $[30] = currentIndex;
        $[31] = images;
        $[32] = t;
        $[33] = t12;
    } else {
        t12 = $[33];
    }
    let t13;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
            className: "w-5 h-5 sm:w-6 sm:h-6"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 175,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    let t14;
    if ($[35] !== goToPrevious) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: goToPrevious,
            className: "absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-30 p-2 sm:p-3 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white hover:text-red-700 transition-all opacity-50 sm:opacity-0 group-hover:opacity-100 sm:-translate-x-4 sm:group-hover:translate-x-0",
            children: t13
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 182,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[35] = goToPrevious;
        $[36] = t14;
    } else {
        t14 = $[36];
    }
    let t15;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
            className: "w-5 h-5 sm:w-6 sm:h-6"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 190,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[37] = t15;
    } else {
        t15 = $[37];
    }
    let t16;
    if ($[38] !== goToNext) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: goToNext,
            className: "absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-30 p-2 sm:p-3 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white hover:text-red-700 transition-all opacity-50 sm:opacity-0 group-hover:opacity-100 sm:translate-x-4 sm:group-hover:translate-x-0",
            children: t15
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[38] = goToNext;
        $[39] = t16;
    } else {
        t16 = $[39];
    }
    let t17;
    if ($[40] !== changeIndex || $[41] !== currentIndex || $[42] !== images) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute bottom-6 right-6 z-30 flex gap-2",
            children: images.map((_, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>changeIndex(index_0),
                    className: `h-2 rounded-full transition-all duration-300 ${index_0 === currentIndex ? "w-8 bg-red-600" : "w-2 bg-white/50 hover:bg-white"}`
                }, index_0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 205,
                    columnNumber: 98
                }, ("TURBOPACK compile-time value", void 0)))
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 205,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[40] = changeIndex;
        $[41] = currentIndex;
        $[42] = images;
        $[43] = t17;
    } else {
        t17 = $[43];
    }
    let t18;
    if ($[44] !== t12 || $[45] !== t14 || $[46] !== t16 || $[47] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative h-[280px] sm:h-[360px] md:h-[420px] lg:h-[520px] w-full overflow-hidden rounded-xl md:rounded-2xl shadow-2xl group",
            children: [
                t12,
                t14,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 215,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[44] = t12;
        $[45] = t14;
        $[46] = t16;
        $[47] = t17;
        $[48] = t18;
    } else {
        t18 = $[48];
    }
    return t18;
};
_s(ImageCarousel, "jHU6G0N/yLNLmALfrXAZwMrsAXE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = ImageCarousel;
const RecentActivitiesCarousel = ()=>{
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "083d5785c71a11666ecc0295689aeb54449224783ebcb8ef352aaa92b470196e") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "083d5785c71a11666ecc0295689aeb54449224783ebcb8ef352aaa92b470196e";
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [itemsPerPage, setItemsPerPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(3);
    const latestEvents = __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$data$2f$humanitarian$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["humanitarianEvents"].slice(0, 10);
    let t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ()=>{
            const handleResize = ()=>{
                if (window.innerWidth < 768) {
                    setItemsPerPage(1);
                } else {
                    if (window.innerWidth < 1024) {
                        setItemsPerPage(2);
                    } else {
                        setItemsPerPage(3);
                    }
                }
            };
            handleResize();
            window.addEventListener("resize", handleResize);
            return ()=>window.removeEventListener("resize", handleResize);
        };
        t1 = [];
        $[1] = t0;
        $[2] = t1;
    } else {
        t0 = $[1];
        t1 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RecentActivitiesCarousel.useEffect": ()=>{
            const timer = setInterval({
                "RecentActivitiesCarousel.useEffect.timer": ()=>{
                    setCurrentIndex({
                        "RecentActivitiesCarousel.useEffect.timer": (prev)=>{
                            const maxIndex = Math.max(0, latestEvents.length - itemsPerPage);
                            return prev >= maxIndex ? 0 : prev + 1;
                        }
                    }["RecentActivitiesCarousel.useEffect.timer"]);
                }
            }["RecentActivitiesCarousel.useEffect.timer"], 5000);
            return ({
                "RecentActivitiesCarousel.useEffect": ()=>clearInterval(timer)
            })["RecentActivitiesCarousel.useEffect"];
        }
    }["RecentActivitiesCarousel.useEffect"], [
        itemsPerPage,
        latestEvents.length
    ]);
    const maxIndex_0 = Math.max(0, latestEvents.length - itemsPerPage);
    let t2;
    if ($[3] !== maxIndex_0) {
        t2 = ()=>{
            setCurrentIndex((prev_0)=>prev_0 >= maxIndex_0 ? 0 : prev_0 + 1);
        };
        $[3] = maxIndex_0;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const nextSlide = t2;
    let t3;
    if ($[5] !== maxIndex_0) {
        t3 = ()=>{
            setCurrentIndex((prev_1)=>prev_1 === 0 ? maxIndex_0 : prev_1 - 1);
        };
        $[5] = maxIndex_0;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const prevSlide = t3;
    const t4 = "relative group/carousel";
    let t5;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
            className: "w-5 h-5"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 300,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== prevSlide) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: prevSlide,
            className: "absolute left-0 top-1/2 -translate-y-1/2 z-30 p-3 rounded-full bg-white shadow-lg border border-neutral-100 text-neutral-700 hover:bg-neutral-50 hover:text-red-700 transition-all opacity-100 md:opacity-0 md:group-hover/carousel:opacity-100 md:-translate-x-4 md:group-hover/carousel:translate-x-0",
            "aria-label": "Previous",
            children: t5
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 307,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[8] = prevSlide;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
            className: "w-5 h-5"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 315,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== nextSlide) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: nextSlide,
            className: "absolute right-0 top-1/2 -translate-y-1/2 z-30 p-3 rounded-full bg-white shadow-lg border border-neutral-100 text-neutral-700 hover:bg-neutral-50 hover:text-red-700 transition-all opacity-100 md:opacity-0 md:group-hover/carousel:opacity-100 md:translate-x-4 md:group-hover/carousel:translate-x-0",
            "aria-label": "Next",
            children: t7
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 322,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[11] = nextSlide;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    const t9 = "overflow-hidden -mx-4 px-4 py-4";
    const t10 = "flex gap-8 transition-transform duration-500 ease-out";
    const t11 = `translateX(-${currentIndex * (100 / itemsPerPage)}%)`;
    let t12;
    if ($[13] !== t11) {
        t12 = {
            transform: t11
        };
        $[13] = t11;
        $[14] = t12;
    } else {
        t12 = $[14];
    }
    const t13 = latestEvents.map(_temp);
    let t14;
    if ($[15] !== t12 || $[16] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t9,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: t10,
                style: t12,
                children: t13
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 344,
                columnNumber: 31
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 344,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[15] = t12;
        $[16] = t13;
        $[17] = t14;
    } else {
        t14 = $[17];
    }
    let t15;
    if ($[18] !== t14 || $[19] !== t6 || $[20] !== t8) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            children: [
                t6,
                t8,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 353,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[18] = t14;
        $[19] = t6;
        $[20] = t8;
        $[21] = t15;
    } else {
        t15 = $[21];
    }
    return t15;
};
_s1(RecentActivitiesCarousel, "HcOw0nmtQI2b+MqTv4fZp1Aynqc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c1 = RecentActivitiesCarousel;
function Home() {
    _s2();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(113);
    if ($[0] !== "083d5785c71a11666ecc0295689aeb54449224783ebcb8ef352aaa92b470196e") {
        for(let $i = 0; $i < 113; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "083d5785c71a11666ecc0295689aeb54449224783ebcb8ef352aaa92b470196e";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    if ($[1] !== t) {
        const features = [
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hand$2d$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HandHeart$3e$__["HandHeart"],
                link: "/humanitarian-services",
                titleKey: "home.feature1_title",
                descKey: "home.feature1_desc",
                color: "bg-rose-50 text-rose-600"
            },
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
                link: "/friendship-meet",
                titleKey: "home.feature2_title",
                descKey: "home.feature2_desc",
                color: "bg-blue-50 text-blue-600"
            },
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"],
                link: "/news-events",
                titleKey: "home.feature3_title",
                descKey: "home.feature3_desc",
                color: "bg-amber-50 text-amber-600"
            }
        ];
        t5 = "bg-neutral-50";
        let t7;
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-0 left-0 w-full h-full overflow-hidden z-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute -top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-red-100/50 blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 404,
                        columnNumber: 85
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-[20%] -left-[10%] w-[40%] h-[40%] rounded-full bg-blue-100/50 blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 404,
                        columnNumber: 189
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 404,
                columnNumber: 12
            }, this);
            $[9] = t7;
        } else {
            t7 = $[9];
        }
        let t8;
        if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full mb-10 lg:mb-14",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ImageCarousel, {}, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 411,
                    columnNumber: 51
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 411,
                columnNumber: 12
            }, this);
            $[10] = t8;
        } else {
            t8 = $[10];
        }
        let t9;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                className: "w-4 h-4 text-red-600"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 418,
                columnNumber: 12
            }, this);
            $[11] = t9;
        } else {
            t9 = $[11];
        }
        const t10 = String(t("home.established", "Est. 1995"));
        let t11;
        if ($[12] !== t10) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-neutral-200 shadow-sm mb-6 animate-fade-in",
                children: [
                    t9,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm font-semibold text-neutral-600 tracking-wide uppercase",
                        children: t10
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 426,
                        columnNumber: 154
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 426,
                columnNumber: 13
            }, this);
            $[12] = t10;
            $[13] = t11;
        } else {
            t11 = $[13];
        }
        const t12 = String(t("home.hero_title", "Indian Penpals' League"));
        let t13;
        if ($[14] !== t12) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-extrabold text-neutral-900 leading-tight mb-4 sm:mb-6 tracking-tight animate-slide-up px-2",
                children: t12
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 435,
                columnNumber: 13
            }, this);
            $[14] = t12;
            $[15] = t13;
        } else {
            t13 = $[15];
        }
        let t14;
        if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
            t14 = {
                animationDelay: "0.1s"
            };
            $[16] = t14;
        } else {
            t14 = $[16];
        }
        const t15 = String(t("home.hero_sub", "Love, Friendship & Humanity"));
        let t16;
        if ($[17] !== t15) {
            t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-base sm:text-lg md:text-xl lg:text-2xl text-neutral-600 mb-6 sm:mb-8 leading-relaxed max-w-2xl mx-auto animate-slide-up px-4",
                style: t14,
                children: t15
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 453,
                columnNumber: 13
            }, this);
            $[17] = t15;
            $[18] = t16;
        } else {
            t16 = $[18];
        }
        let t17;
        if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
            t17 = {
                animationDelay: "0.2s"
            };
            $[19] = t17;
        } else {
            t17 = $[19];
        }
        const t18 = String(t("nav.about", "About Us"));
        let t19;
        if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 471,
                columnNumber: 13
            }, this);
            $[20] = t19;
        } else {
            t19 = $[20];
        }
        let t20;
        if ($[21] !== t18) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/about",
                className: "w-full sm:w-auto px-8 py-4 bg-red-700 text-white rounded-full font-bold text-lg shadow-lg shadow-red-700/30 hover:bg-red-800 hover:shadow-red-800/40 hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-2",
                children: [
                    t18,
                    t19
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 478,
                columnNumber: 13
            }, this);
            $[21] = t18;
            $[22] = t20;
        } else {
            t20 = $[22];
        }
        let t21;
        if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
            t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 486,
                columnNumber: 13
            }, this);
            $[23] = t21;
        } else {
            t21 = $[23];
        }
        const t22 = String(t("nav.contact", "Contact"));
        let t23;
        if ($[24] !== t22) {
            t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/contact",
                className: "w-full sm:w-auto px-8 py-4 bg-white text-neutral-700 border border-neutral-200 rounded-full font-bold text-lg hover:bg-neutral-50 hover:border-neutral-300 transition-all duration-300 flex items-center justify-center gap-2",
                children: [
                    t21,
                    t22
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 494,
                columnNumber: 13
            }, this);
            $[24] = t22;
            $[25] = t23;
        } else {
            t23 = $[25];
        }
        let t24;
        if ($[26] !== t20 || $[27] !== t23) {
            t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up",
                style: t17,
                children: [
                    t20,
                    t23
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 502,
                columnNumber: 13
            }, this);
            $[26] = t20;
            $[27] = t23;
            $[28] = t24;
        } else {
            t24 = $[28];
        }
        if ($[29] !== t11 || $[30] !== t13 || $[31] !== t16 || $[32] !== t24) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative pt-4 pb-16 lg:pt-8 lg:pb-28 overflow-hidden",
                children: [
                    t7,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container-custom mx-auto relative z-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center",
                            children: [
                                t8,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full text-center",
                                    children: [
                                        t11,
                                        t13,
                                        t16,
                                        t24
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 510,
                                    columnNumber: 194
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 510,
                            columnNumber: 146
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 510,
                        columnNumber: 90
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 510,
                columnNumber: 12
            }, this);
            $[29] = t11;
            $[30] = t13;
            $[31] = t16;
            $[32] = t24;
            $[33] = t6;
        } else {
            t6 = $[33];
        }
        t4 = "py-20 bg-white";
        t2 = "container-custom mx-auto";
        const t25 = String(t("home.our_activities", "Our Activities"));
        let t26;
        if ($[34] !== t25) {
            t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl lg:text-4xl font-bold text-neutral-900 mb-4",
                children: t25
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 524,
                columnNumber: 13
            }, this);
            $[34] = t25;
            $[35] = t26;
        } else {
            t26 = $[35];
        }
        const t27 = String(t("home.activities_subtitle", "We bring people together through various initiatives aimed at fostering friendship and serving society."));
        let t28;
        if ($[36] !== t27) {
            t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-lg text-neutral-600",
                children: t27
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 533,
                columnNumber: 13
            }, this);
            $[36] = t27;
            $[37] = t28;
        } else {
            t28 = $[37];
        }
        if ($[38] !== t26 || $[39] !== t28) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center max-w-3xl mx-auto mb-16",
                children: [
                    t26,
                    t28
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 540,
                columnNumber: 12
            }, this);
            $[38] = t26;
            $[39] = t28;
            $[40] = t3;
        } else {
            t3 = $[40];
        }
        t0 = "grid md:grid-cols-3 gap-8";
        t1 = features.map({
            "Home[features.map()]": (feature, index)=>{
                const Icon = feature.icon;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: feature.link,
                    className: "group relative bg-neutral-50 rounded-2xl p-8 hover:bg-white hover:shadow-xl transition-all duration-300 border border-transparent hover:border-neutral-100",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `w-14 h-14 rounded-xl ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                className: "w-7 h-7"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 551,
                                columnNumber: 372
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 551,
                            columnNumber: 221
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-xl font-bold text-neutral-900 mb-3 group-hover:text-red-700 transition-colors",
                            children: String(t(feature.titleKey))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 551,
                            columnNumber: 406
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-600 mb-6 leading-relaxed",
                            children: String(t(feature.descKey))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 551,
                            columnNumber: 539
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center text-red-700 font-semibold group-hover:gap-2 transition-all",
                            children: [
                                String(t("home.learn_more", "Learn more")),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                    className: "w-4 h-4 ml-1"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 551,
                                    columnNumber: 763
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 551,
                            columnNumber: 624
                        }, this)
                    ]
                }, index, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 551,
                    columnNumber: 16
                }, this);
            }
        }["Home[features.map()]"]);
        $[1] = t;
        $[2] = t0;
        $[3] = t1;
        $[4] = t2;
        $[5] = t3;
        $[6] = t4;
        $[7] = t5;
        $[8] = t6;
    } else {
        t0 = $[2];
        t1 = $[3];
        t2 = $[4];
        t3 = $[5];
        t4 = $[6];
        t5 = $[7];
        t6 = $[8];
    }
    let t7;
    if ($[41] !== t0 || $[42] !== t1) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t0,
            children: t1
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 573,
            columnNumber: 10
        }, this);
        $[41] = t0;
        $[42] = t1;
        $[43] = t7;
    } else {
        t7 = $[43];
    }
    let t8;
    if ($[44] !== t2 || $[45] !== t3 || $[46] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: [
                t3,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 582,
            columnNumber: 10
        }, this);
        $[44] = t2;
        $[45] = t3;
        $[46] = t7;
        $[47] = t8;
    } else {
        t8 = $[47];
    }
    let t9;
    if ($[48] !== t4 || $[49] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t4,
            children: t8
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 592,
            columnNumber: 10
        }, this);
        $[48] = t4;
        $[49] = t8;
        $[50] = t9;
    } else {
        t9 = $[50];
    }
    let t10;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-0 right-0 w-1/3 h-full bg-linear-to-l from-red-900/20 to-transparent"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 601,
            columnNumber: 11
        }, this);
        $[51] = t10;
    } else {
        t10 = $[51];
    }
    let t11;
    if ($[52] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute -top-10 -left-10 text-red-700/20",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$quote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Quote$3e$__["Quote"], {
                className: "w-32 h-32"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 608,
                columnNumber: 70
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 608,
            columnNumber: 11
        }, this);
        $[52] = t11;
    } else {
        t11 = $[52];
    }
    let t12;
    if ($[53] !== t) {
        t12 = t("home.founder_quote", "Our founder quote");
        $[53] = t;
        $[54] = t12;
    } else {
        t12 = $[54];
    }
    const t13 = String(t12);
    let t14;
    if ($[55] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
            className: "text-3xl lg:text-4xl font-medium leading-tight mb-8 relative z-10",
            children: [
                "“",
                t13,
                "”"
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 624,
            columnNumber: 11
        }, this);
        $[55] = t13;
        $[56] = t14;
    } else {
        t14 = $[56];
    }
    let t15;
    if ($[57] !== t) {
        t15 = t("home.founder_name", "Founder");
        $[57] = t;
        $[58] = t15;
    } else {
        t15 = $[58];
    }
    const t16 = String(t15);
    let t17;
    if ($[59] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("cite", {
            className: "text-lg text-red-400 font-style-normal block mb-12",
            children: [
                "— ",
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 641,
            columnNumber: 11
        }, this);
        $[59] = t16;
        $[60] = t17;
    } else {
        t17 = $[60];
    }
    let t18;
    if ($[61] !== t14 || $[62] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "lg:w-1/2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    t11,
                    t14,
                    t17
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 649,
                columnNumber: 37
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 649,
            columnNumber: 11
        }, this);
        $[61] = t14;
        $[62] = t17;
        $[63] = t18;
    } else {
        t18 = $[63];
    }
    let t19;
    if ($[64] !== t) {
        t19 = t("home.welcome_title", "Welcome to IPL");
        $[64] = t;
        $[65] = t19;
    } else {
        t19 = $[65];
    }
    const t20 = String(t19);
    let t21;
    if ($[66] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-2xl font-bold mb-6",
            children: t20
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 667,
            columnNumber: 11
        }, this);
        $[66] = t20;
        $[67] = t21;
    } else {
        t21 = $[67];
    }
    let t22;
    if ($[68] !== t) {
        t22 = t("home.about_intro", "About intro text");
        $[68] = t;
        $[69] = t22;
    } else {
        t22 = $[69];
    }
    const t23 = String(t22);
    let t24;
    if ($[70] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-300 mb-6 leading-relaxed",
            children: t23
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 684,
            columnNumber: 11
        }, this);
        $[70] = t23;
        $[71] = t24;
    } else {
        t24 = $[71];
    }
    let t25;
    if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-4 rounded-lg bg-white/5 border border-white/5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-xs text-neutral-400 uppercase tracking-wider mb-1",
                    children: "Registration"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 692,
                    columnNumber: 76
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "font-mono font-bold text-primary-400",
                    children: "#F23778"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 692,
                    columnNumber: 162
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 692,
            columnNumber: 11
        }, this);
        $[72] = t25;
    } else {
        t25 = $[72];
    }
    let t26;
    if ($[73] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-2 gap-4 mb-8",
            children: [
                t25,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 rounded-lg bg-white/5 border border-white/5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-neutral-400 uppercase tracking-wider mb-1",
                            children: "Tax Benefit"
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 699,
                            columnNumber: 126
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "font-mono font-bold text-primary-400",
                            children: "80G Certified"
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 699,
                            columnNumber: 211
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 699,
                    columnNumber: 61
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 699,
            columnNumber: 11
        }, this);
        $[73] = t26;
    } else {
        t26 = $[73];
    }
    let t27;
    if ($[74] !== t) {
        t27 = t("home.read_more", "Read full story");
        $[74] = t;
        $[75] = t27;
    } else {
        t27 = $[75];
    }
    const t28 = String(t27);
    let t29;
    if ($[76] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
            className: "w-5 h-5"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 715,
            columnNumber: 11
        }, this);
        $[76] = t29;
    } else {
        t29 = $[76];
    }
    let t30;
    if ($[77] !== t28) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/about",
            className: "inline-flex items-center gap-2 text-white font-semibold hover:text-red-400 transition-colors",
            children: [
                t28,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 722,
            columnNumber: 11
        }, this);
        $[77] = t28;
        $[78] = t30;
    } else {
        t30 = $[78];
    }
    let t31;
    if ($[79] !== t21 || $[80] !== t24 || $[81] !== t30) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "lg:w-1/2 bg-white/5 backdrop-blur-sm rounded-2xl p-8 lg:p-12 border border-white/10",
            children: [
                t21,
                t24,
                t26,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 730,
            columnNumber: 11
        }, this);
        $[79] = t21;
        $[80] = t24;
        $[81] = t30;
        $[82] = t31;
    } else {
        t31 = $[82];
    }
    let t32;
    if ($[83] !== t18 || $[84] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-900 text-white relative overflow-hidden",
            children: [
                t10,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container-custom mx-auto relative z-10",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col lg:flex-row items-center gap-16",
                        children: [
                            t18,
                            t31
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 740,
                        columnNumber: 150
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 740,
                    columnNumber: 94
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 740,
            columnNumber: 11
        }, this);
        $[83] = t18;
        $[84] = t31;
        $[85] = t32;
    } else {
        t32 = $[85];
    }
    let t33;
    if ($[86] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl font-bold text-neutral-900 mb-2",
                    children: "Recent Humanitarian Activities"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 749,
                    columnNumber: 16
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-neutral-600",
                    children: "Our latest efforts in serving the community"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 749,
                    columnNumber: 108
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 749,
            columnNumber: 11
        }, this);
        $[86] = t33;
    } else {
        t33 = $[86];
    }
    let t34;
    if ($[87] !== t) {
        t34 = t("home.view_all", "View All");
        $[87] = t;
        $[88] = t34;
    } else {
        t34 = $[88];
    }
    const t35 = String(t34);
    let t36;
    if ($[89] !== t35) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col md:flex-row justify-between items-end mb-12 gap-4",
            children: [
                t33,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/humanitarian-services",
                    className: "px-6 py-2 bg-white border border-neutral-200 rounded-full text-neutral-700 font-medium hover:bg-neutral-50 hover:border-neutral-300 transition-all",
                    children: t35
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 765,
                    columnNumber: 97
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 765,
            columnNumber: 11
        }, this);
        $[89] = t35;
        $[90] = t36;
    } else {
        t36 = $[90];
    }
    let t37;
    if ($[91] === Symbol.for("react.memo_cache_sentinel")) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RecentActivitiesCarousel, {}, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 773,
            columnNumber: 11
        }, this);
        $[91] = t37;
    } else {
        t37 = $[91];
    }
    let t38;
    if ($[92] !== t36) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container-custom mx-auto",
                children: [
                    t36,
                    t37
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 780,
                columnNumber: 52
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 780,
            columnNumber: 11
        }, this);
        $[92] = t36;
        $[93] = t38;
    } else {
        t38 = $[93];
    }
    let t39;
    if ($[94] === Symbol.for("react.memo_cache_sentinel")) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
            className: "w-12 h-12 text-red-600 mx-auto mb-6 animate-pulse"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 788,
            columnNumber: 11
        }, this);
        $[94] = t39;
    } else {
        t39 = $[94];
    }
    let t40;
    if ($[95] !== t) {
        t40 = t("home.mother_teresa_quote", "Spread love everywhere you go. Let no one ever come to you without leaving happier.");
        $[95] = t;
        $[96] = t40;
    } else {
        t40 = $[96];
    }
    const t41 = String(t40);
    let t42;
    if ($[97] !== t41) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
            className: "text-2xl md:text-4xl font-serif italic text-neutral-800 mb-8 leading-tight",
            children: [
                "“",
                t41,
                "”"
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 804,
            columnNumber: 11
        }, this);
        $[97] = t41;
        $[98] = t42;
    } else {
        t42 = $[98];
    }
    let t43;
    if ($[99] !== t) {
        t43 = t("home.mother_teresa", "Mother Teresa");
        $[99] = t;
        $[100] = t43;
    } else {
        t43 = $[100];
    }
    const t44 = String(t43);
    let t45;
    if ($[101] !== t44) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("cite", {
            className: "text-lg font-semibold text-neutral-500 not-italic",
            children: [
                "— ",
                t44
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 821,
            columnNumber: 11
        }, this);
        $[101] = t44;
        $[102] = t45;
    } else {
        t45 = $[102];
    }
    let t46;
    if ($[103] !== t42 || $[104] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-white border-t border-neutral-100",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container-custom mx-auto text-center max-w-4xl",
                children: [
                    t39,
                    t42,
                    t45
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 829,
                columnNumber: 75
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 829,
            columnNumber: 11
        }, this);
        $[103] = t42;
        $[104] = t45;
        $[105] = t46;
    } else {
        t46 = $[105];
    }
    let t47;
    if ($[106] !== t32 || $[107] !== t38 || $[108] !== t46 || $[109] !== t5 || $[110] !== t6 || $[111] !== t9) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t5,
            children: [
                t6,
                t9,
                t32,
                t38,
                t46
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 838,
            columnNumber: 11
        }, this);
        $[106] = t32;
        $[107] = t38;
        $[108] = t46;
        $[109] = t5;
        $[110] = t6;
        $[111] = t9;
        $[112] = t47;
    } else {
        t47 = $[112];
    }
    return t47;
}
_s2(Home, "vu2xTFBfHkv41zWfADiErp1aWcA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c2 = Home;
function _temp(activity) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex-none w-full md:w-[calc(50%-16px)] lg:w-[calc(33.333%-21.33px)] group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-48 overflow-hidden relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors z-10"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 852,
                        columnNumber: 278
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: activity.image,
                        alt: activity.title,
                        fill: true,
                        sizes: "(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw",
                        className: "object-cover transform group-hover:scale-110 transition-transform duration-700"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 852,
                        columnNumber: 376
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-4 left-4 z-20 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-red-700 uppercase tracking-wider shadow-sm",
                        children: activity.date
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 852,
                        columnNumber: 595
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 852,
                columnNumber: 231
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-bold text-neutral-900 mb-3 group-hover:text-red-700 transition-colors line-clamp-2",
                        children: activity.title
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 852,
                        columnNumber: 805
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-neutral-600 text-sm leading-relaxed line-clamp-3 mb-4",
                        children: activity.description
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 852,
                        columnNumber: 938
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between mt-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/humanitarian-services",
                            className: "text-red-700 text-sm font-semibold flex items-center gap-1 group-hover:gap-2 transition-all",
                            children: [
                                "Read more ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                    className: "w-4 h-4"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 852,
                                    columnNumber: 1247
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 852,
                            columnNumber: 1097
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 852,
                        columnNumber: 1038
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 852,
                columnNumber: 784
            }, this)
        ]
    }, activity.id, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
        lineNumber: 852,
        columnNumber: 10
    }, this);
}
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ImageCarousel");
__turbopack_context__.k.register(_c1, "RecentActivitiesCarousel");
__turbopack_context__.k.register(_c2, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=IPL-Website-test-main_src_9d7c69c0._.js.map