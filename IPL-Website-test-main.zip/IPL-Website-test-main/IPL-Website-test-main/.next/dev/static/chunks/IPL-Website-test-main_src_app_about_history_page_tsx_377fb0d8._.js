(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/app/about/history/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HistoryPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript) <export default as Globe>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/book-open.js [app-client] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function HistoryPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(111);
    if ($[0] !== "fc417a146329ad710e2924bcefaf247f4725f52e2d0d89f555cede00b24a4670") {
        for(let $i = 0; $i < 111; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fc417a146329ad710e2924bcefaf247f4725f52e2d0d89f555cede00b24a4670";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [
            {
                year: "1995",
                title: "Foundation",
                titleTa: "\u0BA4\u0BCA\u0B9F\u0B95\u0BCD\u0B95\u0BAE\u0BCD",
                description: "IPL was founded in Mumbai on March 12, 1995, by like-minded pen pals united by love, friendship, and humanity.",
                descriptionTa: "\u0B85\u0BA9\u0BCD\u0BAA\u0BC1, \u0BA8\u0B9F\u0BCD\u0BAA\u0BC1 \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BAE\u0BA9\u0BBF\u0BA4\u0BA8\u0BC7\u0BAF\u0BA4\u0BCD\u0BA4\u0BBE\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BBF\u0BA3\u0BC8\u0BA8\u0BCD\u0BA4 \u0BAA\u0BC7\u0BA9\u0BBE \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BBE\u0BB2\u0BCD 1995 \u0BAE\u0BBE\u0BB0\u0BCD\u0B9A\u0BCD 12 \u0B85\u0BA9\u0BCD\u0BB1\u0BC1 \u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD IPL \u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"],
                color: "from-red-500 to-rose-600"
            },
            {
                year: "2001",
                title: "Gujarat Earthquake Relief",
                titleTa: "\u0B95\u0BC1\u0B9C\u0BB0\u0BBE\u0BA4\u0BCD \u0BA8\u0BBF\u0BB2\u0BA8\u0B9F\u0BC1\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BB5\u0BBE\u0BB0\u0BA3\u0BAE\u0BCD",
                description: "Established relief center (Jan 27 - Feb 2, 2001) and collected funds for earthquake victims, handed over to the Mumbai District Collector.",
                descriptionTa: "\u0BA8\u0BBF\u0BB5\u0BBE\u0BB0\u0BA3 \u0BAE\u0BC8\u0BAF\u0BAE\u0BCD \u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 (\u0B9C\u0BA9\u0BB5\u0BB0\u0BBF 27 - \u0BAA\u0BBF\u0BAA\u0BCD\u0BB0\u0BB5\u0BB0\u0BBF 2, 2001) \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BA8\u0BBF\u0BB2\u0BA8\u0B9F\u0BC1\u0B95\u0BCD\u0B95 \u0BAA\u0BBE\u0BA4\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BB5\u0BB0\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BBE\u0BA9 \u0BA8\u0BBF\u0BA4\u0BBF \u0B9A\u0BC7\u0B95\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1 \u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8 \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F \u0B86\u0B9F\u0BCD\u0B9A\u0BBF\u0BAF\u0BB0\u0BBF\u0B9F\u0BAE\u0BCD \u0B92\u0BAA\u0BCD\u0BAA\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"],
                color: "from-orange-500 to-amber-600"
            },
            {
                year: "2005",
                title: "Tsunami Relief Operations",
                titleTa: "\u0B9A\u0BC1\u0BA9\u0BBE\u0BAE\u0BBF \u0BA8\u0BBF\u0BB5\u0BBE\u0BB0\u0BA3 \u0BA8\u0B9F\u0BB5\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BC8\u0B95\u0BB3\u0BCD",
                description: "Traveled along the coast from Colachel to Manakudy in Kanyakumari district, directly providing rice, lentils, food grains, and clothing to 200+ affected families.",
                descriptionTa: "\u0B95\u0BA9\u0BCD\u0BA9\u0BBF\u0BAF\u0BBE\u0B95\u0BC1\u0BAE\u0BB0\u0BBF \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B95\u0BCB\u0BB2\u0B9A\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0BA4\u0BB2\u0BCD \u0BAE\u0BA9\u0B95\u0BCD\u0B95\u0BC1\u0B9F\u0BBF \u0BB5\u0BB0\u0BC8 \u0B95\u0B9F\u0BB1\u0BCD\u0B95\u0BB0\u0BC8 \u0B93\u0BB0\u0BAE\u0BBE\u0B95 \u0BAA\u0BAF\u0BA3\u0BBF\u0BA4\u0BCD\u0BA4\u0BC1, 200+ \u0BAA\u0BBE\u0BA4\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B95\u0BC1\u0B9F\u0BC1\u0BAE\u0BCD\u0BAA\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BA8\u0BC7\u0BB0\u0B9F\u0BBF\u0BAF\u0BBE\u0B95 \u0B85\u0BB0\u0BBF\u0B9A\u0BBF, \u0BAA\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1, \u0B89\u0BA3\u0BB5\u0BC1 \u0BA4\u0BBE\u0BA9\u0BBF\u0BAF\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B86\u0B9F\u0BC8\u0B95\u0BB3\u0BCD \u0BB5\u0BB4\u0B99\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9.",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__["Globe"],
                color: "from-blue-500 to-cyan-600"
            },
            {
                year: "2007",
                title: "Paris - Bharathiyar Anniversary",
                titleTa: "\u0BAA\u0BBE\u0BB0\u0BBF\u0BB8\u0BCD - \u0BAA\u0BBE\u0BB0\u0BA4\u0BBF\u0BAF\u0BBE\u0BB0\u0BCD \u0B86\u0BA3\u0BCD\u0B9F\u0BC1 \u0BB5\u0BBF\u0BB4\u0BBE",
                description: "Special guest at the 125th anniversary of Mahakavi Bharathiyar organized by France Tamil Sangam in Paris, the only Mumbai Tamil organization invited.",
                descriptionTa: "\u0BAA\u0BBE\u0BB0\u0BBF\u0BB8\u0BBF\u0BB2\u0BCD \u0BAA\u0BBF\u0BB0\u0BBE\u0BA9\u0BCD\u0BB8\u0BCD \u0BA4\u0BAE\u0BBF\u0BB4\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BCD \u0BA8\u0B9F\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF \u0BAE\u0B95\u0BBE\u0B95\u0BB5\u0BBF \u0BAA\u0BBE\u0BB0\u0BA4\u0BBF\u0BAF\u0BBE\u0BB0\u0BBF\u0BA9\u0BCD 125\u0BB5\u0BA4\u0BC1 \u0B86\u0BA3\u0BCD\u0B9F\u0BC1 \u0BB5\u0BBF\u0BB4\u0BBE\u0BB5\u0BBF\u0BB2\u0BCD \u0B9A\u0BBF\u0BB1\u0BAA\u0BCD\u0BAA\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD, \u0B85\u0BB4\u0BC8\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B92\u0BB0\u0BC7 \u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8 \u0BA4\u0BAE\u0BBF\u0BB4\u0BCD \u0B85\u0BAE\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1.",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"],
                color: "from-indigo-500 to-purple-600"
            },
            {
                year: "2011",
                title: "Gandhi Statue Inauguration",
                titleTa: "\u0B95\u0BBE\u0BA8\u0BCD\u0BA4\u0BBF \u0B9A\u0BBF\u0BB2\u0BC8 \u0BA4\u0BBF\u0BB1\u0BAA\u0BCD\u0BAA\u0BC1 \u0BB5\u0BBF\u0BB4\u0BBE",
                description: "Special guest at the Mahatma Gandhi Statue Inauguration organized by Aubervilliers Tamil Cultural Forum in Paris. Presented memento to the Mayor.",
                descriptionTa: "\u0BAA\u0BBE\u0BB0\u0BBF\u0BB8\u0BBF\u0BB2\u0BCD \u0B93\u0BAA\u0BB0\u0BCD\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF\u0BAF\u0BB0\u0BCD\u0BB8\u0BCD \u0BA4\u0BAE\u0BBF\u0BB4\u0BCD \u0B95\u0BB2\u0BBE\u0B9A\u0BCD\u0B9A\u0BBE\u0BB0 \u0BAE\u0BA9\u0BCD\u0BB1\u0BAE\u0BCD \u0BA8\u0B9F\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF \u0BAE\u0B95\u0BBE\u0BA4\u0BCD\u0BAE\u0BBE \u0B95\u0BBE\u0BA8\u0BCD\u0BA4\u0BBF \u0B9A\u0BBF\u0BB2\u0BC8 \u0BA4\u0BBF\u0BB1\u0BAA\u0BCD\u0BAA\u0BC1 \u0BB5\u0BBF\u0BB4\u0BBE\u0BB5\u0BBF\u0BB2\u0BCD \u0B9A\u0BBF\u0BB1\u0BAA\u0BCD\u0BAA\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD. \u0BAE\u0BC7\u0BAF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BA8\u0BBF\u0BA9\u0BC8\u0BB5\u0BC1\u0BAA\u0BCD \u0BAA\u0BB0\u0BBF\u0B9A\u0BC1 \u0BB5\u0BB4\u0B99\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
                color: "from-emerald-500 to-teal-600"
            },
            {
                year: "2019",
                title: "Silver Jubilee Celebration",
                titleTa: "\u0BB5\u0BC6\u0BB3\u0BCD\u0BB3\u0BBF \u0BB5\u0BBF\u0BB4\u0BBE \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD",
                description: "Celebrated 25 years of service with the grand 25th Friendship Meet in Tirunelveli, marking a historic milestone in our journey.",
                descriptionTa: "25 \u0B86\u0BA3\u0BCD\u0B9F\u0BC1\u0B95\u0BBE\u0BB2 \u0B9A\u0BC7\u0BB5\u0BC8\u0BAF\u0BC8 \u0BA4\u0BBF\u0BB0\u0BC1\u0BA8\u0BC6\u0BB2\u0BCD\u0BB5\u0BC7\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0BAA\u0BBF\u0BB0\u0BAE\u0BBE\u0BA3\u0BCD\u0B9F\u0BAE\u0BBE\u0BA9 25\u0BB5\u0BA4\u0BC1 \u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BA4\u0BCD\u0BA4\u0BC1\u0B9F\u0BA9\u0BCD \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F\u0BBF\u0BA9\u0BCB\u0BAE\u0BCD, \u0B87\u0BA4\u0BC1 \u0BA8\u0BAE\u0BA4\u0BC1 \u0BAA\u0BAF\u0BA3\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B92\u0BB0\u0BC1 \u0BB5\u0BB0\u0BB2\u0BBE\u0BB1\u0BCD\u0BB1\u0BC1 \u0BAE\u0BC8\u0BB2\u0BCD\u0B95\u0BB2\u0BCD.",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"],
                color: "from-pink-500 to-rose-600"
            }
        ];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const milestones = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [
            {
                title: "\"\u0B85\u0BA4\u0BBF\u0B95\u0BBE\u0BB2\u0BC8\" - Morning",
                author: "Theni Poet Vetrivel",
                color: "bg-rose-500"
            },
            {
                title: "\"\u0B87\u0BA4\u0BAF\u0BA4\u0BCD\u0BA4\u0BC1\u0B9F\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\" - Heartbeat",
                author: "Mumbai Poet Senthoor Nagarajan",
                color: "bg-amber-500"
            },
            {
                title: "\"\u0B95\u0BB0\u0BC8\u0BAF\u0BC7\u0BB1\u0BC1\u0BAE\u0BCD \u0B85\u0BB2\u0BC8\u0B95\u0BB3\u0BCD\" - Shore-bound Waves",
                author: "Mumbai Poet Irajakai Nilavan",
                color: "bg-blue-500"
            },
            {
                title: "\"\u0B89\u0BA3\u0BB0\u0BCD\u0BB5\u0BC1\u0B95\u0BB3\u0BCD\" - Feelings",
                author: "Mumbai Poet M. S. Rajan Martin",
                color: "bg-emerald-500"
            },
            {
                title: "\"\u0B9A\u0BC6\u0BAA\u0BCD\u0BAA\u0BC7\u0B9F\u0BC1\" - Copper Plate",
                author: "Hosur Poet Karumalai Tamilazhan",
                color: "bg-purple-500"
            },
            {
                title: "\"\u0B95\u0BBE\u0BAE\u0BB0\u0BBE\u0B9C\u0BB0\u0BCD \u0B95\u0BBE\u0BB5\u0BBF\u0BAF\u0BAE\u0BCD\"",
                author: "Mumbai Poet Senthoor Nagarajan",
                color: "bg-orange-500",
                pages: "1050 pages"
            }
        ];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const publications = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [
            {
                year: "2007",
                location: "Paris, France",
                title: "Bharathiyar 125th Anniversary",
                description: "Only Mumbai Tamil organization invited as special guest to France Tamil Sangam event."
            },
            {
                year: "2011",
                location: "Paris, France",
                title: "Gandhi Statue Inauguration",
                description: "Special guest at Aubervilliers Tamil Cultural Forum, presented memento to Mayor."
            },
            {
                year: "2012",
                location: "Sri Lanka",
                title: "Tamil Magazines Conference",
                description: "Invited as special guest at 6th conference of Tamil Little Magazines Association."
            }
        ];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const internationalEvents = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 z-0",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/Images/iplbanner.png",
                    alt: "History background",
                    fill: true,
                    className: "object-cover opacity-20",
                    priority: true
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 132,
                    columnNumber: 48
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 bg-gradient-to-b from-neutral-50/80 via-neutral-50/60 to-neutral-50"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 132,
                    columnNumber: 174
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 132,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
            className: "w-4 h-4 text-red-700"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 139,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== t) {
        t5 = t("history.intro.title", "Our Heritage");
        $[6] = t;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-red-100 shadow-sm mb-8",
            children: [
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-semibold tracking-wider uppercase text-red-800",
                    children: t5
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 154,
                    columnNumber: 131
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 154,
            columnNumber: 10
        }, this);
        $[8] = t5;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== t) {
        t7 = t("history.hero.title", "History");
        $[10] = t;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-4xl sm:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6 leading-tight",
            children: t7
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 170,
            columnNumber: 10
        }, this);
        $[12] = t7;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] !== t) {
        t9 = t("history.hero.subtitle", "A Journey of Love, Friendship & Humanitarian Service");
        $[14] = t;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg sm:text-xl text-neutral-600 max-w-2xl mx-auto leading-relaxed mb-8",
            children: t9
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[16] = t9;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-px w-16 bg-gradient-to-r from-transparent to-red-300"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 194,
                    columnNumber: 67
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                    className: "w-5 h-5 text-red-600"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 194,
                    columnNumber: 141
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-px w-16 bg-gradient-to-l from-transparent to-red-300"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 194,
                    columnNumber: 183
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 194,
            columnNumber: 11
        }, this);
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== t10 || $[20] !== t6 || $[21] !== t8) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative pt-24 pb-16 overflow-hidden",
            children: [
                t3,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 relative z-10",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-4xl mx-auto text-center",
                        children: [
                            t6,
                            t8,
                            t10,
                            t11
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                        lineNumber: 201,
                        columnNumber: 127
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 201,
                    columnNumber: 73
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 201,
            columnNumber: 11
        }, this);
        $[19] = t10;
        $[20] = t6;
        $[21] = t8;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute -top-4 -left-4 text-8xl text-red-100 font-serif leading-none",
            children: '"'
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 211,
            columnNumber: 11
        }, this);
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    if ($[24] !== t) {
        t14 = t("history.intro.desc", "A legacy of humanitarian service and cultural preservation spanning nearly three decades");
        $[24] = t;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xl sm:text-2xl text-neutral-700 leading-relaxed text-center relative z-10 font-light italic px-8",
            children: t14
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 226,
            columnNumber: 11
        }, this);
        $[26] = t14;
        $[27] = t15;
    } else {
        t15 = $[27];
    }
    let t16;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute -bottom-8 -right-4 text-8xl text-red-100 font-serif leading-none rotate-180",
            children: '"'
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 234,
            columnNumber: 11
        }, this);
        $[28] = t16;
    } else {
        t16 = $[28];
    }
    let t17;
    if ($[29] !== t15) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
            className: "relative",
            children: [
                t13,
                t15,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 241,
            columnNumber: 11
        }, this);
        $[29] = t15;
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-2 md:grid-cols-4 gap-6 mt-16",
            children: [
                {
                    value: "30+",
                    label: "Years of Service"
                },
                {
                    value: "28+",
                    label: "Friendship Meets"
                },
                {
                    value: "15+",
                    label: "States Reached"
                },
                {
                    value: "5000+",
                    label: "Members"
                }
            ].map(_HistoryPageAnonymous)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 249,
            columnNumber: 11
        }, this);
        $[31] = t18;
    } else {
        t18 = $[31];
    }
    let t19;
    if ($[32] !== t17) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-16 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto",
                    children: [
                        t17,
                        t18
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 268,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 268,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 268,
            columnNumber: 11
        }, this);
        $[32] = t17;
        $[33] = t19;
    } else {
        t19 = $[33];
    }
    let t20;
    if ($[34] !== t) {
        t20 = t("history.timeline.title", "Major Milestones");
        $[34] = t;
        $[35] = t20;
    } else {
        t20 = $[35];
    }
    let t21;
    if ($[36] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
            children: t20
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 284,
            columnNumber: 11
        }, this);
        $[36] = t20;
        $[37] = t21;
    } else {
        t21 = $[37];
    }
    let t22;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-600 max-w-xl mx-auto",
            children: "Key moments that shaped our journey of love, friendship, and humanitarian service."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 292,
            columnNumber: 11
        }, this);
        $[38] = t22;
    } else {
        t22 = $[38];
    }
    let t23;
    if ($[39] !== t21) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-16",
            children: [
                t21,
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 299,
            columnNumber: 11
        }, this);
        $[39] = t21;
        $[40] = t23;
    } else {
        t23 = $[40];
    }
    let t24;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-red-200 via-red-400 to-red-200 md:-translate-x-px"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 307,
            columnNumber: 11
        }, this);
        $[41] = t24;
    } else {
        t24 = $[41];
    }
    let t25;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative",
            children: [
                t24,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-12",
                    children: milestones.map(_HistoryPageMilestonesMap)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 314,
                    columnNumber: 42
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 314,
            columnNumber: 11
        }, this);
        $[42] = t25;
    } else {
        t25 = $[42];
    }
    let t26;
    if ($[43] !== t23) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-6xl mx-auto",
                    children: [
                        t23,
                        t25
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 321,
                    columnNumber: 92
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 321,
                columnNumber: 52
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 321,
            columnNumber: 11
        }, this);
        $[43] = t23;
        $[44] = t26;
    } else {
        t26 = $[44];
    }
    let t27;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-red-50 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 329,
                columnNumber: 105
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 329,
            columnNumber: 11
        }, this);
        $[45] = t27;
    } else {
        t27 = $[45];
    }
    let t28;
    if ($[46] !== t) {
        t28 = t("history.publications.title", "Literary Contributions");
        $[46] = t;
        $[47] = t28;
    } else {
        t28 = $[47];
    }
    let t29;
    if ($[48] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
            children: t28
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 344,
            columnNumber: 11
        }, this);
        $[48] = t28;
        $[49] = t29;
    } else {
        t29 = $[49];
    }
    let t30;
    if ($[50] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-600 max-w-xl mx-auto",
            children: "Books and publications supported by IPL to promote Tamil literature."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 352,
            columnNumber: 11
        }, this);
        $[50] = t30;
    } else {
        t30 = $[50];
    }
    let t31;
    if ($[51] !== t29) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-16",
            children: [
                t27,
                t29,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 359,
            columnNumber: 11
        }, this);
        $[51] = t29;
        $[52] = t31;
    } else {
        t31 = $[52];
    }
    let t32;
    if ($[53] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-6",
            children: publications.map(_HistoryPagePublicationsMap)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 367,
            columnNumber: 11
        }, this);
        $[53] = t32;
    } else {
        t32 = $[53];
    }
    let t33;
    if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-3xl p-8 sm:p-10 border border-amber-200",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row gap-6 items-start",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-md border border-amber-100 flex-shrink-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                            className: "w-8 h-8 text-amber-600"
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                            lineNumber: 374,
                            columnNumber: 317
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                        lineNumber: 374,
                        columnNumber: 188
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "inline-block px-3 py-1 bg-amber-200 text-amber-900 text-xs font-bold rounded-full mb-3",
                                children: "Epic Poetry - 1050 Pages"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                                lineNumber: 374,
                                columnNumber: 372
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-2xl font-bold text-neutral-900 mb-3",
                                children: "Kamarajar Kaviyam"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                                lineNumber: 374,
                                columnNumber: 508
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-neutral-700 leading-relaxed",
                                children: "Fully supported Mumbai poet Senthoor Nagarajan in creating this monumental epic poetry book, organizing a grand release function, conducting research seminars, and introducing it to the Tamil literary world."
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                                lineNumber: 374,
                                columnNumber: 587
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                        lineNumber: 374,
                        columnNumber: 367
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 374,
                columnNumber: 127
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 374,
            columnNumber: 11
        }, this);
        $[54] = t33;
    } else {
        t33 = $[54];
    }
    let t34;
    if ($[55] !== t31) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-6xl mx-auto",
                    children: [
                        t31,
                        t32,
                        t33
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 381,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 381,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 381,
            columnNumber: 11
        }, this);
        $[55] = t31;
        $[56] = t34;
    } else {
        t34 = $[56];
    }
    let t35;
    if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                className: "w-8 h-8 text-white"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 389,
                columnNumber: 107
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 389,
            columnNumber: 11
        }, this);
        $[57] = t35;
    } else {
        t35 = $[57];
    }
    let t36;
    if ($[58] !== t) {
        t36 = t("history.international.title", "International Recognition");
        $[58] = t;
        $[59] = t36;
    } else {
        t36 = $[59];
    }
    let t37;
    if ($[60] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold mb-4",
            children: t36
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 404,
            columnNumber: 11
        }, this);
        $[60] = t36;
        $[61] = t37;
    } else {
        t37 = $[61];
    }
    let t38;
    if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-400 max-w-xl mx-auto",
            children: "IPL's global footprint and international engagements."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 412,
            columnNumber: 11
        }, this);
        $[62] = t38;
    } else {
        t38 = $[62];
    }
    let t39;
    if ($[63] !== t37) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-16",
            children: [
                t35,
                t37,
                t38
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 419,
            columnNumber: 11
        }, this);
        $[63] = t37;
        $[64] = t39;
    } else {
        t39 = $[64];
    }
    let t40;
    if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid md:grid-cols-3 gap-6",
            children: internationalEvents.map(_HistoryPageInternationalEventsMap)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 427,
            columnNumber: 11
        }, this);
        $[65] = t40;
    } else {
        t40 = $[65];
    }
    let t41;
    if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
            className: "w-12 h-12 mx-auto mb-6 text-white/80"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 434,
            columnNumber: 11
        }, this);
        $[66] = t41;
    } else {
        t41 = $[66];
    }
    let t42;
    if ($[67] !== t) {
        t42 = t("history.global.title", "Global Tamil Network");
        $[67] = t;
        $[68] = t42;
    } else {
        t42 = $[68];
    }
    let t43;
    if ($[69] !== t42) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-2xl sm:text-3xl font-bold mb-4",
            children: t42
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 449,
            columnNumber: 11
        }, this);
        $[69] = t42;
        $[70] = t43;
    } else {
        t43 = $[70];
    }
    let t44;
    if ($[71] !== t) {
        t44 = t("history.global.desc", "A Mumbai Tamil organization that maintains friendship with numerous internationally operating Tamil organizations, unites Tamils globally, participates in Tamil cultural events, and is fully committed to nurturing the mother tongue.");
        $[71] = t;
        $[72] = t44;
    } else {
        t44 = $[72];
    }
    let t45;
    if ($[73] !== t44) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-red-100 max-w-2xl mx-auto leading-relaxed",
            children: t44
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 465,
            columnNumber: 11
        }, this);
        $[73] = t44;
        $[74] = t45;
    } else {
        t45 = $[74];
    }
    let t46;
    if ($[75] !== t43 || $[76] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-16 text-center p-8 sm:p-12 bg-gradient-to-r from-red-600 to-red-700 rounded-3xl",
            children: [
                t41,
                t43,
                t45
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 473,
            columnNumber: 11
        }, this);
        $[75] = t43;
        $[76] = t45;
        $[77] = t46;
    } else {
        t46 = $[77];
    }
    let t47;
    if ($[78] !== t39 || $[79] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-900 text-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-6xl mx-auto",
                    children: [
                        t39,
                        t40,
                        t46
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 482,
                    columnNumber: 104
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 482,
                columnNumber: 64
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 482,
            columnNumber: 11
        }, this);
        $[78] = t39;
        $[79] = t46;
        $[80] = t47;
    } else {
        t47 = $[80];
    }
    let t48;
    if ($[81] !== t) {
        t48 = t("history.cta.title", "Learn More About IPL");
        $[81] = t;
        $[82] = t48;
    } else {
        t48 = $[82];
    }
    let t49;
    if ($[83] !== t48) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold mb-6",
            children: t48
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 499,
            columnNumber: 11
        }, this);
        $[83] = t48;
        $[84] = t49;
    } else {
        t49 = $[84];
    }
    let t50;
    if ($[85] !== t) {
        t50 = t("history.cta.desc", "Discover our journey and join our mission");
        $[85] = t;
        $[86] = t50;
    } else {
        t50 = $[86];
    }
    let t51;
    if ($[87] !== t50) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xl text-red-100 mb-10 leading-relaxed",
            children: t50
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 515,
            columnNumber: 11
        }, this);
        $[87] = t50;
        $[88] = t51;
    } else {
        t51 = $[88];
    }
    let t52;
    if ($[89] !== t) {
        t52 = t("history.cta.profile", "View Profile");
        $[89] = t;
        $[90] = t52;
    } else {
        t52 = $[90];
    }
    let t53;
    if ($[91] !== t52) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/about/ipl-profile",
            className: "px-8 py-4 bg-white text-red-700 rounded-full font-bold shadow-xl hover:bg-amber-50 hover:scale-105 transition-all duration-300",
            children: t52
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 531,
            columnNumber: 11
        }, this);
        $[91] = t52;
        $[92] = t53;
    } else {
        t53 = $[92];
    }
    let t54;
    if ($[93] !== t) {
        t54 = t("history.cta.events", "See Events");
        $[93] = t;
        $[94] = t54;
    } else {
        t54 = $[94];
    }
    let t55;
    if ($[95] !== t54) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/news-events",
            className: "px-8 py-4 bg-transparent text-white border-2 border-white/50 rounded-full font-bold hover:bg-white/10 hover:border-white transition-all duration-300",
            children: t54
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 547,
            columnNumber: 11
        }, this);
        $[95] = t54;
        $[96] = t55;
    } else {
        t55 = $[96];
    }
    let t56;
    if ($[97] !== t53 || $[98] !== t55) {
        t56 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row gap-4 justify-center",
            children: [
                t53,
                t55
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 555,
            columnNumber: 11
        }, this);
        $[97] = t53;
        $[98] = t55;
        $[99] = t56;
    } else {
        t56 = $[99];
    }
    let t57;
    if ($[100] !== t49 || $[101] !== t51 || $[102] !== t56) {
        t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-gradient-to-br from-red-700 to-red-800",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-3xl mx-auto text-center text-white",
                    children: [
                        t49,
                        t51,
                        t56
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 564,
                    columnNumber: 120
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 564,
                columnNumber: 80
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 564,
            columnNumber: 11
        }, this);
        $[100] = t49;
        $[101] = t51;
        $[102] = t56;
        $[103] = t57;
    } else {
        t57 = $[103];
    }
    let t58;
    if ($[104] !== t12 || $[105] !== t19 || $[106] !== t26 || $[107] !== t34 || $[108] !== t47 || $[109] !== t57) {
        t58 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "min-h-screen bg-neutral-50",
            children: [
                t12,
                t19,
                t26,
                t34,
                t47,
                t57
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
            lineNumber: 574,
            columnNumber: 11
        }, this);
        $[104] = t12;
        $[105] = t19;
        $[106] = t26;
        $[107] = t34;
        $[108] = t47;
        $[109] = t57;
        $[110] = t58;
    } else {
        t58 = $[110];
    }
    return t58;
}
_s(HistoryPage, "vu2xTFBfHkv41zWfADiErp1aWcA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = HistoryPage;
function _HistoryPageInternationalEventsMap(event, index_2) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-4xl font-black text-white/20 block mb-4",
                children: event.year
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 588,
                columnNumber: 176
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 text-red-400 text-sm font-medium mb-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                        className: "w-4 h-4"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                        lineNumber: 588,
                        columnNumber: 337
                    }, this),
                    event.location
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 588,
                columnNumber: 258
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-xl font-bold text-white mb-3",
                children: event.title
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 588,
                columnNumber: 389
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-neutral-400 text-sm leading-relaxed",
                children: event.description
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 588,
                columnNumber: 457
            }, this)
        ]
    }, index_2, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
        lineNumber: 588,
        columnNumber: 10
    }, this);
}
function _HistoryPagePublicationsMap(pub, index_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group bg-neutral-50 rounded-2xl p-6 border border-neutral-100 hover:bg-white hover:shadow-xl hover:-translate-y-1 transition-all duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `w-12 h-1.5 ${pub.color} rounded-full mb-4`
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 591,
                columnNumber: 183
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-lg font-bold text-neutral-900 mb-2 group-hover:text-red-700 transition-colors",
                children: pub.title
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 591,
                columnNumber: 246
            }, this),
            pub.pages && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "inline-block px-2 py-1 bg-amber-100 text-amber-800 text-xs font-semibold rounded mb-3",
                children: pub.pages
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 591,
                columnNumber: 375
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-neutral-500 italic",
                children: [
                    "— ",
                    pub.author
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 591,
                columnNumber: 498
            }, this)
        ]
    }, index_1, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
        lineNumber: 591,
        columnNumber: 10
    }, this);
}
function _HistoryPageMilestonesMap(milestone, index_0) {
    const Icon = milestone.icon;
    const isEven = index_0 % 2 === 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative flex items-start gap-8 ${isEven ? "md:flex-row-reverse" : ""}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute left-4 md:left-1/2 w-4 h-4 bg-white border-4 border-red-600 rounded-full -translate-x-1/2 z-10 shadow-sm"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 596,
                columnNumber: 114
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `w-full md:w-[calc(50%-2rem)] ml-12 md:ml-0 ${isEven ? "md:mr-auto md:pr-8" : "md:ml-auto md:pl-8"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-neutral-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4 mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-12 h-12 rounded-xl bg-gradient-to-br ${milestone.color} flex items-center justify-center shadow-lg`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                        className: "w-6 h-6 text-white"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                                        lineNumber: 596,
                                        columnNumber: 681
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                                    lineNumber: 596,
                                    columnNumber: 561
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-2xl sm:text-3xl font-bold text-neutral-900",
                                    children: milestone.year
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                                    lineNumber: 596,
                                    columnNumber: 726
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                            lineNumber: 596,
                            columnNumber: 515
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-xl font-bold text-neutral-900 mb-3",
                            children: milestone.title
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                            lineNumber: 596,
                            columnNumber: 821
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-600 leading-relaxed",
                            children: milestone.description
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                            lineNumber: 596,
                            columnNumber: 899
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                    lineNumber: 596,
                    columnNumber: 365
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 596,
                columnNumber: 247
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "hidden md:block w-[calc(50%-2rem)]"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 596,
                columnNumber: 986
            }, this)
        ]
    }, index_0, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
        lineNumber: 596,
        columnNumber: 10
    }, this);
}
function _HistoryPageAnonymous(stat, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center p-6 bg-neutral-50 rounded-2xl border border-neutral-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-3xl sm:text-4xl font-bold text-red-700 mb-2",
                children: stat.value
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 599,
                columnNumber: 107
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm text-neutral-500 font-medium",
                children: stat.label
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
                lineNumber: 599,
                columnNumber: 191
            }, this)
        ]
    }, index, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/history/page.tsx",
        lineNumber: 599,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "HistoryPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=IPL-Website-test-main_src_app_about_history_page_tsx_377fb0d8._.js.map