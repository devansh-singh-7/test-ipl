(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/37e5c_6e9a00e3._.js",
  "static/chunks/IPL-Website-test-main_src_app_about_ipl-presidents-blog_page_tsx_9ed74cbb._.js"
],
    source: "dynamic"
});
