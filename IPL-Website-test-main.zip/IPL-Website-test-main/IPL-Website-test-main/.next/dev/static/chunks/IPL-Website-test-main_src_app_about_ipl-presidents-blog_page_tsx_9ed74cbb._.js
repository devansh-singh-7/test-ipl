(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PresidentBlogPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/file-text.js [app-client] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/external-link.js [app-client] (ecmascript) <export default as ExternalLink>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function PresidentBlogPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(134);
    if ($[0] !== "da1831b2e6e422e4e2b0128b1fdca97269cc55b54a1c2f17c4e37ba27fb08663") {
        for(let $i = 0; $i < 134; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "da1831b2e6e422e4e2b0128b1fdca97269cc55b54a1c2f17c4e37ba27fb08663";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let totalPages;
    if ($[1] !== currentPage || $[2] !== t) {
        const blogPosts = [
            {
                id: 1,
                titleKey: "blog.posts.silverJubilee.title",
                descKey: "blog.posts.silverJubilee.desc",
                date: "2020",
                imageUrl: "https://images.unsplash.com/photo-1464660756002-dd1ee6debbe4?w=800&q=80",
                featured: true
            },
            {
                id: 2,
                titleKey: "blog.posts.friendship27.title",
                descKey: "blog.posts.friendship27.desc",
                date: "2024",
                imageUrl: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&q=80",
                featured: true
            },
            {
                id: 3,
                titleKey: "blog.posts.pongal2024.title",
                descKey: "blog.posts.pongal2024.desc",
                date: "January 2024",
                imageUrl: "https://images.unsplash.com/photo-1610732821891-3ab90e94eb00?w=800&q=80",
                featured: false
            },
            {
                id: 4,
                titleKey: "blog.posts.souvenir2023.title",
                descKey: "blog.posts.souvenir2023.desc",
                date: "2023",
                imageUrl: "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=800&q=80",
                featured: false
            },
            {
                id: 5,
                titleKey: "blog.posts.isroVisit.title",
                descKey: "blog.posts.isroVisit.desc",
                date: "November 2022",
                imageUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800&q=80",
                featured: false
            },
            {
                id: 6,
                titleKey: "blog.posts.agm19.title",
                descKey: "blog.posts.agm19.desc",
                date: "May 2022",
                imageUrl: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=800&q=80",
                featured: false
            },
            {
                id: 7,
                titleKey: "blog.posts.secretaryWedding.title",
                descKey: "blog.posts.secretaryWedding.desc",
                date: "January 2022",
                imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?w=800&q=80",
                featured: false
            },
            {
                id: 8,
                titleKey: "blog.posts.calendar2022.title",
                descKey: "blog.posts.calendar2022.desc",
                date: "2022",
                imageUrl: "https://images.unsplash.com/photo-1506784365847-bbad939e9335?w=800&q=80",
                featured: false
            },
            {
                id: 9,
                titleKey: "blog.posts.cmLetter.title",
                descKey: "blog.posts.cmLetter.desc",
                date: "November 2021",
                imageUrl: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=800&q=80",
                featured: false
            },
            {
                id: 10,
                titleKey: "blog.posts.hajTravel.title",
                descKey: "blog.posts.hajTravel.desc",
                date: "November 2021",
                imageUrl: "https://images.unsplash.com/photo-1564769625905-50e93615e769?w=800&q=80",
                featured: false
            },
            {
                id: 11,
                titleKey: "blog.posts.diaspora.title",
                descKey: "blog.posts.diaspora.desc",
                date: "October 2021",
                imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
                featured: false
            },
            {
                id: 12,
                titleKey: "blog.posts.lifetimeAward.title",
                descKey: "blog.posts.lifetimeAward.desc",
                date: "2021",
                imageUrl: "https://images.unsplash.com/photo-1567427017947-545c5f8d16ad?w=800&q=80",
                featured: true
            },
            {
                id: 13,
                titleKey: "blog.posts.chancellor.title",
                descKey: "blog.posts.chancellor.desc",
                date: "2018",
                imageUrl: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&q=80",
                featured: false
            },
            {
                id: 14,
                titleKey: "blog.posts.airport.title",
                descKey: "blog.posts.airport.desc",
                date: "February 2021",
                imageUrl: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=800&q=80",
                featured: false
            },
            {
                id: 15,
                titleKey: "blog.posts.pongal2020.title",
                descKey: "blog.posts.pongal2020.desc",
                date: "January 2020",
                imageUrl: "https://images.unsplash.com/photo-1610732821891-3ab90e94eb00?w=800&q=80",
                featured: false
            },
            {
                id: 16,
                titleKey: "blog.posts.covidRelief.title",
                descKey: "blog.posts.covidRelief.desc",
                date: "2020",
                imageUrl: "https://images.unsplash.com/photo-1584744982493-c48f5f1ad8f8?w=800&q=80",
                featured: false
            },
            {
                id: 17,
                titleKey: "blog.posts.chessAcademy.title",
                descKey: "blog.posts.chessAcademy.desc",
                date: "2020",
                imageUrl: "https://images.unsplash.com/photo-1529699211952-734e80c4d42b?w=800&q=80",
                featured: false
            },
            {
                id: 18,
                titleKey: "blog.posts.souvenir2019.title",
                descKey: "blog.posts.souvenir2019.desc",
                date: "2019",
                imageUrl: "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=800&q=80",
                featured: false
            }
        ];
        totalPages = Math.ceil(blogPosts.length / 6);
        const startIndex = (currentPage - 1) * 6;
        const endIndex = startIndex + 6;
        const currentPosts = blogPosts.slice(startIndex, endIndex);
        t5 = "min-h-screen bg-white";
        let t9;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = {
                minHeight: "320px"
            };
            $[13] = t9;
        } else {
            t9 = $[13];
        }
        let t10;
        if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 z-0 pointer-events-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: "/Images/iplbanner.png",
                        alt: "President Blog background",
                        className: "w-[85%] h-full opacity-40 object-contain mx-auto",
                        style: {
                            objectPosition: "center"
                        }
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                        lineNumber: 174,
                        columnNumber: 71
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: "absolute",
                            inset: 0,
                            backgroundColor: "rgba(0,0,0,0.04)"
                        }
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                        lineNumber: 176,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 174,
                columnNumber: 13
            }, this);
            $[14] = t10;
        } else {
            t10 = $[14];
        }
        let t11;
        if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "inline-block p-3 sm:p-4 bg-purple-50 rounded-full mb-4 sm:mb-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                    className: "w-10 h-10 sm:w-12 sm:h-12 text-purple-700"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                    lineNumber: 187,
                    columnNumber: 93
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 187,
                columnNumber: 13
            }, this);
            $[15] = t11;
        } else {
            t11 = $[15];
        }
        let t12;
        if ($[16] !== t) {
            t12 = t("blog.hero.title");
            $[16] = t;
            $[17] = t12;
        } else {
            t12 = $[17];
        }
        let t13;
        if ($[18] !== t12) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 px-2",
                children: t12
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 202,
                columnNumber: 13
            }, this);
            $[18] = t12;
            $[19] = t13;
        } else {
            t13 = $[19];
        }
        let t14;
        if ($[20] !== t) {
            t14 = t("blog.hero.subtitle");
            $[20] = t;
            $[21] = t14;
        } else {
            t14 = $[21];
        }
        let t15;
        if ($[22] !== t14) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-lg sm:text-xl px-4",
                children: t14
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 218,
                columnNumber: 13
            }, this);
            $[22] = t14;
            $[23] = t15;
        } else {
            t15 = $[23];
        }
        if ($[24] !== t13 || $[25] !== t15) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative bg-transparent pt-12 md:pt-16 lg:pt-20 pb-8 overflow-hidden",
                style: t9,
                children: [
                    t10,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10 container mx-auto px-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-4xl mx-auto text-center",
                            children: [
                                t11,
                                t13,
                                t15
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                            lineNumber: 225,
                            columnNumber: 172
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                        lineNumber: 225,
                        columnNumber: 118
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 225,
                columnNumber: 12
            }, this);
            $[24] = t13;
            $[25] = t15;
            $[26] = t6;
        } else {
            t6 = $[26];
        }
        let t16;
        if ($[27] !== t) {
            t16 = t("blog.intro.desc");
            $[27] = t;
            $[28] = t16;
        } else {
            t16 = $[28];
        }
        if ($[29] !== t16) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-12 sm:py-16 bg-neutral-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-4xl mx-auto text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-base sm:text-lg text-gray-700 leading-relaxed",
                            children: t16
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                            lineNumber: 241,
                            columnNumber: 149
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                        lineNumber: 241,
                        columnNumber: 102
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                    lineNumber: 241,
                    columnNumber: 62
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 241,
                columnNumber: 12
            }, this);
            $[29] = t16;
            $[30] = t7;
        } else {
            t7 = $[30];
        }
        let t17;
        if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                className: "w-10 h-10 text-purple-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 249,
                columnNumber: 13
            }, this);
            $[31] = t17;
        } else {
            t17 = $[31];
        }
        let t18;
        if ($[32] !== t) {
            t18 = t("blog.featured.title");
            $[32] = t;
            $[33] = t18;
        } else {
            t18 = $[33];
        }
        let t19;
        if ($[34] !== t18) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-12",
                children: [
                    t17,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-4xl font-bold text-neutral-900",
                        children: t18
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                        lineNumber: 264,
                        columnNumber: 65
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 264,
                columnNumber: 13
            }, this);
            $[34] = t18;
            $[35] = t19;
        } else {
            t19 = $[35];
        }
        const t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid md:grid-cols-2 gap-8",
            children: blogPosts.filter(_PresidentBlogPageBlogPostsFilter).map({
                "PresidentBlogPage[(anonymous)()]": (post_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "group bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative h-64 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: post_0.imageUrl,
                                        alt: t(post_0.titleKey),
                                        fill: true,
                                        className: "object-cover group-hover:scale-110 transition-transform duration-300"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                        lineNumber: 271,
                                        columnNumber: 249
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute top-4 right-4 px-4 py-2 bg-purple-700 text-white rounded-lg font-semibold",
                                        children: post_0.date
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                        lineNumber: 271,
                                        columnNumber: 398
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                lineNumber: 271,
                                columnNumber: 202
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-2xl font-bold text-neutral-900 mb-4 group-hover:text-purple-700 transition-colors",
                                        children: t(post_0.titleKey)
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                        lineNumber: 271,
                                        columnNumber: 544
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-neutral-600 leading-relaxed mb-6",
                                        children: t(post_0.descKey)
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                        lineNumber: 271,
                                        columnNumber: 672
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 text-purple-700 font-semibold group-hover:gap-4 transition-all",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: t("blog.readMore")
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                                lineNumber: 271,
                                                columnNumber: 852
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                className: "w-5 h-5"
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                                lineNumber: 271,
                                                columnNumber: 885
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                        lineNumber: 271,
                                        columnNumber: 748
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                lineNumber: 271,
                                columnNumber: 523
                            }, this)
                        ]
                    }, post_0.id, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                        lineNumber: 271,
                        columnNumber: 55
                    }, this)
            }["PresidentBlogPage[(anonymous)()]"])
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 270,
            columnNumber: 17
        }, this);
        if ($[36] !== t19 || $[37] !== t20) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-20 px-4 bg-linear-to-br from-purple-50 to-pink-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-6xl mx-auto",
                    children: [
                        t19,
                        t20
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                    lineNumber: 274,
                    columnNumber: 86
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 274,
                columnNumber: 12
            }, this);
            $[36] = t19;
            $[37] = t20;
            $[38] = t8;
        } else {
            t8 = $[38];
        }
        t4 = "py-20 px-4";
        t2 = "max-w-6xl mx-auto";
        let t21;
        if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
            t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                className: "w-10 h-10 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 285,
                columnNumber: 13
            }, this);
            $[39] = t21;
        } else {
            t21 = $[39];
        }
        let t22;
        if ($[40] !== t) {
            t22 = t("blog.allPosts.title");
            $[40] = t;
            $[41] = t22;
        } else {
            t22 = $[41];
        }
        if ($[42] !== t22) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-12",
                children: [
                    t21,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-4xl font-bold text-neutral-900",
                        children: t22
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                        lineNumber: 299,
                        columnNumber: 64
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 299,
                columnNumber: 12
            }, this);
            $[42] = t22;
            $[43] = t3;
        } else {
            t3 = $[43];
        }
        t0 = "grid md:grid-cols-2 lg:grid-cols-3 gap-8";
        t1 = currentPosts.map({
            "PresidentBlogPage[currentPosts.map()]": (post_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "group bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative h-48 overflow-hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: post_1.imageUrl,
                                    alt: t(post_1.titleKey),
                                    fill: true,
                                    className: "object-cover group-hover:scale-110 transition-transform duration-300"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                    lineNumber: 307,
                                    columnNumber: 236
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute top-4 right-4 px-3 py-1 bg-red-700 text-white rounded-lg text-sm font-semibold",
                                    children: post_1.date
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                    lineNumber: 307,
                                    columnNumber: 385
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                            lineNumber: 307,
                            columnNumber: 189
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xl font-bold text-neutral-900 mb-3 group-hover:text-red-700 transition-colors line-clamp-2",
                                    children: t(post_1.titleKey)
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                    lineNumber: 307,
                                    columnNumber: 536
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-neutral-600 text-sm leading-relaxed line-clamp-3 mb-4",
                                    children: t(post_1.descKey)
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                    lineNumber: 307,
                                    columnNumber: 673
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 text-red-700 font-semibold text-sm group-hover:gap-3 transition-all",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: t("blog.readMore")
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                            lineNumber: 307,
                                            columnNumber: 879
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                            className: "w-4 h-4"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                            lineNumber: 307,
                                            columnNumber: 912
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                    lineNumber: 307,
                                    columnNumber: 770
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                            lineNumber: 307,
                            columnNumber: 515
                        }, this)
                    ]
                }, post_1.id, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                    lineNumber: 307,
                    columnNumber: 58
                }, this)
        }["PresidentBlogPage[currentPosts.map()]"]);
        $[1] = currentPage;
        $[2] = t;
        $[3] = t0;
        $[4] = t1;
        $[5] = t2;
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
        $[9] = t6;
        $[10] = t7;
        $[11] = t8;
        $[12] = totalPages;
    } else {
        t0 = $[3];
        t1 = $[4];
        t2 = $[5];
        t3 = $[6];
        t4 = $[7];
        t5 = $[8];
        t6 = $[9];
        t7 = $[10];
        t8 = $[11];
        totalPages = $[12];
    }
    let t9;
    if ($[44] !== t0 || $[45] !== t1) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t0,
            children: t1
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 335,
            columnNumber: 10
        }, this);
        $[44] = t0;
        $[45] = t1;
        $[46] = t9;
    } else {
        t9 = $[46];
    }
    let t10;
    if ($[47] !== currentPage || $[48] !== t || $[49] !== totalPages) {
        t10 = totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-center items-center gap-4 mt-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: {
                        "PresidentBlogPage[<button>.onClick]": ()=>setCurrentPage(_PresidentBlogPageButtonOnClickSetCurrentPage)
                    }["PresidentBlogPage[<button>.onClick]"],
                    disabled: currentPage === 1,
                    className: "px-6 py-3 bg-neutral-200 text-neutral-700 rounded-lg font-semibold hover:bg-neutral-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                    children: t("blog.pagination.previous")
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                    lineNumber: 344,
                    columnNumber: 91
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: Array.from({
                        length: totalPages
                    }, _PresidentBlogPageArrayFrom).map({
                        "PresidentBlogPage[(anonymous)()]": (page)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: {
                                    "PresidentBlogPage[(anonymous)() > <button>.onClick]": ()=>setCurrentPage(page)
                                }["PresidentBlogPage[(anonymous)() > <button>.onClick]"],
                                className: `w-12 h-12 rounded-lg font-semibold transition-all ${currentPage === page ? "bg-red-700 text-white shadow-lg scale-110" : "bg-white text-neutral-700 hover:bg-neutral-100"}`,
                                children: page
                            }, page, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                                lineNumber: 349,
                                columnNumber: 55
                            }, this)
                    }["PresidentBlogPage[(anonymous)()]"])
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                    lineNumber: 346,
                    columnNumber: 284
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: {
                        "PresidentBlogPage[<button>.onClick]": ()=>setCurrentPage({
                                "PresidentBlogPage[<button>.onClick > setCurrentPage()]": (prev_0)=>Math.min(totalPages, prev_0 + 1)
                            }["PresidentBlogPage[<button>.onClick > setCurrentPage()]"])
                    }["PresidentBlogPage[<button>.onClick]"],
                    disabled: currentPage === totalPages,
                    className: "px-6 py-3 bg-neutral-200 text-neutral-700 rounded-lg font-semibold hover:bg-neutral-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                    children: t("blog.pagination.next")
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                    lineNumber: 352,
                    columnNumber: 54
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 344,
            columnNumber: 29
        }, this);
        $[47] = currentPage;
        $[48] = t;
        $[49] = totalPages;
        $[50] = t10;
    } else {
        t10 = $[50];
    }
    let t11;
    if ($[51] !== t10 || $[52] !== t2 || $[53] !== t3 || $[54] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: [
                t3,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 366,
            columnNumber: 11
        }, this);
        $[51] = t10;
        $[52] = t2;
        $[53] = t3;
        $[54] = t9;
        $[55] = t11;
    } else {
        t11 = $[55];
    }
    let t12;
    if ($[56] !== t11 || $[57] !== t4) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t4,
            children: t11
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 377,
            columnNumber: 11
        }, this);
        $[56] = t11;
        $[57] = t4;
        $[58] = t12;
    } else {
        t12 = $[58];
    }
    let t13;
    if ($[59] !== t) {
        t13 = t("blog.highlights.title");
        $[59] = t;
        $[60] = t13;
    } else {
        t13 = $[60];
    }
    let t14;
    if ($[61] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-4xl font-bold text-neutral-900 mb-12 text-center",
            children: t13
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 394,
            columnNumber: 11
        }, this);
        $[61] = t13;
        $[62] = t14;
    } else {
        t14 = $[62];
    }
    let t15;
    if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-16 h-16 bg-linear-to-br from-purple-100 to-pink-100 rounded-xl flex items-center justify-center mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                className: "w-8 h-8 text-purple-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 402,
                columnNumber: 131
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 402,
            columnNumber: 11
        }, this);
        $[63] = t15;
    } else {
        t15 = $[63];
    }
    let t16;
    if ($[64] !== t) {
        t16 = t("blog.highlights.award.title");
        $[64] = t;
        $[65] = t16;
    } else {
        t16 = $[65];
    }
    let t17;
    if ($[66] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-2xl font-bold text-neutral-900 mb-4",
            children: t16
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 417,
            columnNumber: 11
        }, this);
        $[66] = t16;
        $[67] = t17;
    } else {
        t17 = $[67];
    }
    let t18;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-700 leading-relaxed",
            children: 'திரு. மா. கருண் அவர்களுக்கு "வாழ்நாள் சாதனையாளர் விருது" வழங்கப்பட்டது. இந்தியப் பேனாநண்பர் பேரவையின் தலைவரான மா. கருண் அவர்கள் சமூக நலத்தில் ஆற்றிய பங்களிப்புக்காக இவ்விருது வழங்கப்பட்டது.'
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 425,
            columnNumber: 11
        }, this);
        $[68] = t18;
    } else {
        t18 = $[68];
    }
    let t19;
    if ($[69] !== t17) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl p-8",
            children: [
                t15,
                t17,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 432,
            columnNumber: 11
        }, this);
        $[69] = t17;
        $[70] = t19;
    } else {
        t19 = $[70];
    }
    let t20;
    if ($[71] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-16 h-16 bg-linear-to-br from-blue-100 to-cyan-100 rounded-xl flex items-center justify-center mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                className: "w-8 h-8 text-blue-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 440,
                columnNumber: 129
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 440,
            columnNumber: 11
        }, this);
        $[71] = t20;
    } else {
        t20 = $[71];
    }
    let t21;
    if ($[72] !== t) {
        t21 = t("blog.highlights.isro.title");
        $[72] = t;
        $[73] = t21;
    } else {
        t21 = $[73];
    }
    let t22;
    if ($[74] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-2xl font-bold text-neutral-900 mb-4",
            children: t21
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 455,
            columnNumber: 11
        }, this);
        $[74] = t21;
        $[75] = t22;
    } else {
        t22 = $[75];
    }
    let t23;
    if ($[76] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-700 leading-relaxed",
            children: "பேரவைத் தலைவர் மா.கருண் - இந்திய விண்வெளி ஆராய்ச்சி மையத்தின் மேனாள் தலைவர் சந்திப்பு. இந்திய விண்வெளி ஆராய்ச்சி அமைப்பின் (ISRO) தலைவரை சந்தித்து வாழ்த்துக்களை பகிர்ந்து கொண்டார்."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 463,
            columnNumber: 11
        }, this);
        $[76] = t23;
    } else {
        t23 = $[76];
    }
    let t24;
    if ($[77] !== t22) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl p-8",
            children: [
                t20,
                t22,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 470,
            columnNumber: 11
        }, this);
        $[77] = t22;
        $[78] = t24;
    } else {
        t24 = $[78];
    }
    let t25;
    if ($[79] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-16 h-16 bg-linear-to-br from-green-100 to-emerald-100 rounded-xl flex items-center justify-center mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                className: "w-8 h-8 text-green-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 478,
                columnNumber: 133
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 478,
            columnNumber: 11
        }, this);
        $[79] = t25;
    } else {
        t25 = $[79];
    }
    let t26;
    if ($[80] !== t) {
        t26 = t("blog.highlights.calendar.title");
        $[80] = t;
        $[81] = t26;
    } else {
        t26 = $[81];
    }
    let t27;
    if ($[82] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-2xl font-bold text-neutral-900 mb-4",
            children: t26
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 493,
            columnNumber: 11
        }, this);
        $[82] = t26;
        $[83] = t27;
    } else {
        t27 = $[83];
    }
    let t28;
    if ($[84] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-700 leading-relaxed",
            children: "இந்தியப் பேனாநண்பர் பேரவை தலைமை அலுவலகத்தில் பேரவை நாட்காட்டி - 2022 வெளியீடு. பேரவையின் முக்கிய நிகழ்வுகள் மற்றும் சமூக நல செயல்பாடுகள் இடம்பெற்ற நாட்காட்டி வெளியிடப்பட்டது."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 501,
            columnNumber: 11
        }, this);
        $[84] = t28;
    } else {
        t28 = $[84];
    }
    let t29;
    if ($[85] !== t27) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl p-8",
            children: [
                t25,
                t27,
                t28
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 508,
            columnNumber: 11
        }, this);
        $[85] = t27;
        $[86] = t29;
    } else {
        t29 = $[86];
    }
    let t30;
    if ($[87] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-16 h-16 bg-linear-to-br from-red-100 to-orange-100 rounded-xl flex items-center justify-center mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 516,
                columnNumber: 130
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 516,
            columnNumber: 11
        }, this);
        $[87] = t30;
    } else {
        t30 = $[87];
    }
    let t31;
    if ($[88] !== t) {
        t31 = t("blog.highlights.jubilee.title");
        $[88] = t;
        $[89] = t31;
    } else {
        t31 = $[89];
    }
    let t32;
    if ($[90] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-2xl font-bold text-neutral-900 mb-4",
            children: t31
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 531,
            columnNumber: 11
        }, this);
        $[90] = t31;
        $[91] = t32;
    } else {
        t32 = $[91];
    }
    let t33;
    if ($[92] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-700 leading-relaxed",
            children: "IPL' SILVER JUBILEE YEAR: 1995 - 2020. இந்தியப் பேனாநண்பர் பேரவையின் 25வது ஆண்டு வெள்ளி விழா கொண்டாட்டங்கள் பிரமாண்டமாக நடைபெற்றன. 25 ஆண்டுகால பயணத்தின் சாதனைகள் கொண்டாடப்பட்டன."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 539,
            columnNumber: 11
        }, this);
        $[92] = t33;
    } else {
        t33 = $[92];
    }
    let t34;
    if ($[93] !== t32) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl p-8",
            children: [
                t30,
                t32,
                t33
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 546,
            columnNumber: 11
        }, this);
        $[93] = t32;
        $[94] = t34;
    } else {
        t34 = $[94];
    }
    let t35;
    if ($[95] !== t19 || $[96] !== t24 || $[97] !== t29 || $[98] !== t34) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid md:grid-cols-2 gap-8",
            children: [
                t19,
                t24,
                t29,
                t34
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 554,
            columnNumber: 11
        }, this);
        $[95] = t19;
        $[96] = t24;
        $[97] = t29;
        $[98] = t34;
        $[99] = t35;
    } else {
        t35 = $[99];
    }
    let t36;
    if ($[100] !== t14 || $[101] !== t35) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 px-4 bg-linear-to-br from-red-50 to-orange-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-6xl mx-auto",
                children: [
                    t14,
                    t35
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 565,
                columnNumber: 84
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 565,
            columnNumber: 11
        }, this);
        $[100] = t14;
        $[101] = t35;
        $[102] = t36;
    } else {
        t36 = $[102];
    }
    let t37;
    if ($[103] !== t) {
        t37 = t("blog.cta.title");
        $[103] = t;
        $[104] = t37;
    } else {
        t37 = $[104];
    }
    let t38;
    if ($[105] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-4xl md:text-5xl font-bold text-white mb-6",
            children: t37
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 582,
            columnNumber: 11
        }, this);
        $[105] = t37;
        $[106] = t38;
    } else {
        t38 = $[106];
    }
    let t39;
    if ($[107] !== t) {
        t39 = t("blog.cta.desc");
        $[107] = t;
        $[108] = t39;
    } else {
        t39 = $[108];
    }
    let t40;
    if ($[109] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xl text-white/90 mb-8",
            children: t39
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 598,
            columnNumber: 11
        }, this);
        $[109] = t39;
        $[110] = t40;
    } else {
        t40 = $[110];
    }
    let t41;
    if ($[111] !== t) {
        t41 = t("blog.cta.news");
        $[111] = t;
        $[112] = t41;
    } else {
        t41 = $[112];
    }
    let t42;
    if ($[113] !== t41) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/news-events",
            className: "px-8 py-4 bg-white text-indigo-700 rounded-xl font-semibold hover:bg-neutral-100 transition-colors shadow-lg hover:shadow-xl",
            children: t41
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 614,
            columnNumber: 11
        }, this);
        $[113] = t41;
        $[114] = t42;
    } else {
        t42 = $[114];
    }
    let t43;
    if ($[115] !== t) {
        t43 = t("blog.cta.contact");
        $[115] = t;
        $[116] = t43;
    } else {
        t43 = $[116];
    }
    let t44;
    if ($[117] !== t43) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/contact",
            className: "px-8 py-4 bg-transparent text-white border-2 border-white rounded-xl font-semibold hover:bg-white/10 transition-colors shadow-lg hover:shadow-xl",
            children: t43
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 630,
            columnNumber: 11
        }, this);
        $[117] = t43;
        $[118] = t44;
    } else {
        t44 = $[118];
    }
    let t45;
    if ($[119] !== t42 || $[120] !== t44) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row gap-4 justify-center",
            children: [
                t42,
                t44
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 638,
            columnNumber: 11
        }, this);
        $[119] = t42;
        $[120] = t44;
        $[121] = t45;
    } else {
        t45 = $[121];
    }
    let t46;
    if ($[122] !== t38 || $[123] !== t40 || $[124] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 px-4 bg-linear-to-r from-indigo-700 to-purple-700",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-4xl mx-auto text-center",
                children: [
                    t38,
                    t40,
                    t45
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
                lineNumber: 647,
                columnNumber: 88
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 647,
            columnNumber: 11
        }, this);
        $[122] = t38;
        $[123] = t40;
        $[124] = t45;
        $[125] = t46;
    } else {
        t46 = $[125];
    }
    let t47;
    if ($[126] !== t12 || $[127] !== t36 || $[128] !== t46 || $[129] !== t5 || $[130] !== t6 || $[131] !== t7 || $[132] !== t8) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: t5,
            children: [
                t6,
                t7,
                t8,
                t12,
                t36,
                t46
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-presidents-blog/page.tsx",
            lineNumber: 657,
            columnNumber: 11
        }, this);
        $[126] = t12;
        $[127] = t36;
        $[128] = t46;
        $[129] = t5;
        $[130] = t6;
        $[131] = t7;
        $[132] = t8;
        $[133] = t47;
    } else {
        t47 = $[133];
    }
    return t47;
}
_s(PresidentBlogPage, "XgzSaEje7k8kFuGwQqGrTS91LrM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = PresidentBlogPage;
function _PresidentBlogPageArrayFrom(_, i) {
    return i + 1;
}
function _PresidentBlogPageButtonOnClickSetCurrentPage(prev) {
    return Math.max(1, prev - 1);
}
function _PresidentBlogPageBlogPostsFilter(post) {
    return post.featured;
}
var _c;
__turbopack_context__.k.register(_c, "PresidentBlogPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=IPL-Website-test-main_src_app_about_ipl-presidents-blog_page_tsx_9ed74cbb._.js.map