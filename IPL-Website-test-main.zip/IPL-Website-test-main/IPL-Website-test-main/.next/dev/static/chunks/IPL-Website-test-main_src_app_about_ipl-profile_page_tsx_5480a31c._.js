(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>IPLProfilePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript) <export default as Globe>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function IPLProfilePage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(123);
    if ($[0] !== "fd641e3b15a51ffb72815ab524a345505892520da2ca12a573ac681a3b12ea08") {
        for(let $i = 0; $i < 123; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fd641e3b15a51ffb72815ab524a345505892520da2ca12a573ac681a3b12ea08";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [
            {
                title: "Eye Camps",
                titleTa: "\u0B95\u0BA3\u0BCD \u0BAE\u0BC1\u0B95\u0BBE\u0BAE\u0BCD\u0B95\u0BB3\u0BCD",
                count: "31+",
                icon: "\uD83D\uDC41\uFE0F",
                color: "from-blue-500 to-cyan-600"
            },
            {
                title: "Friendship Meets",
                titleTa: "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
                count: "28+",
                icon: "\uD83E\uDD1D",
                color: "from-red-500 to-rose-600"
            },
            {
                title: "States Reached",
                titleTa: "\u0BAE\u0BBE\u0BA8\u0BBF\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
                count: "15+",
                icon: "\uD83D\uDDFA\uFE0F",
                color: "from-emerald-500 to-teal-600"
            },
            {
                title: "Years of Service",
                titleTa: "\u0B9A\u0BC7\u0BB5\u0BC8 \u0B86\u0BA3\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD",
                count: "30+",
                icon: "\uD83C\uDF89",
                color: "from-amber-500 to-orange-600"
            }
        ];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const achievements = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [
            {
                title: "Bombay Societies Act, 1950",
                detail: "Registered as a Social Welfare Trust",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"]
            },
            {
                title: "Bombay Public Trust Act",
                detail: "Registration #F23778",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"]
            },
            {
                title: "Section 80G Certificate",
                detail: "Tax benefit for donors",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"]
            },
            {
                title: "Social Welfare Trust",
                detail: "Serving communities since 1995",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"]
            }
        ];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const registrations = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [
            {
                year: "1995",
                location: "Mumbai (Inauguration)",
                locationTa: "\u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8 (\u0BA4\u0BC1\u0BB5\u0B95\u0BCD\u0B95 \u0BB5\u0BBF\u0BB4\u0BBE)"
            },
            {
                year: "1996",
                location: "Thanjavur",
                locationTa: "\u0BA4\u0B9E\u0BCD\u0B9A\u0BBE\u0BB5\u0BC2\u0BB0\u0BCD"
            },
            {
                year: "1997",
                location: "Kolar Gold Fields",
                locationTa: "\u0B95\u0BCB\u0BB2\u0BBE\u0BB0\u0BCD \u0BA4\u0B99\u0BCD\u0B95 \u0BB5\u0BAF\u0BB2\u0BCD"
            },
            {
                year: "1998",
                location: "Chennai",
                locationTa: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8"
            },
            {
                year: "1999",
                location: "Karur",
                locationTa: "\u0B95\u0BB0\u0BC2\u0BB0\u0BCD"
            },
            {
                year: "2000",
                location: "Senkam",
                locationTa: "\u0B9A\u0BC6\u0B99\u0BCD\u0B95\u0BAE\u0BCD"
            },
            {
                year: "2010",
                location: "Coimbatore",
                locationTa: "\u0B95\u0BCB\u0BB5\u0BC8"
            },
            {
                year: "2019",
                location: "Namakkal",
                locationTa: "\u0BA8\u0BBE\u0BAE\u0B95\u0BCD\u0B95\u0BB2\u0BCD"
            },
            {
                year: "2023",
                location: "New Delhi",
                locationTa: "\u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF"
            },
            {
                year: "2024",
                location: "Kuttalam",
                locationTa: "\u0B95\u0BC1\u0B9F\u0BCD\u0B9F\u0BBE\u0BB2\u0BAE\u0BCD"
            }
        ];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const friendshipMeets = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 z-0",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/Images/iplbanner.png",
                    alt: "IPL Profile background",
                    fill: true,
                    className: "object-cover opacity-15",
                    priority: true
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 124,
                    columnNumber: 48
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 bg-gradient-to-b from-neutral-50/80 via-neutral-50/60 to-neutral-50"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 124,
                    columnNumber: 178
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 124,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-red-100 shadow-sm mb-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                    className: "w-4 h-4 text-red-700"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 131,
                    columnNumber: 127
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-semibold tracking-wider uppercase text-red-800",
                    children: "About IPL"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 131,
                    columnNumber: 169
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 131,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== t) {
        t5 = t("profile.hero.title", "IPL Profile");
        $[6] = t;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-4xl sm:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6 leading-tight",
            children: t5
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 146,
            columnNumber: 10
        }, this);
        $[8] = t5;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== t) {
        t7 = t("profile.hero.subtitle", "Spreading Love, Friendship & Humanity Since 1995");
        $[10] = t;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg sm:text-xl text-neutral-600 max-w-2xl mx-auto leading-relaxed",
            children: t7
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 162,
            columnNumber: 10
        }, this);
        $[12] = t7;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center gap-4 mt-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-px w-16 bg-gradient-to-r from-transparent to-red-300"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 170,
                    columnNumber: 71
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-red-700 font-semibold",
                    children: "Est. March 12, 1995"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 170,
                    columnNumber: 145
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-px w-16 bg-gradient-to-l from-transparent to-red-300"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 170,
                    columnNumber: 216
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 170,
            columnNumber: 10
        }, this);
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== t6 || $[16] !== t8) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative pt-24 pb-16 overflow-hidden",
            children: [
                t3,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 relative z-10",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-4xl mx-auto text-center",
                        children: [
                            t4,
                            t6,
                            t8,
                            t9
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 177,
                        columnNumber: 127
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 177,
                    columnNumber: 73
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 177,
            columnNumber: 11
        }, this);
        $[15] = t6;
        $[16] = t8;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-16 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 md:grid-cols-4 gap-6",
                        children: achievements.map(_IPLProfilePageAchievementsMap)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 186,
                        columnNumber: 122
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 186,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 186,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-red-50 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 193,
                columnNumber: 105
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 193,
            columnNumber: 11
        }, this);
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    let t13;
    if ($[20] !== t) {
        t13 = t("profile.inception.title", "Inception of the League");
        $[20] = t;
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t12,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
                    children: t13
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 208,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[22] = t13;
        $[23] = t14;
    } else {
        t14 = $[23];
    }
    let t15;
    if ($[24] !== t) {
        t15 = t("profile.inception.desc", "Hearts enriched with love, friendship, and humanitarian thoughts, eliminating caste, religious, and political differences - this is the Indian Penpals League, a beautiful friendship world.");
        $[24] = t;
        $[25] = t15;
    } else {
        t15 = $[25];
    }
    let t16;
    if ($[26] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-neutral-700 leading-relaxed mb-6",
            children: t15
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 224,
            columnNumber: 11
        }, this);
        $[26] = t15;
        $[27] = t16;
    } else {
        t16 = $[27];
    }
    let t17;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6 bg-red-50 rounded-2xl border-l-4 border-red-600",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-neutral-700 italic leading-relaxed",
                children: "அன்பு, நட்பு, மனிதநேய சிந்தனைகளால் செழுமையடைந்த இதயங்கள், சாதி, மத மற்றும் அரசியல் வேறுபாடுகளை நீக்கி - இது இந்தியப் பேனாநண்பர் பேரவை, ஒரு அழகான நட்புலகம்."
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 232,
                columnNumber: 80
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 232,
            columnNumber: 11
        }, this);
        $[28] = t17;
    } else {
        t17 = $[28];
    }
    let t18;
    if ($[29] !== t16) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-3xl p-8 sm:p-12 shadow-sm border border-neutral-100",
            children: [
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 239,
            columnNumber: 11
        }, this);
        $[29] = t16;
        $[30] = t18;
    } else {
        t18 = $[30];
    }
    let t19;
    if ($[31] !== t14 || $[32] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto",
                    children: [
                        t14,
                        t18
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 247,
                    columnNumber: 92
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 247,
                columnNumber: 52
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 247,
            columnNumber: 11
        }, this);
        $[31] = t14;
        $[32] = t18;
        $[33] = t19;
    } else {
        t19 = $[33];
    }
    let t20;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-14 h-14 bg-amber-50 rounded-xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__["Globe"], {
                className: "w-7 h-7 text-amber-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 256,
                columnNumber: 106
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 256,
            columnNumber: 11
        }, this);
        $[34] = t20;
    } else {
        t20 = $[34];
    }
    let t21;
    if ($[35] !== t) {
        t21 = t("profile.growth.title", "\u0BAA\u0BC7\u0BB0\u0BB5\u0BC8\u0BAF\u0BBF\u0BA9\u0BCD \u0BB5\u0BB3\u0BB0\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF");
        $[35] = t;
        $[36] = t21;
    } else {
        t21 = $[36];
    }
    let t22;
    if ($[37] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-6",
            children: t21
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[37] = t21;
        $[38] = t22;
    } else {
        t22 = $[38];
    }
    let t23;
    let t24;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-neutral-600 leading-relaxed mb-6",
            children: 'With the noble vision that "good friends create a good nation," the league has grown tremendously across India and abroad.'
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-700 leading-relaxed italic",
            children: "நல்ல நண்பர்கள் உருவானால் நல்ல நாடு தானாகவே உருவாகும் என்ற உயரிய நோக்கத்தின் அசுரவளர்ச்சியாய் தமிழகத்தின் அனைத்து மாவட்டங்களிலும் விரிந்துள்ளது."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 281,
            columnNumber: 11
        }, this);
        $[39] = t23;
        $[40] = t24;
    } else {
        t23 = $[39];
        t24 = $[40];
    }
    let t25;
    if ($[41] !== t22) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t20,
                t22,
                t23,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 290,
            columnNumber: 11
        }, this);
        $[41] = t22;
        $[42] = t25;
    } else {
        t25 = $[42];
    }
    let t26;
    if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-xl font-bold text-neutral-900 mb-6",
            children: "Presence In"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 298,
            columnNumber: 11
        }, this);
        $[43] = t26;
    } else {
        t26 = $[43];
    }
    let t27;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-gradient-to-br from-amber-50 to-orange-50 rounded-3xl p-8 border border-amber-100",
            children: [
                t26,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-2 gap-4",
                    children: [
                        "Tamil Nadu",
                        "Kerala",
                        "Karnataka",
                        "Goa",
                        "New Delhi",
                        "Assam",
                        "France",
                        "Australia",
                        "UAE"
                    ].map(_IPLProfilePageAnonymous)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 305,
                    columnNumber: 118
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 305,
            columnNumber: 11
        }, this);
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] !== t25) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid md:grid-cols-2 gap-12 items-center",
                        children: [
                            t25,
                            t27
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 312,
                        columnNumber: 122
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 312,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 312,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 312,
            columnNumber: 11
        }, this);
        $[45] = t25;
        $[46] = t28;
    } else {
        t28 = $[46];
    }
    let t29;
    if ($[47] !== t) {
        t29 = t("about.registration_title", "Registration & Recognition");
        $[47] = t;
        $[48] = t29;
    } else {
        t29 = $[48];
    }
    let t30;
    if ($[49] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold mb-4",
            children: t29
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 328,
            columnNumber: 11
        }, this);
        $[49] = t29;
        $[50] = t30;
    } else {
        t30 = $[50];
    }
    let t31;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-400 max-w-xl mx-auto",
            children: "Officially registered and recognized for our humanitarian work."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 336,
            columnNumber: 11
        }, this);
        $[51] = t31;
    } else {
        t31 = $[51];
    }
    let t32;
    if ($[52] !== t30) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t30,
                t31
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 343,
            columnNumber: 11
        }, this);
        $[52] = t30;
        $[53] = t32;
    } else {
        t32 = $[53];
    }
    let t33;
    if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid sm:grid-cols-2 gap-6",
            children: registrations.map(_IPLProfilePageRegistrationsMap)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 351,
            columnNumber: 11
        }, this);
        $[54] = t33;
    } else {
        t33 = $[54];
    }
    let t34;
    if ($[55] !== t32) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-900 text-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: [
                        t32,
                        t33
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 358,
                    columnNumber: 104
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 358,
                columnNumber: 64
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 358,
            columnNumber: 11
        }, this);
        $[55] = t32;
        $[56] = t34;
    } else {
        t34 = $[56];
    }
    let t35;
    if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-white rounded-2xl shadow-sm mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 366,
                columnNumber: 114
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 366,
            columnNumber: 11
        }, this);
        $[57] = t35;
    } else {
        t35 = $[57];
    }
    let t36;
    if ($[58] !== t) {
        t36 = t("profile.humanitarian.title", "\u0BAA\u0BC7\u0BB0\u0BB5\u0BC8\u0BAF\u0BBF\u0BA9\u0BCD \u0B9A\u0BAE\u0BC2\u0B95\u0BA8\u0BB2 \u0B9A\u0BC6\u0BAF\u0BB2\u0BCD\u0BAA\u0BBE\u0B9F\u0BC1\u0B95\u0BB3\u0BCD");
        $[58] = t;
        $[59] = t36;
    } else {
        t36 = $[59];
    }
    let t37;
    if ($[60] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
            children: t36
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 381,
            columnNumber: 11
        }, this);
        $[60] = t36;
        $[61] = t37;
    } else {
        t37 = $[61];
    }
    let t38;
    if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-600 max-w-2xl mx-auto",
            children: "Humanitarian Services that touch lives across communities."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 389,
            columnNumber: 11
        }, this);
        $[62] = t38;
    } else {
        t38 = $[62];
    }
    let t39;
    if ($[63] !== t37) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t35,
                t37,
                t38
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 396,
            columnNumber: 11
        }, this);
        $[63] = t37;
        $[64] = t39;
    } else {
        t39 = $[64];
    }
    let t40;
    if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: "எழுத்தால் இணைந்த இதயங்கள் அன்பு, நட்பு, மனிதநேயச் சிந்தனைகளைக் கடிதங்கள் மூலம் பகிர்ந்து கொண்ட நிலையில் பேரவை சமூக நல அறக்கட்டளையாகப் பதிவு செய்யப்பட்டு மனிதநேய உதவிகள் வழங்கப்படுகிறது."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 404,
            columnNumber: 11
        }, this);
        $[65] = t40;
    } else {
        t40 = $[65];
    }
    let t41;
    if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid sm:grid-cols-2 gap-4 not-prose",
            children: [
                "Eye Examination Camps (31+)",
                "ENT Medical Camps",
                "Cancer Awareness Camps",
                "AIDS Awareness Programs",
                "Education Fee Assistance",
                "Medical Aid Support"
            ].map(_IPLProfilePageAnonymous2)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 411,
            columnNumber: 11
        }, this);
        $[66] = t41;
    } else {
        t41 = $[66];
    }
    let t42;
    if ($[67] === Symbol.for("react.memo_cache_sentinel")) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-3xl p-8 sm:p-12 shadow-lg border border-neutral-100",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "prose prose-lg max-w-none text-neutral-700 leading-relaxed space-y-6",
                children: [
                    t40,
                    t41,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-6 bg-amber-50 rounded-2xl border border-amber-200",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-700 m-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    className: "text-amber-800",
                                    children: "Partnership with Aditya Jyot Eye Hospital:"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                                    lineNumber: 418,
                                    columnNumber: 298
                                }, this),
                                " In collaboration with the world-renowned hospital under the guidance of Padma Shri Dr. S. Natarajan, 31 eye examination camps have been conducted in Mumbai slum areas."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                            lineNumber: 418,
                            columnNumber: 262
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 418,
                        columnNumber: 193
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 418,
                columnNumber: 97
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 418,
            columnNumber: 11
        }, this);
        $[67] = t42;
    } else {
        t42 = $[67];
    }
    let t43;
    if ($[68] !== t39) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-gradient-to-br from-red-50 to-orange-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: [
                        t39,
                        t42
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 425,
                    columnNumber: 121
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 425,
                columnNumber: 81
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 425,
            columnNumber: 11
        }, this);
        $[68] = t39;
        $[69] = t43;
    } else {
        t43 = $[69];
    }
    let t44;
    if ($[70] === Symbol.for("react.memo_cache_sentinel")) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-red-50 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                className: "w-8 h-8 text-red-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 433,
                columnNumber: 105
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 433,
            columnNumber: 11
        }, this);
        $[70] = t44;
    } else {
        t44 = $[70];
    }
    let t45;
    if ($[71] !== t) {
        t45 = t("profile.friendshipMeet.title", "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE \u0BB5\u0BBF\u0BB4\u0BBE\u0B95\u0BCD\u0B95\u0BB3\u0BCD");
        $[71] = t;
        $[72] = t45;
    } else {
        t45 = $[72];
    }
    let t46;
    if ($[73] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
            children: t45
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 448,
            columnNumber: 11
        }, this);
        $[73] = t45;
        $[74] = t46;
    } else {
        t46 = $[74];
    }
    let t47;
    if ($[75] === Symbol.for("react.memo_cache_sentinel")) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-neutral-600 max-w-2xl mx-auto",
            children: "28+ successful Friendship Meets across India since 1995."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 456,
            columnNumber: 11
        }, this);
        $[75] = t47;
    } else {
        t47 = $[75];
    }
    let t48;
    if ($[76] !== t46) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t44,
                t46,
                t47
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 463,
            columnNumber: 11
        }, this);
        $[76] = t46;
        $[77] = t48;
    } else {
        t48 = $[77];
    }
    let t49;
    if ($[78] === Symbol.for("react.memo_cache_sentinel")) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4",
            children: friendshipMeets.map(_IPLProfilePageFriendshipMeetsMap)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 471,
            columnNumber: 11
        }, this);
        $[78] = t49;
    } else {
        t49 = $[78];
    }
    let t50;
    if ($[79] === Symbol.for("react.memo_cache_sentinel")) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-neutral-50 rounded-3xl p-8 sm:p-12 border border-neutral-100",
            children: [
                t49,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 text-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: "/friendship-meet",
                        className: "inline-flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-full font-semibold hover:bg-red-700 transition-colors",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                                lineNumber: 478,
                                columnNumber: 295
                            }, this),
                            "View All Friendship Meets"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 478,
                        columnNumber: 131
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 478,
                    columnNumber: 97
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 478,
            columnNumber: 11
        }, this);
        $[79] = t50;
    } else {
        t50 = $[79];
    }
    let t51;
    if ($[80] !== t48) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto",
                    children: [
                        t48,
                        t50
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 485,
                    columnNumber: 87
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 485,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 485,
            columnNumber: 11
        }, this);
        $[80] = t48;
        $[81] = t51;
    } else {
        t51 = $[81];
    }
    let t52;
    if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
        t52 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-16 h-16 bg-purple-50 rounded-2xl mb-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                className: "w-8 h-8 text-purple-700"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 493,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 493,
            columnNumber: 11
        }, this);
        $[82] = t52;
    } else {
        t52 = $[82];
    }
    let t53;
    if ($[83] !== t) {
        t53 = t("profile.notableGuests.title", "Notable Guests");
        $[83] = t;
        $[84] = t53;
    } else {
        t53 = $[84];
    }
    let t54;
    if ($[85] !== t53) {
        t54 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-12",
            children: [
                t52,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-4",
                    children: t53
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 508,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 508,
            columnNumber: 11
        }, this);
        $[85] = t53;
        $[86] = t54;
    } else {
        t54 = $[86];
    }
    let t55;
    if ($[87] === Symbol.for("react.memo_cache_sentinel")) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-neutral-700 leading-relaxed mb-8",
            children: "சரித்திர சாதனையாக நடைபெற்று வரும் நட்புச்சங்கம விழாக்களில் பல்வேறு துறைச் சான்றோர் பெருமக்கள் சிறப்பு விருந்தினராகப் பங்கேற்றுள்ளனர்."
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 516,
            columnNumber: 11
        }, this);
        $[87] = t55;
    } else {
        t55 = $[87];
    }
    let t56;
    if ($[88] === Symbol.for("react.memo_cache_sentinel")) {
        t56 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-3xl p-8 sm:p-12 shadow-sm border border-neutral-100",
            children: [
                t55,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid sm:grid-cols-2 gap-4",
                    children: [
                        {
                            name: "R. R. Gopal",
                            title: "Nakkheeran - Journalism Pioneer"
                        },
                        {
                            name: "V. G. Santhosham",
                            title: "Chevalier"
                        },
                        {
                            name: "T. M. Soundararajan",
                            title: "Legendary Playback Singer"
                        },
                        {
                            name: "S. V. Sekar",
                            title: "Actor & Comedian"
                        },
                        {
                            name: "A. L. Srinivasan",
                            title: "Radio Drama Legend"
                        },
                        {
                            name: "S. V. Subramanian",
                            title: "Distinguished Guest"
                        }
                    ].map(_IPLProfilePageAnonymous3)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 523,
                    columnNumber: 102
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 523,
            columnNumber: 11
        }, this);
        $[88] = t56;
    } else {
        t56 = $[88];
    }
    let t57;
    if ($[89] !== t54) {
        t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-neutral-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto",
                    children: [
                        t54,
                        t56
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 548,
                    columnNumber: 92
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 548,
                columnNumber: 52
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 548,
            columnNumber: 11
        }, this);
        $[89] = t54;
        $[90] = t57;
    } else {
        t57 = $[90];
    }
    let t58;
    if ($[91] !== t) {
        t58 = t("profile.cta.title", "Join Our Mission");
        $[91] = t;
        $[92] = t58;
    } else {
        t58 = $[92];
    }
    let t59;
    if ($[93] !== t58) {
        t59 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl sm:text-4xl font-bold mb-6",
            children: t58
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 564,
            columnNumber: 11
        }, this);
        $[93] = t58;
        $[94] = t59;
    } else {
        t59 = $[94];
    }
    let t60;
    if ($[95] !== t) {
        t60 = t("profile.cta.desc", "Be part of our journey to spread love, friendship and humanity");
        $[95] = t;
        $[96] = t60;
    } else {
        t60 = $[96];
    }
    let t61;
    if ($[97] !== t60) {
        t61 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xl text-red-100 mb-10 leading-relaxed",
            children: t60
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 580,
            columnNumber: 11
        }, this);
        $[97] = t60;
        $[98] = t61;
    } else {
        t61 = $[98];
    }
    let t62;
    if ($[99] !== t) {
        t62 = t("profile.cta.contact", "Contact Us");
        $[99] = t;
        $[100] = t62;
    } else {
        t62 = $[100];
    }
    let t63;
    if ($[101] !== t62) {
        t63 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/contact",
            className: "px-8 py-4 bg-white text-red-700 rounded-full font-bold shadow-xl hover:bg-amber-50 hover:scale-105 transition-all duration-300",
            children: t62
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 596,
            columnNumber: 11
        }, this);
        $[101] = t62;
        $[102] = t63;
    } else {
        t63 = $[102];
    }
    let t64;
    if ($[103] !== t) {
        t64 = t("profile.cta.services", "Our Services");
        $[103] = t;
        $[104] = t64;
    } else {
        t64 = $[104];
    }
    let t65;
    if ($[105] !== t64) {
        t65 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/humanitarian-services",
            className: "px-8 py-4 bg-transparent text-white border-2 border-white/50 rounded-full font-bold hover:bg-white/10 hover:border-white transition-all duration-300",
            children: t64
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 612,
            columnNumber: 11
        }, this);
        $[105] = t64;
        $[106] = t65;
    } else {
        t65 = $[106];
    }
    let t66;
    if ($[107] !== t63 || $[108] !== t65) {
        t66 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row gap-4 justify-center",
            children: [
                t63,
                t65
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 620,
            columnNumber: 11
        }, this);
        $[107] = t63;
        $[108] = t65;
        $[109] = t66;
    } else {
        t66 = $[109];
    }
    let t67;
    if ($[110] !== t59 || $[111] !== t61 || $[112] !== t66) {
        t67 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-gradient-to-br from-red-700 to-red-800",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-3xl mx-auto text-center text-white",
                    children: [
                        t59,
                        t61,
                        t66
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 629,
                    columnNumber: 120
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 629,
                columnNumber: 80
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 629,
            columnNumber: 11
        }, this);
        $[110] = t59;
        $[111] = t61;
        $[112] = t66;
        $[113] = t67;
    } else {
        t67 = $[113];
    }
    let t68;
    if ($[114] !== t10 || $[115] !== t19 || $[116] !== t28 || $[117] !== t34 || $[118] !== t43 || $[119] !== t51 || $[120] !== t57 || $[121] !== t67) {
        t68 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "min-h-screen bg-neutral-50",
            children: [
                t10,
                t11,
                t19,
                t28,
                t34,
                t43,
                t51,
                t57,
                t67
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 639,
            columnNumber: 11
        }, this);
        $[114] = t10;
        $[115] = t19;
        $[116] = t28;
        $[117] = t34;
        $[118] = t43;
        $[119] = t51;
        $[120] = t57;
        $[121] = t67;
        $[122] = t68;
    } else {
        t68 = $[122];
    }
    return t68;
}
_s(IPLProfilePage, "vu2xTFBfHkv41zWfADiErp1aWcA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = IPLProfilePage;
function _IPLProfilePageAnonymous3(guest, i_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-4 p-4 bg-purple-50 rounded-xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                    className: "w-5 h-5 text-purple-700"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 655,
                    columnNumber: 176
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 655,
                columnNumber: 89
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-bold text-neutral-900",
                        children: guest.name
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 655,
                        columnNumber: 232
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-neutral-500",
                        children: guest.title
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 655,
                        columnNumber: 290
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 655,
                columnNumber: 227
            }, this)
        ]
    }, i_1, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 655,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageFriendshipMeetsMap(meet, index_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-xl p-4 text-center shadow-sm border border-neutral-100 hover:shadow-md hover:-translate-y-1 transition-all duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-2xl font-bold text-red-700 block mb-1",
                children: meet.year
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 658,
                columnNumber: 178
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs text-neutral-500",
                children: meet.location
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 658,
                columnNumber: 257
            }, this)
        ]
    }, index_1, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 658,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageAnonymous2(service, i_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-3 p-4 bg-red-50 rounded-xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                className: "w-5 h-5 text-red-600"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 661,
                columnNumber: 86
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-neutral-700 font-medium",
                children: service
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 661,
                columnNumber: 134
            }, this)
        ]
    }, i_0, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 661,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageRegistrationsMap(item_0, index_0) {
    const Icon = item_0.icon;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center flex-shrink-0",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                        className: "w-6 h-6 text-red-400"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                        lineNumber: 665,
                        columnNumber: 293
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 665,
                    columnNumber: 194
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-bold text-white mb-1",
                            children: item_0.title
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                            lineNumber: 665,
                            columnNumber: 345
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-400 text-sm",
                            children: item_0.detail
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                            lineNumber: 665,
                            columnNumber: 414
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                    lineNumber: 665,
                    columnNumber: 340
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
            lineNumber: 665,
            columnNumber: 154
        }, this)
    }, index_0, false, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 665,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageAnonymous(place, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                className: "w-4 h-4 text-amber-600"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 668,
                columnNumber: 59
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-neutral-700 text-sm font-medium",
                children: place
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 668,
                columnNumber: 104
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 668,
        columnNumber: 10
    }, this);
}
function _IPLProfilePageAchievementsMap(item, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center p-6 bg-neutral-50 rounded-2xl border border-neutral-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-4xl mb-3",
                children: item.icon
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 671,
                columnNumber: 172
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-3xl sm:text-4xl font-bold text-neutral-900 mb-2",
                children: item.count
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 671,
                columnNumber: 220
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm text-neutral-500 font-medium",
                children: item.title
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
                lineNumber: 671,
                columnNumber: 308
            }, this)
        ]
    }, index, true, {
        fileName: "[project]/IPL-Website-test-main/src/app/about/ipl-profile/page.tsx",
        lineNumber: 671,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "IPLProfilePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=IPL-Website-test-main_src_app_about_ipl-profile_page_tsx_5480a31c._.js.map