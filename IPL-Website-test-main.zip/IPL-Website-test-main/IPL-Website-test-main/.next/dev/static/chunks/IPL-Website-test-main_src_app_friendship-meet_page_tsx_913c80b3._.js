(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/37e5c_b1a8bb38._.js",
  "static/chunks/IPL-Website-test-main_src_app_friendship-meet_page_tsx_d37c2d44._.js"
],
    source: "dynamic"
});
