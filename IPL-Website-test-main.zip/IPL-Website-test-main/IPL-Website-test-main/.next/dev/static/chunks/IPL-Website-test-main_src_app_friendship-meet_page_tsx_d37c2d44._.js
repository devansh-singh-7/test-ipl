(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FriendshipMeet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$camera$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Camera$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/camera.js [app-client] (ecmascript) <export default as Camera>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$handshake$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Handshake$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/handshake.js [app-client] (ecmascript) <export default as Handshake>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript) <export default as Globe>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/gift.js [app-client] (ecmascript) <export default as Gift>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/award.js [app-client] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function FriendshipMeet() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(149);
    if ($[0] !== "bcc4ebfcecb61e806d12d6ed25d4c42a90b6a987ee449f31dc2c36a912d91654") {
        for(let $i = 0; $i < 149; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bcc4ebfcecb61e806d12d6ed25d4c42a90b6a987ee449f31dc2c36a912d91654";
    }
    const { t, lang } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [selectedYear, setSelectedYear] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("2024");
    let friendshipMeets;
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[1] !== lang || $[2] !== t) {
        const friendsDayEvents = [
            {
                id: 1,
                year: "2024",
                date: "August 4, 2024",
                title: "International Friendship Day Celebration 2024",
                location: "Multiple Locations across India",
                description: "IPL members celebrated International Friendship Day with various cultural programs, gift exchanges, and community gatherings.",
                image: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&q=80",
                participants: "500+",
                activities: [
                    "Cultural Programs",
                    "Gift Exchange",
                    "Community Gathering",
                    "Friendship Pledge"
                ],
                titleTa: "\u0B9A\u0BB0\u0BCD\u0BB5\u0BA4\u0BC7\u0B9A \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0BBF\u0BA9 \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD 2024",
                locationTa: "\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF\u0BBE \u0BAE\u0BC1\u0BB4\u0BC1\u0BB5\u0BA4\u0BC1\u0BAE\u0BCD \u0BAA\u0BB2 \u0B87\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BB2\u0BCD",
                descriptionTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0BA9\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BAA\u0BB2\u0BCD\u0BB5\u0BC7\u0BB1\u0BC1 \u0B95\u0BB2\u0BBE\u0B9A\u0BCD\u0B9A\u0BBE\u0BB0 \u0BA8\u0BBF\u0B95\u0BB4\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BCD, \u0BAA\u0BB0\u0BBF\u0B9A\u0BC1 \u0BAA\u0BB0\u0BBF\u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B9A\u0BAE\u0BC2\u0B95\u0B95\u0BCD \u0B95\u0BC2\u0B9F\u0BCD\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0B9A\u0BB0\u0BCD\u0BB5\u0BA4\u0BC7\u0B9A \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0BBF\u0BA9\u0BA4\u0BCD\u0BA4\u0BC8\u0B95\u0BCD \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F\u0BBF\u0BA9\u0BB0\u0BCD.",
                activitiesTa: [
                    "\u0B95\u0BB2\u0BBE\u0B9A\u0BCD\u0B9A\u0BBE\u0BB0 \u0BA8\u0BBF\u0B95\u0BB4\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BCD",
                    "\u0BAA\u0BB0\u0BBF\u0B9A\u0BC1 \u0BAA\u0BB0\u0BBF\u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0BAE\u0BCD",
                    "\u0B9A\u0BAE\u0BC2\u0B95\u0B95\u0BCD \u0B95\u0BC2\u0B9F\u0BB2\u0BCD",
                    "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1 \u0B89\u0BB1\u0BC1\u0BA4\u0BBF\u0BAE\u0BCA\u0BB4\u0BBF"
                ]
            },
            {
                id: 2,
                year: "2023",
                date: "August 6, 2023",
                title: "International Friendship Day Celebration 2023",
                location: "New Delhi & Regional Branches",
                description: "A day dedicated to celebrating the bonds of friendship with pen pals from around the world.",
                image: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&q=80",
                participants: "450+",
                activities: [
                    "Letter Writing",
                    "Cultural Exchange",
                    "Friendship Band Distribution",
                    "Group Photos"
                ],
                titleTa: "\u0B9A\u0BB0\u0BCD\u0BB5\u0BA4\u0BC7\u0B9A \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0BBF\u0BA9 \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD 2023",
                locationTa: "\u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF & \u0BAE\u0BA3\u0BCD\u0B9F\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8\u0B95\u0BB3\u0BCD",
                descriptionTa: "\u0B89\u0BB2\u0B95\u0BAE\u0BCD \u0BAE\u0BC1\u0BB4\u0BC1\u0BB5\u0BA4\u0BBF\u0BB2\u0BC1\u0BAE\u0BCD \u0B89\u0BB3\u0BCD\u0BB3 \u0BAA\u0BC7\u0BA9\u0BBE \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BBE\u0BA9 \u0BA8\u0B9F\u0BCD\u0BAA\u0BBF\u0BA9\u0BCD \u0BAA\u0BA8\u0BCD\u0BA4\u0BA4\u0BCD\u0BA4\u0BC8\u0B95\u0BCD \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F \u0B85\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BA3\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B92\u0BB0\u0BC1 \u0BA8\u0BBE\u0BB3\u0BCD.",
                activitiesTa: [
                    "\u0B95\u0B9F\u0BBF\u0BA4\u0BAE\u0BCD \u0B8E\u0BB4\u0BC1\u0BA4\u0BC1\u0BA4\u0BB2\u0BCD",
                    "\u0B95\u0BB2\u0BBE\u0B9A\u0BCD\u0B9A\u0BBE\u0BB0 \u0BAA\u0BB0\u0BBF\u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0BAE\u0BCD",
                    "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1 \u0B95\u0BAF\u0BBF\u0BB1\u0BC1 \u0BB5\u0BB4\u0B99\u0BCD\u0B95\u0BB2\u0BCD",
                    "\u0B95\u0BC1\u0BB4\u0BC1 \u0BAA\u0BC1\u0B95\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BCD"
                ]
            },
            {
                id: 3,
                year: "2022",
                date: "August 7, 2022",
                title: "International Friendship Day Celebration 2022",
                location: "Mumbai & Regional Offices",
                description: "IPL organized special friendship day events to honor the spirit of penpal friendships.",
                image: "https://images.unsplash.com/photo-1522543558187-768b6df7c25c?w=800&q=80",
                participants: "400+",
                activities: [
                    "Friendship Cards",
                    "Cultural Performances",
                    "Unity March",
                    "Social Gathering"
                ],
                titleTa: "\u0B9A\u0BB0\u0BCD\u0BB5\u0BA4\u0BC7\u0B9A \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0BBF\u0BA9 \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD 2022",
                locationTa: "\u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8 & \u0BAE\u0BA3\u0BCD\u0B9F\u0BB2 \u0B85\u0BB2\u0BC1\u0BB5\u0BB2\u0B95\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
                descriptionTa: "\u0BAA\u0BC7\u0BA9\u0BBE\u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD \u0BA8\u0B9F\u0BCD\u0BAA\u0BBF\u0BA9\u0BCD \u0B89\u0BA3\u0BB0\u0BCD\u0BB5\u0BC8 \u0B95\u0BCC\u0BB0\u0BB5\u0BBF\u0B95\u0BCD\u0B95 \u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B9A\u0BBF\u0BB1\u0BAA\u0BCD\u0BAA\u0BC1 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0BBF\u0BA9 \u0BA8\u0BBF\u0B95\u0BB4\u0BCD\u0BB5\u0BC1\u0B95\u0BB3\u0BC8 \u0B8F\u0BB1\u0BCD\u0BAA\u0BBE\u0B9F\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BA4\u0BC1.",
                activitiesTa: [
                    "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1 \u0B85\u0B9F\u0BCD\u0B9F\u0BC8\u0B95\u0BB3\u0BCD",
                    "\u0B95\u0BB2\u0BBE\u0B9A\u0BCD\u0B9A\u0BBE\u0BB0 \u0BA8\u0BBF\u0B95\u0BB4\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BCD",
                    "\u0B92\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BC8\u0BAA\u0BCD \u0BAA\u0BC7\u0BB0\u0BA3\u0BBF",
                    "\u0B9A\u0BAE\u0BC2\u0B95\u0B95\u0BCD \u0B95\u0BC2\u0B9F\u0BB2\u0BCD"
                ]
            }
        ];
        let t9;
        if ($[13] !== t) {
            t9 = t("meet.28.title", "28th Friendship Meet");
            $[13] = t;
            $[14] = t9;
        } else {
            t9 = $[14];
        }
        let t10;
        if ($[15] !== t) {
            t10 = t("meet.28.date", "24 MAY 2025");
            $[15] = t;
            $[16] = t10;
        } else {
            t10 = $[16];
        }
        let t11;
        if ($[17] !== t) {
            t11 = t("meet.28.location", "To be announced");
            $[17] = t;
            $[18] = t11;
        } else {
            t11 = $[18];
        }
        let t12;
        if ($[19] !== t) {
            t12 = t("meet.28.desc", "The 28th Annual Friendship Meet bringing together pen friends from across India and abroad");
            $[19] = t;
            $[20] = t12;
        } else {
            t12 = $[20];
        }
        let t13;
        if ($[21] !== t10 || $[22] !== t11 || $[23] !== t12 || $[24] !== t9) {
            t13 = {
                year: "2024",
                number: "28",
                titleEn: t9,
                date: t10,
                location: t11,
                description: t12,
                status: "upcoming"
            };
            $[21] = t10;
            $[22] = t11;
            $[23] = t12;
            $[24] = t9;
            $[25] = t13;
        } else {
            t13 = $[25];
        }
        let t14;
        if ($[26] !== t) {
            t14 = t("meet.27.title", "27th Friendship Meet");
            $[26] = t;
            $[27] = t14;
        } else {
            t14 = $[27];
        }
        let t15;
        if ($[28] !== t) {
            t15 = t("meet.27.date", "25 MAY 2024");
            $[28] = t;
            $[29] = t15;
        } else {
            t15 = $[29];
        }
        let t16;
        if ($[30] !== t) {
            t16 = t("meet.27.location", "Kuttalam, Tenkasi District");
            $[30] = t;
            $[31] = t16;
        } else {
            t16 = $[31];
        }
        let t17;
        if ($[32] !== t) {
            t17 = t("meet.27.desc", "27th Annual Friendship Meet held at TMNS Hall, Kuttalam");
            $[32] = t;
            $[33] = t17;
        } else {
            t17 = $[33];
        }
        let t18;
        if ($[34] !== t14 || $[35] !== t15 || $[36] !== t16 || $[37] !== t17) {
            t18 = {
                year: "2024",
                number: "27",
                titleEn: t14,
                date: t15,
                location: t16,
                description: t17,
                status: "completed"
            };
            $[34] = t14;
            $[35] = t15;
            $[36] = t16;
            $[37] = t17;
            $[38] = t18;
        } else {
            t18 = $[38];
        }
        let t19;
        if ($[39] !== t) {
            t19 = t("meet.26.title", "26th Friendship Meet");
            $[39] = t;
            $[40] = t19;
        } else {
            t19 = $[40];
        }
        let t20;
        if ($[41] !== t) {
            t20 = t("meet.26.date", "20 MAY 2023");
            $[41] = t;
            $[42] = t20;
        } else {
            t20 = $[42];
        }
        let t21;
        if ($[43] !== t) {
            t21 = t("meet.26.location", "New Delhi");
            $[43] = t;
            $[44] = t21;
        } else {
            t21 = $[44];
        }
        let t22;
        if ($[45] !== t) {
            t22 = t("meet.26.desc", "Shri Vittal Mandir Hall, Ramakrishnapuram, New Delhi");
            $[45] = t;
            $[46] = t22;
        } else {
            t22 = $[46];
        }
        let t23;
        if ($[47] !== t19 || $[48] !== t20 || $[49] !== t21 || $[50] !== t22) {
            t23 = {
                year: "2023",
                number: "26",
                titleEn: t19,
                date: t20,
                location: t21,
                description: t22,
                status: "completed"
            };
            $[47] = t19;
            $[48] = t20;
            $[49] = t21;
            $[50] = t22;
            $[51] = t23;
        } else {
            t23 = $[51];
        }
        let t24;
        if ($[52] !== t13 || $[53] !== t18 || $[54] !== t23) {
            t24 = [
                t13,
                t18,
                t23
            ];
            $[52] = t13;
            $[53] = t18;
            $[54] = t23;
            $[55] = t24;
        } else {
            t24 = $[55];
        }
        friendshipMeets = t24;
        const getLocalized = {
            "FriendshipMeet[getLocalized]": (event)=>{
                if (lang === "ta") {
                    return {
                        title: event.titleTa || event.title,
                        location: event.locationTa || event.location,
                        description: event.descriptionTa || event.description
                    };
                }
                return {
                    title: event.title,
                    location: event.location,
                    description: event.description
                };
            }
        }["FriendshipMeet[getLocalized]"];
        t7 = "min-h-screen bg-neutral-50";
        let t25;
        if ($[56] === Symbol.for("react.memo_cache_sentinel")) {
            t25 = {
                minHeight: "280px"
            };
            $[56] = t25;
        } else {
            t25 = $[56];
        }
        let t26;
        if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
            t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 z-0 pointer-events-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: "/Images/iplbanner.png",
                        alt: "Friendship Meet background",
                        className: "w-[85%] h-full opacity-40 object-contain mx-auto",
                        style: {
                            objectPosition: "center"
                        }
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 267,
                        columnNumber: 71
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: "absolute",
                            inset: 0,
                            backgroundColor: "rgba(0,0,0,0.04)"
                        }
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 269,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 267,
                columnNumber: 13
            }, this);
            $[57] = t26;
        } else {
            t26 = $[57];
        }
        let t27;
        if ($[58] === Symbol.for("react.memo_cache_sentinel")) {
            t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                className: "w-4 h-4 text-red-600"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 280,
                columnNumber: 13
            }, this);
            $[58] = t27;
        } else {
            t27 = $[58];
        }
        let t28;
        if ($[59] !== t) {
            t28 = t("meet.badge", "Annual Celebration");
            $[59] = t;
            $[60] = t28;
        } else {
            t28 = $[60];
        }
        let t29;
        if ($[61] !== t28) {
            t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-white border border-neutral-200 shadow-sm mb-6 sm:mb-8 animate-fade-in",
                children: [
                    t27,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-semibold tracking-wider uppercase text-neutral-600",
                        children: t28
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 295,
                        columnNumber: 181
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 295,
                columnNumber: 13
            }, this);
            $[61] = t28;
            $[62] = t29;
        } else {
            t29 = $[62];
        }
        let t30;
        if ($[63] !== t) {
            t30 = t("meet.title", "Friendship Meet");
            $[63] = t;
            $[64] = t30;
        } else {
            t30 = $[64];
        }
        let t31;
        if ($[65] !== t30) {
            t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-extrabold tracking-tight text-neutral-900 mb-4 sm:mb-6 animate-slide-up",
                children: t30
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 311,
                columnNumber: 13
            }, this);
            $[65] = t30;
            $[66] = t31;
        } else {
            t31 = $[66];
        }
        let t32;
        if ($[67] === Symbol.for("react.memo_cache_sentinel")) {
            t32 = {
                animationDelay: "0.1s"
            };
            $[67] = t32;
        } else {
            t32 = $[67];
        }
        let t33;
        if ($[68] !== t) {
            t33 = t("meet.subtitle_native", "\u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BAE\u0BCD");
            $[68] = t;
            $[69] = t33;
        } else {
            t33 = $[69];
        }
        let t34;
        if ($[70] !== t33) {
            t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-base sm:text-lg md:text-xl text-neutral-600 font-medium mb-3 sm:mb-4 animate-slide-up",
                style: t32,
                children: t33
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 336,
                columnNumber: 13
            }, this);
            $[70] = t33;
            $[71] = t34;
        } else {
            t34 = $[71];
        }
        let t35;
        if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
            t35 = {
                animationDelay: "0.15s"
            };
            $[72] = t35;
        } else {
            t35 = $[72];
        }
        let t36;
        if ($[73] !== t) {
            t36 = t("meet.subtitle", "Where letters transform into lasting bonds and pen friends become family");
            $[73] = t;
            $[74] = t36;
        } else {
            t36 = $[74];
        }
        let t37;
        if ($[75] !== t36) {
            t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm sm:text-base md:text-lg lg:text-xl text-neutral-600 leading-relaxed max-w-2xl mx-auto animate-slide-up px-2",
                style: t35,
                children: t36
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 361,
                columnNumber: 13
            }, this);
            $[75] = t36;
            $[76] = t37;
        } else {
            t37 = $[76];
        }
        if ($[77] !== t29 || $[78] !== t31 || $[79] !== t34 || $[80] !== t37) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative bg-transparent pt-8 sm:pt-12 md:pt-16 lg:pt-20 pb-6 sm:pb-8 overflow-hidden",
                style: t25,
                children: [
                    t26,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10 container-custom mx-auto text-center px-4",
                        children: [
                            t29,
                            t31,
                            t34,
                            t37
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 368,
                        columnNumber: 135
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 368,
                columnNumber: 12
            }, this);
            $[77] = t29;
            $[78] = t31;
            $[79] = t34;
            $[80] = t37;
            $[81] = t8;
        } else {
            t8 = $[81];
        }
        t2 = "container-custom mx-auto px-4 mb-16 sm:mb-24";
        if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center mb-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-red-50 border border-red-100 mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                                className: "w-4 h-4 text-red-700"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 379,
                                columnNumber: 173
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs font-semibold tracking-wider uppercase text-red-800",
                                children: "International Friendship Day"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 379,
                                columnNumber: 215
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 379,
                        columnNumber: 47
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 mb-4",
                        children: "Friends Day Celebrations"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 379,
                        columnNumber: 334
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-lg text-neutral-600 max-w-3xl mx-auto",
                        children: "Celebrating the spirit of friendship every first Sunday of August. International Friendship Day is celebrated annually, bringing together pen friends from across the globe to honor the beautiful bonds of friendship."
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 379,
                        columnNumber: 444
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 379,
                columnNumber: 12
            }, this);
            $[82] = t3;
        } else {
            t3 = $[82];
        }
        let t38;
        if ($[83] === Symbol.for("react.memo_cache_sentinel")) {
            t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-xl sm:text-2xl font-bold text-neutral-900 mb-6",
                children: "About International Friendship Day"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 386,
                columnNumber: 13
            }, this);
            $[83] = t38;
        } else {
            t38 = $[83];
        }
        if ($[84] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-4xl mx-auto bg-white rounded-2xl sm:rounded-3xl p-6 sm:p-10 md:p-12 shadow-lg border border-neutral-100 mb-12",
                children: [
                    t38,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "prose prose-lg max-w-none text-neutral-600 space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "International Friendship Day is celebrated on the first Sunday of August every year. Indian Penpals' League has been celebrating this special day since its inception, bringing together pen friends from across the globe to honor the beautiful bonds of friendship."
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 392,
                                columnNumber: 220
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "On this day, IPL members participate in various activities including cultural programs, gift exchanges, friendship band distribution, and community gatherings. It's a day to strengthen existing friendships and create new ones."
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 392,
                                columnNumber: 489
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "The celebration embodies IPL's core values of Love, Friendship, and Humanity, bringing people together regardless of geographical boundaries, cultures, or backgrounds."
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 392,
                                columnNumber: 722
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 392,
                        columnNumber: 150
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 392,
                columnNumber: 12
            }, this);
            $[84] = t4;
        } else {
            t4 = $[84];
        }
        let t39;
        if ($[85] === Symbol.for("react.memo_cache_sentinel")) {
            t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl p-6 border border-neutral-100 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-14 h-14 rounded-xl bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                            className: "w-7 h-7 text-white"
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                            lineNumber: 399,
                            columnNumber: 274
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 399,
                        columnNumber: 156
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-neutral-900 mb-2",
                        children: "Celebrate Friendship"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 399,
                        columnNumber: 320
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-neutral-600",
                        children: "Honor the beautiful bonds formed through pen pal connections"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 399,
                        columnNumber: 401
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 399,
                columnNumber: 13
            }, this);
            $[85] = t39;
        } else {
            t39 = $[85];
        }
        let t40;
        if ($[86] === Symbol.for("react.memo_cache_sentinel")) {
            t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl p-6 border border-neutral-100 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-14 h-14 rounded-xl bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__["Gift"], {
                            className: "w-7 h-7 text-white"
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                            lineNumber: 406,
                            columnNumber: 280
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 406,
                        columnNumber: 156
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-neutral-900 mb-2",
                        children: "Exchange Gifts"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 406,
                        columnNumber: 325
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-neutral-600",
                        children: "Share tokens of appreciation and friendship bands"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 406,
                        columnNumber: 400
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 406,
                columnNumber: 13
            }, this);
            $[86] = t40;
        } else {
            t40 = $[86];
        }
        let t41;
        if ($[87] === Symbol.for("react.memo_cache_sentinel")) {
            t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl p-6 border border-neutral-100 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__["Globe"], {
                            className: "w-7 h-7 text-white"
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                            lineNumber: 413,
                            columnNumber: 276
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 413,
                        columnNumber: 156
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-neutral-900 mb-2",
                        children: "Global Unity"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 413,
                        columnNumber: 322
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-neutral-600",
                        children: "Connect with friends across borders and cultures"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 413,
                        columnNumber: 395
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 413,
                columnNumber: 13
            }, this);
            $[87] = t41;
        } else {
            t41 = $[87];
        }
        if ($[88] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16",
                children: [
                    t39,
                    t40,
                    t41,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-2xl p-6 border border-neutral-100 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-14 h-14 rounded-xl bg-gradient-to-br from-green-600 to-green-700 flex items-center justify-center mb-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$camera$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Camera$3e$__["Camera"], {
                                    className: "w-7 h-7 text-white"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 419,
                                    columnNumber: 356
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 419,
                                columnNumber: 234
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-bold text-neutral-900 mb-2",
                                children: "Create Memories"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 419,
                                columnNumber: 403
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-neutral-600",
                                children: "Capture beautiful moments with your pen pals"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 419,
                                columnNumber: 479
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 419,
                        columnNumber: 91
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 419,
                columnNumber: 12
            }, this);
            $[88] = t5;
        } else {
            t5 = $[88];
        }
        if ($[89] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center mb-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-white border border-neutral-200 shadow-sm mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                                className: "w-4 h-4 text-red-600"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 425,
                                columnNumber: 186
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs font-semibold tracking-wider uppercase text-neutral-600",
                                children: "Past Celebrations"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                lineNumber: 425,
                                columnNumber: 228
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 425,
                        columnNumber: 47
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl sm:text-2xl lg:text-3xl font-bold text-neutral-900 mb-4",
                        children: "Friends Day Events"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 425,
                        columnNumber: 340
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 425,
                columnNumber: 12
            }, this);
            $[89] = t6;
        } else {
            t6 = $[89];
        }
        t0 = "grid md:grid-cols-2 lg:grid-cols-3 gap-6";
        t1 = friendsDayEvents.map({
            "FriendshipMeet[friendsDayEvents.map()]": (event_0)=>{
                const localized = getLocalized(event_0);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-neutral-100 hover:-translate-y-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative h-48 overflow-hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: event_0.image,
                                    alt: localized.title,
                                    fill: true,
                                    className: "object-cover transition-transform duration-500 group-hover:scale-110",
                                    sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 241
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 450
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute bottom-4 left-4 right-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "inline-block px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full mb-2",
                                        children: event_0.year
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                        lineNumber: 434,
                                        columnNumber: 582
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 532
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                            lineNumber: 434,
                            columnNumber: 194
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                    className: "text-lg font-bold text-neutral-900 mb-2 group-hover:text-red-700 transition-colors",
                                    children: localized.title
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 735
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 text-sm text-neutral-600 mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                            className: "w-4 h-4"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 434,
                                            columnNumber: 927
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: event_0.date
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 434,
                                            columnNumber: 959
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 856
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 text-sm text-neutral-600 mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                            className: "w-4 h-4"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 434,
                                            columnNumber: 1063
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: localized.location
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 434,
                                            columnNumber: 1093
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 992
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-neutral-600 mb-4",
                                    children: localized.description
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 1132
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 mb-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                            className: "w-4 h-4 text-red-600"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 434,
                                            columnNumber: 1250
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-sm font-semibold text-neutral-900",
                                            children: [
                                                event_0.participants,
                                                " Participants"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 434,
                                            columnNumber: 1292
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 1204
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap gap-2",
                                    children: event_0.activities.map(_FriendshipMeetFriendsDayEventsMapEvent_0ActivitiesMap)
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 1397
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                            lineNumber: 434,
                            columnNumber: 714
                        }, this)
                    ]
                }, event_0.id, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                    lineNumber: 434,
                    columnNumber: 16
                }, this);
            }
        }["FriendshipMeet[friendsDayEvents.map()]"]);
        $[1] = lang;
        $[2] = t;
        $[3] = friendshipMeets;
        $[4] = t0;
        $[5] = t1;
        $[6] = t2;
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
    } else {
        friendshipMeets = $[3];
        t0 = $[4];
        t1 = $[5];
        t2 = $[6];
        t3 = $[7];
        t4 = $[8];
        t5 = $[9];
        t6 = $[10];
        t7 = $[11];
        t8 = $[12];
    }
    let t9;
    if ($[90] !== t0 || $[91] !== t1) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t0,
            children: t1
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 463,
            columnNumber: 10
        }, this);
        $[90] = t0;
        $[91] = t1;
        $[92] = t9;
    } else {
        t9 = $[92];
    }
    let t10;
    if ($[93] !== t2 || $[94] !== t3 || $[95] !== t4 || $[96] !== t5 || $[97] !== t6 || $[98] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t2,
            children: [
                t3,
                t4,
                t5,
                t6,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 472,
            columnNumber: 11
        }, this);
        $[93] = t2;
        $[94] = t3;
        $[95] = t4;
        $[96] = t5;
        $[97] = t6;
        $[98] = t9;
        $[99] = t10;
    } else {
        t10 = $[99];
    }
    let t11;
    if ($[100] !== t) {
        t11 = t("meet.past_title", "Annual Friendship Meets");
        $[100] = t;
        $[101] = t11;
    } else {
        t11 = $[101];
    }
    let t12;
    if ($[102] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl md:text-4xl font-bold text-neutral-900 mb-4",
            children: t11
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 493,
            columnNumber: 11
        }, this);
        $[102] = t11;
        $[103] = t12;
    } else {
        t12 = $[103];
    }
    let t13;
    if ($[104] !== t) {
        t13 = t("meet.past_sub", "Explore our journey through the years");
        $[104] = t;
        $[105] = t13;
    } else {
        t13 = $[105];
    }
    let t14;
    if ($[106] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-neutral-600",
            children: t13
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 509,
            columnNumber: 11
        }, this);
        $[106] = t13;
        $[107] = t14;
    } else {
        t14 = $[107];
    }
    let t15;
    if ($[108] !== t12 || $[109] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mb-14",
            children: [
                t12,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 517,
            columnNumber: 11
        }, this);
        $[108] = t12;
        $[109] = t14;
        $[110] = t15;
    } else {
        t15 = $[110];
    }
    let t16;
    if ($[111] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = [
            "2024",
            "2023",
            "2022"
        ];
        $[111] = t16;
    } else {
        t16 = $[111];
    }
    let t17;
    if ($[112] !== selectedYear) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-center mb-12",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "inline-flex bg-white rounded-full border border-neutral-200 p-2 gap-2 shadow-sm",
                children: t16.map({
                    "FriendshipMeet[(anonymous)()]": (year)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: {
                                "FriendshipMeet[(anonymous)() > <button>.onClick]": ()=>setSelectedYear(year)
                            }["FriendshipMeet[(anonymous)() > <button>.onClick]"],
                            className: `px-8 py-2.5 rounded-full text-sm font-semibold transition ${selectedYear === year ? "bg-red-700 text-white shadow-sm" : "text-neutral-600 hover:bg-neutral-100"}`,
                            children: year
                        }, year, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                            lineNumber: 534,
                            columnNumber: 52
                        }, this)
                }["FriendshipMeet[(anonymous)()]"])
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 533,
                columnNumber: 54
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 533,
            columnNumber: 11
        }, this);
        $[112] = selectedYear;
        $[113] = t17;
    } else {
        t17 = $[113];
    }
    let t18;
    if ($[114] !== friendshipMeets || $[115] !== selectedYear) {
        t18 = friendshipMeets.filter({
            "FriendshipMeet[friendshipMeets.filter()]": (m)=>m.year === selectedYear
        }["FriendshipMeet[friendshipMeets.filter()]"]);
        $[114] = friendshipMeets;
        $[115] = selectedYear;
        $[116] = t18;
    } else {
        t18 = $[116];
    }
    let t19;
    if ($[117] !== t || $[118] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-4xl mx-auto space-y-6",
            children: t18.map({
                "FriendshipMeet[(anonymous)()]": (meet, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "group bg-white rounded-2xl overflow-hidden shadow-sm border border-neutral-200 hover:border-red-200 hover:shadow-xl transition-all duration-300",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col md:flex-row",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "md:w-48 bg-linear-to-br from-red-600 to-red-700 p-8 flex flex-col items-center justify-center text-white",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-6xl font-extrabold mb-2 tracking-tight",
                                            children: meet.number
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 557,
                                            columnNumber: 401
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-xs font-semibold uppercase tracking-wider opacity-90",
                                            children: t("meet.badge_small", "Annual Meet")
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 557,
                                            columnNumber: 481
                                        }, this),
                                        meet.status === "upcoming" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-4 px-3 py-1 bg-white/20 rounded-full text-[10px] font-bold tracking-wider",
                                            children: t("meet.upcoming", "UPCOMING")
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 557,
                                            columnNumber: 631
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 557,
                                    columnNumber: 279
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 p-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-2xl font-bold text-neutral-900 mb-5 group-hover:text-red-700 transition-colors",
                                            children: meet.titleEn
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 557,
                                            columnNumber: 798
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-wrap gap-6 mb-5 text-sm text-neutral-600",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                            className: "w-5 h-5 text-red-700"
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                                            lineNumber: 557,
                                                            columnNumber: 1026
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "font-semibold",
                                                            children: meet.date
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                                            lineNumber: 557,
                                                            columnNumber: 1071
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                                    lineNumber: 557,
                                                    columnNumber: 985
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                            className: "w-5 h-5 text-red-700"
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                                            lineNumber: 557,
                                                            columnNumber: 1168
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: meet.location
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                                            lineNumber: 557,
                                                            columnNumber: 1211
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                                    lineNumber: 557,
                                                    columnNumber: 1127
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 557,
                                            columnNumber: 917
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-neutral-600 leading-relaxed mb-6",
                                            children: meet.description
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 557,
                                            columnNumber: 1251
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "inline-flex items-center gap-2 text-red-700 font-semibold text-sm hover:gap-3 transition-all",
                                            children: [
                                                t("meet.view_details", "View Details"),
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                    className: "w-5 h-5"
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                                    lineNumber: 557,
                                                    columnNumber: 1480
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                            lineNumber: 557,
                                            columnNumber: 1326
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                                    lineNumber: 557,
                                    columnNumber: 770
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                            lineNumber: 557,
                            columnNumber: 236
                        }, this)
                    }, index, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                        lineNumber: 557,
                        columnNumber: 59
                    }, this)
            }["FriendshipMeet[(anonymous)()]"])
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 556,
            columnNumber: 11
        }, this);
        $[117] = t;
        $[118] = t18;
        $[119] = t19;
    } else {
        t19 = $[119];
    }
    let t20;
    if ($[120] !== t15 || $[121] !== t17 || $[122] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-white py-20 border-t border-neutral-100",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container-custom mx-auto",
                children: [
                    t15,
                    t17,
                    t19
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 567,
                columnNumber: 75
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 567,
            columnNumber: 11
        }, this);
        $[120] = t15;
        $[121] = t17;
        $[122] = t19;
        $[123] = t20;
    } else {
        t20 = $[123];
    }
    let t21;
    if ($[124] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 opacity-10",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute -top-32 right-0 w-96 h-96 bg-white/10 rounded-full"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                    lineNumber: 577,
                    columnNumber: 56
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute bottom-0 -left-32 w-72 h-72 bg-white/10 rounded-full"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                    lineNumber: 577,
                    columnNumber: 135
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 577,
            columnNumber: 11
        }, this);
        $[124] = t21;
    } else {
        t21 = $[124];
    }
    let t22;
    if ($[125] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex items-center justify-center w-20 h-20 bg-white/10 backdrop-blur-xl rounded-full mb-8 border border-white/20",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$handshake$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Handshake$3e$__["Handshake"], {
                className: "w-10 h-10"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                lineNumber: 584,
                columnNumber: 148
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 584,
            columnNumber: 11
        }, this);
        $[125] = t22;
    } else {
        t22 = $[125];
    }
    let t23;
    if ($[126] !== t) {
        t23 = t("meet.cta_title", "Join Our Next Friendship Meet");
        $[126] = t;
        $[127] = t23;
    } else {
        t23 = $[127];
    }
    let t24;
    if ($[128] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl md:text-5xl font-bold tracking-tight mb-6",
            children: t23
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 599,
            columnNumber: 11
        }, this);
        $[128] = t23;
        $[129] = t24;
    } else {
        t24 = $[129];
    }
    let t25;
    if ($[130] !== t) {
        t25 = t("meet.cta_desc", "Experience the joy of meeting friends who share your passion for friendship and humanity.");
        $[130] = t;
        $[131] = t25;
    } else {
        t25 = $[131];
    }
    let t26;
    if ($[132] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg md:text-xl text-white/90 max-w-2xl mx-auto leading-relaxed mb-10",
            children: t25
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 615,
            columnNumber: 11
        }, this);
        $[132] = t25;
        $[133] = t26;
    } else {
        t26 = $[133];
    }
    let t27;
    if ($[134] !== t) {
        t27 = t("meet.cta_button", "Contact Us for Details");
        $[134] = t;
        $[135] = t27;
    } else {
        t27 = $[135];
    }
    let t28;
    if ($[136] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
            className: "w-5 h-5"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 631,
            columnNumber: 11
        }, this);
        $[136] = t28;
    } else {
        t28 = $[136];
    }
    let t29;
    if ($[137] !== t27) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "/contact",
            className: "inline-flex items-center gap-2 px-8 py-4 bg-white text-red-700 rounded-full font-bold text-lg shadow-md hover:shadow-xl hover:-translate-y-1 transition-all",
            children: [
                t27,
                " ",
                t28
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 638,
            columnNumber: 11
        }, this);
        $[137] = t27;
        $[138] = t29;
    } else {
        t29 = $[138];
    }
    let t30;
    if ($[139] !== t24 || $[140] !== t26 || $[141] !== t29) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative bg-linear-to-br from-red-700 via-red-700 to-red-800 text-white py-24 overflow-hidden",
            children: [
                t21,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container-custom mx-auto text-center relative z-10",
                    children: [
                        t22,
                        t24,
                        t26,
                        t29
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
                    lineNumber: 646,
                    columnNumber: 131
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 646,
            columnNumber: 11
        }, this);
        $[139] = t24;
        $[140] = t26;
        $[141] = t29;
        $[142] = t30;
    } else {
        t30 = $[142];
    }
    let t31;
    if ($[143] !== t10 || $[144] !== t20 || $[145] !== t30 || $[146] !== t7 || $[147] !== t8) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t7,
            children: [
                t8,
                t10,
                t20,
                t30
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
            lineNumber: 656,
            columnNumber: 11
        }, this);
        $[143] = t10;
        $[144] = t20;
        $[145] = t30;
        $[146] = t7;
        $[147] = t8;
        $[148] = t31;
    } else {
        t31 = $[148];
    }
    return t31;
}
_s(FriendshipMeet, "YllkjTjXG5LYb141FpkQDHRb1YE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = FriendshipMeet;
function _FriendshipMeetFriendsDayEventsMapEvent_0ActivitiesMap(activity, idx) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "px-2 py-1 bg-red-50 text-red-700 text-xs rounded-full",
        children: activity
    }, idx, false, {
        fileName: "[project]/IPL-Website-test-main/src/app/friendship-meet/page.tsx",
        lineNumber: 669,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "FriendshipMeet");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=IPL-Website-test-main_src_app_friendship-meet_page_tsx_d37c2d44._.js.map