(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/IPL-Website-test-main_src_ba65a6de._.js",
  "static/chunks/37e5c_0863100e._.js",
  "static/chunks/IPL-Website-test-main_src_app_globals_a17289c6.css"
],
    source: "dynamic"
});
