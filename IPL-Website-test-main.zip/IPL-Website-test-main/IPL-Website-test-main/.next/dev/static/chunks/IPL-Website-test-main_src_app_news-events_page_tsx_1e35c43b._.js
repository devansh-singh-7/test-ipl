(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/app/news-events/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NewsEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/trending-up.js [app-client] (ecmascript) <export default as TrendingUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$components$2f$ui$2f$GlobalSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/components/ui/GlobalSearch.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function NewsEventsContent() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(130);
    if ($[0] !== "7b173bbdc1b66d2c500ff379a167e8bf1548fa63dda60f953d8a36e5bc3318e6") {
        for(let $i = 0; $i < 130; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7b173bbdc1b66d2c500ff379a167e8bf1548fa63dda60f953d8a36e5bc3318e6";
    }
    const { t, lang } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [viewMode, setViewMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("grid");
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    let t0;
    if ($[1] !== searchParams) {
        t0 = (searchParams.get("q") || "").trim();
        $[1] = searchParams;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const initialQuery = t0;
    const [query] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialQuery);
    const [selectedItem, setSelectedItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [
            {
                id: 136,
                date: "22 DEC",
                year: "2024",
                titleEn: "Chennai Regional Branch Friends Meeting",
                locationEn: "Moovarasampettai, Chennai",
                descriptionEn: "Chennai Regional Branch Friends Meeting",
                titleTa: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8 \u0BAE\u0BA3\u0BCD\u0B9F\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1",
                locationTa: "\u0BAE\u0BC2\u0BB5\u0BB0\u0B9A\u0BAE\u0BCD\u0BAA\u0BC7\u0B9F\u0BCD\u0B9F\u0BC8, \u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8",
                descriptionTa: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8 \u0BAE\u0BA3\u0BCD\u0B9F\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"
            },
            {
                id: 135,
                date: "25 MAY",
                year: "2024",
                titleEn: "27th Friendship Meet",
                locationEn: "Kuttalam",
                descriptionEn: "27th Friendship Meet at TMNS Hall, Kuttalam, Tenkasi District",
                titleTa: "27\u0BB5\u0BA4\u0BC1 \u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BAE\u0BCD",
                locationTa: "\u0B95\u0BC1\u0B9F\u0BCD\u0B9F\u0BBE\u0BB2\u0BAE\u0BCD",
                descriptionTa: "\u0BA4\u0BC6\u0BA9\u0BCD\u0B95\u0BBE\u0B9A\u0BBF \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD \u0B95\u0BC1\u0B9F\u0BCD\u0B9F\u0BBE\u0BB2\u0BAE\u0BCD TMNS \u0BAE\u0BA3\u0BCD\u0B9F\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD 27\u0BB5\u0BA4\u0BC1 \u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BAE\u0BCD"
            },
            {
                id: 134,
                date: "03 MAR",
                year: "2024",
                titleEn: "IPL Chess Academy Festival",
                locationEn: "Pavoorchathiram",
                descriptionEn: "IPL Chess Academy - Chess Festival, Pavoorchathiram",
                titleTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B9A\u0BC6\u0BB8\u0BCD \u0B85\u0B95\u0BBE\u0B9F\u0BAE\u0BBF \u0BB5\u0BBF\u0BB4\u0BBE",
                locationTa: "\u0BAA\u0BBE\u0BB5\u0BC2\u0BB0\u0BCD\u0B9A\u0BA4\u0BCD\u0BA4\u0BBF\u0BB0\u0BAE\u0BCD",
                descriptionTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B9A\u0BC6\u0BB8\u0BCD \u0B85\u0B95\u0BBE\u0B9F\u0BAE\u0BBF - \u0B9A\u0BC6\u0BB8\u0BCD \u0BB5\u0BBF\u0BB4\u0BBE, \u0BAA\u0BBE\u0BB5\u0BC2\u0BB0\u0BCD\u0B9A\u0BA4\u0BCD\u0BA4\u0BBF\u0BB0\u0BAE\u0BCD"
            },
            {
                id: 133,
                date: "24 FEB",
                year: "2024",
                titleEn: "Kanyakumari District Branch Friends Meeting",
                locationEn: "Kanyakumari",
                descriptionEn: "Kanyakumari District Branch Friends Meeting at Devadas Sweet Home Hall",
                titleTa: "\u0B95\u0BA9\u0BCD\u0BA9\u0BBF\u0BAF\u0BBE\u0B95\u0BC1\u0BAE\u0BB0\u0BBF \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1",
                locationTa: "\u0B95\u0BA9\u0BCD\u0BA9\u0BBF\u0BAF\u0BBE\u0B95\u0BC1\u0BAE\u0BB0\u0BBF",
                descriptionTa: "\u0BA4\u0BC7\u0BB5\u0BA4\u0BBE\u0BB8\u0BCD \u0BB8\u0BCD\u0BB5\u0BC0\u0B9F\u0BCD \u0BB9\u0BCB\u0BAE\u0BCD \u0BAE\u0BA3\u0BCD\u0B9F\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B95\u0BA9\u0BCD\u0BA9\u0BBF\u0BAF\u0BBE\u0B95\u0BC1\u0BAE\u0BB0\u0BBF \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"
            },
            {
                id: 132,
                date: "11 FEB",
                year: "2024",
                titleEn: "27th Friendship Meet - President's Announcement",
                locationEn: "India",
                descriptionEn: "Indian Penpals' League, Mumbai",
                titleTa: "27\u0BB5\u0BA4\u0BC1 \u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BAE\u0BCD - \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BCD \u0B85\u0BB1\u0BBF\u0BB5\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1",
                locationTa: "\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF\u0BBE",
                descriptionTa: "\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF\u0BAA\u0BCD \u0BAA\u0BC7\u0BA9\u0BBE\u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD \u0BAA\u0BC7\u0BB0\u0BB5\u0BC8, \u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8"
            },
            {
                id: 131,
                date: "20 JAN",
                year: "2024",
                titleEn: "Krishnagiri Regional Branch Friends Meeting",
                locationEn: "Hosur",
                descriptionEn: "St. John Bosco Girls Higher Secondary School - Hosur",
                titleTa: "\u0B95\u0BBF\u0BB0\u0BC1\u0BB7\u0BCD\u0BA3\u0B95\u0BBF\u0BB0\u0BBF \u0BAE\u0BA3\u0BCD\u0B9F\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1",
                locationTa: "\u0B93\u0B9A\u0BC2\u0BB0\u0BCD",
                descriptionTa: "\u0B9A\u0BC6\u0BAF\u0BBF\u0BA9\u0BCD\u0B9F\u0BCD \u0B9C\u0BBE\u0BA9\u0BCD \u0BAA\u0BCB\u0BB8\u0BCD\u0B95\u0BCB \u0BAE\u0B95\u0BB3\u0BBF\u0BB0\u0BCD \u0BAE\u0BC7\u0BB2\u0BCD\u0BA8\u0BBF\u0BB2\u0BC8\u0BAA\u0BCD \u0BAA\u0BB3\u0BCD\u0BB3\u0BBF - \u0B93\u0B9A\u0BC2\u0BB0\u0BCD"
            },
            {
                id: 130,
                date: "12 JAN",
                year: "2024",
                titleEn: "Tamil Nadu Government NRI Tamil Day Celebration",
                locationEn: "Tamil Nadu",
                descriptionEn: "Tamil Nadu Government NRI Tamil Day - Award to IPL President",
                titleTa: "\u0BA4\u0BAE\u0BBF\u0BB4\u0B95 \u0B85\u0BB0\u0B9A\u0BC1 \u0B85\u0BAF\u0BB2\u0B95\u0BA4\u0BCD \u0BA4\u0BAE\u0BBF\u0BB4\u0BB0\u0BCD \u0BA4\u0BBF\u0BA9\u0BAE\u0BCD \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBE\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD",
                locationTa: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD\u0BA8\u0BBE\u0B9F\u0BC1",
                descriptionTa: "\u0BA4\u0BAE\u0BBF\u0BB4\u0B95 \u0B85\u0BB0\u0B9A\u0BC1 \u0B85\u0BAF\u0BB2\u0B95\u0BA4\u0BCD \u0BA4\u0BAE\u0BBF\u0BB4\u0BB0\u0BCD \u0BA4\u0BBF\u0BA9\u0BAE\u0BCD - \u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA4\u0BC1"
            },
            {
                id: 129,
                date: "30 DEC",
                year: "2023",
                titleEn: "IPL Chess Tournament",
                locationEn: "Mumbai",
                descriptionEn: "Chess tournament organized by IPL Chess Academy with Mumbai District Chess Association",
                titleTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B9A\u0BC6\u0BB8\u0BCD \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF",
                locationTa: "\u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8",
                descriptionTa: "\u0BAE\u0BC1\u0BAE\u0BCD\u0BAA\u0BC8 \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F \u0B9A\u0BC6\u0BB8\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC1\u0B9F\u0BA9\u0BCD \u0B87\u0BA3\u0BC8\u0BA8\u0BCD\u0BA4\u0BC1 \u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B9A\u0BC6\u0BB8\u0BCD \u0B85\u0B95\u0BBE\u0B9F\u0BAE\u0BBF \u0BA8\u0B9F\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF \u0B9A\u0BC6\u0BB8\u0BCD \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF"
            },
            {
                id: 128,
                date: "17 DEC",
                year: "2023",
                titleEn: "Cash Prize for Tamil Nadu Kho-Kho Players",
                locationEn: "Tamil Nadu",
                descriptionEn: "National Kho-Kho Championship - Cash prizes for Tamil Nadu women players",
                titleTa: "\u0BA4\u0BAE\u0BBF\u0BB4\u0B95 \u0B95\u0BCB-\u0B95\u0BCB \u0BB5\u0BC0\u0BB0\u0BB0\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BB0\u0BCA\u0B95\u0BCD\u0B95\u0BAA\u0BCD \u0BAA\u0BB0\u0BBF\u0B9A\u0BC1",
                locationTa: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD\u0BA8\u0BBE\u0B9F\u0BC1",
                descriptionTa: "\u0BA4\u0BC7\u0B9A\u0BBF\u0BAF \u0B95\u0BCB-\u0B95\u0BCB \u0B9A\u0BBE\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA9\u0BCD\u0BB7\u0BBF\u0BAA\u0BCD - \u0BA4\u0BAE\u0BBF\u0BB4\u0B95 \u0BAE\u0B95\u0BB3\u0BBF\u0BB0\u0BCD \u0B85\u0BA3\u0BBF \u0BB5\u0BC0\u0BB0\u0BB0\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BB0\u0BCA\u0B95\u0BCD\u0B95\u0BAA\u0BCD \u0BAA\u0BB0\u0BBF\u0B9A\u0BC1\u0B95\u0BB3\u0BCD"
            },
            {
                id: 125,
                date: "19 DEC",
                year: "2023",
                titleEn: "Thiruvalluvar Statue Inauguration",
                locationEn: "Paris, France",
                descriptionEn: "Thiruvalluvar Statue Inauguration - Cergy, Paris, France",
                titleTa: "\u0BA4\u0BBF\u0BB0\u0BC1\u0BB5\u0BB3\u0BCD\u0BB3\u0BC1\u0BB5\u0BB0\u0BCD \u0B9A\u0BBF\u0BB2\u0BC8 \u0BA4\u0BBF\u0BB1\u0BAA\u0BCD\u0BAA\u0BC1 \u0BB5\u0BBF\u0BB4\u0BBE",
                locationTa: "\u0BAA\u0BBE\u0BB0\u0BBF\u0BB8\u0BCD, \u0BAA\u0BBF\u0BB0\u0BBE\u0BA9\u0BCD\u0BB8\u0BCD",
                descriptionTa: "\u0BA4\u0BBF\u0BB0\u0BC1\u0BB5\u0BB3\u0BCD\u0BB3\u0BC1\u0BB5\u0BB0\u0BCD \u0B9A\u0BBF\u0BB2\u0BC8 \u0BA4\u0BBF\u0BB1\u0BAA\u0BCD\u0BAA\u0BC1 \u0BB5\u0BBF\u0BB4\u0BBE - \u0B9A\u0BC6\u0BB0\u0BCD\u0B9C\u0BBF, \u0BAA\u0BBE\u0BB0\u0BBF\u0BB8\u0BCD, \u0BAA\u0BBF\u0BB0\u0BBE\u0BA9\u0BCD\u0BB8\u0BCD"
            },
            {
                id: 127,
                date: "16 JUL",
                year: "2023",
                titleEn: "Chennai District Branch Friends Discussion",
                locationEn: "Chennai",
                descriptionEn: "Distribution of school uniforms and educational materials by Chennai District Branch",
                titleTa: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8 \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BB2\u0BA8\u0BCD\u0BA4\u0BC1\u0BB0\u0BC8\u0BAF\u0BBE\u0B9F\u0BB2\u0BCD",
                locationTa: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8",
                descriptionTa: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8 \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F \u0B95\u0BBF\u0BB3\u0BC8 \u0B9A\u0BBE\u0BB0\u0BCD\u0BAA\u0BBF\u0BB2\u0BCD \u0BAA\u0BB3\u0BCD\u0BB3\u0BBF \u0B9A\u0BC0\u0BB0\u0BC1\u0B9F\u0BC8\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B95\u0BB2\u0BCD\u0BB5\u0BBF \u0B89\u0BAA\u0B95\u0BB0\u0BA3\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BB5\u0BBF\u0BA8\u0BBF\u0BAF\u0BCB\u0B95\u0BAE\u0BCD"
            },
            {
                id: 124,
                date: "25 JUN",
                year: "2023",
                titleEn: "Thirukkural as Indian National Book - International Conference",
                locationEn: "New Delhi",
                descriptionEn: "International Conference on Thirukkural as Indian National Book - New Delhi",
                titleTa: "\u0BA4\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BB1\u0BB3\u0BCD \u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF \u0BA4\u0BC7\u0B9A\u0BBF\u0BAF \u0BA8\u0BC2\u0BB2\u0BCD - \u0BAA\u0BA9\u0BCD\u0BA9\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1 \u0BAE\u0BBE\u0BA8\u0BBE\u0B9F\u0BC1",
                locationTa: "\u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF",
                descriptionTa: "\u0BA4\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BB1\u0BB3\u0BC8 \u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF \u0BA4\u0BC7\u0B9A\u0BBF\u0BAF \u0BA8\u0BC2\u0BB2\u0BBE\u0B95 \u0B85\u0BB1\u0BBF\u0BB5\u0BBF\u0B95\u0BCD\u0B95\u0B95\u0BCD \u0B95\u0BCB\u0BB0\u0BC1\u0BAE\u0BCD \u0BAA\u0BA9\u0BCD\u0BA9\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1 \u0BAE\u0BBE\u0BA8\u0BBE\u0B9F\u0BC1 - \u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF"
            },
            {
                id: 126,
                date: "26 JUN",
                year: "2023",
                titleEn: "IPL Chess Academy Tournament",
                locationEn: "Pavoorchathiram, Tenkasi",
                descriptionEn: "IPL Chess Academy tournament, Pavoorchathiram, Tenkasi District",
                titleTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B9A\u0BC6\u0BB8\u0BCD \u0B85\u0B95\u0BBE\u0B9F\u0BAE\u0BBF \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF",
                locationTa: "\u0BAA\u0BBE\u0BB5\u0BC2\u0BB0\u0BCD\u0B9A\u0BA4\u0BCD\u0BA4\u0BBF\u0BB0\u0BAE\u0BCD, \u0BA4\u0BC6\u0BA9\u0BCD\u0B95\u0BBE\u0B9A\u0BBF",
                descriptionTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0B9A\u0BC6\u0BB8\u0BCD \u0B85\u0B95\u0BBE\u0B9F\u0BAE\u0BBF \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF, \u0BAA\u0BBE\u0BB5\u0BC2\u0BB0\u0BCD\u0B9A\u0BA4\u0BCD\u0BA4\u0BBF\u0BB0\u0BAE\u0BCD, \u0BA4\u0BC6\u0BA9\u0BCD\u0B95\u0BBE\u0B9A\u0BBF \u0BAE\u0BBE\u0BB5\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD"
            },
            {
                id: 123,
                date: "01 JAN",
                year: "2023",
                titleEn: "Tamil Festival 2023 Competition Winners",
                locationEn: "India",
                descriptionEn: "Independence Day 2022 / Tamil Festival 2023 competition for students",
                titleTa: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BB0\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0BA8\u0BBE\u0BB3\u0BCD 2023 \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF \u0BB5\u0BC6\u0BB1\u0BCD\u0BB1\u0BBF\u0BAF\u0BBE\u0BB3\u0BB0\u0BCD\u0B95\u0BB3\u0BCD",
                locationTa: "\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF\u0BBE",
                descriptionTa: "\u0BAE\u0BBE\u0BA3\u0BB5\u0BB0\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BBE\u0BA9 \u0B9A\u0BC1\u0BA4\u0BA8\u0BCD\u0BA4\u0BBF\u0BB0 \u0BA4\u0BBF\u0BA9 \u0BB5\u0BBF\u0BB4\u0BBE 2022 / \u0BA4\u0BAE\u0BBF\u0BB4\u0BB0\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0BA8\u0BBE\u0BB3\u0BCD 2023 \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF\u0B95\u0BB3\u0BCD"
            },
            {
                id: 122,
                date: "18 JUN",
                year: "2023",
                titleEn: "IPL New Delhi State Branch Friends Meeting",
                locationEn: "New Delhi",
                descriptionEn: "New Delhi State Branch Friends Meeting - Press Club, Raisina Road",
                titleTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF \u0BAE\u0BBE\u0BA8\u0BBF\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1",
                locationTa: "\u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF",
                descriptionTa: "\u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF \u0BAE\u0BBE\u0BA8\u0BBF\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1 - \u0BAA\u0BBF\u0BB0\u0BB8\u0BCD \u0B95\u0BBF\u0BB3\u0BAA\u0BCD, \u0BB0\u0BC8\u0B9A\u0BBF\u0BA9\u0BBE \u0B9A\u0BBE\u0BB2\u0BC8"
            },
            {
                id: 121,
                date: "02 JUN",
                year: "2023",
                titleEn: "IPL Bahrain Branch Inauguration",
                locationEn: "Bahrain",
                descriptionEn: "Bahrain Branch Inauguration at The Olive Hotel Auditorium, Juffair, Manama",
                titleTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0BAA\u0BB9\u0BCD\u0BB0\u0BC8\u0BA9\u0BCD \u0B95\u0BBF\u0BB3\u0BC8 \u0BA4\u0BCA\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BBF\u0BB4\u0BBE",
                locationTa: "\u0BAA\u0BB9\u0BCD\u0BB0\u0BC8\u0BA9\u0BCD",
                descriptionTa: "\u0BAA\u0BB9\u0BCD\u0BB0\u0BC8\u0BA9\u0BCD \u0B95\u0BBF\u0BB3\u0BC8 \u0BA4\u0BCA\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BBF\u0BB4\u0BBE - \u0B86\u0BB2\u0BB5\u0BCD \u0BB9\u0BCB\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0B85\u0BB0\u0B99\u0BCD\u0B95\u0BAE\u0BCD, \u0B9C\u0BC1\u0B83\u0BAA\u0BCD\u0BAA\u0BAF\u0BB0\u0BCD, \u0BAE\u0BA9\u0BBE\u0BAE\u0BBE"
            },
            {
                id: 120,
                date: "20 MAY",
                year: "2023",
                titleEn: "26th Friendship Meet",
                locationEn: "New Delhi",
                descriptionEn: "26th Friendship Meet at Shri Vittal Mandir Hall, Ramakrishnapuram, New Delhi",
                titleTa: "26\u0BB5\u0BA4\u0BC1 \u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BAE\u0BCD",
                locationTa: "\u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF",
                descriptionTa: "\u0BB8\u0BCD\u0BB0\u0BC0 \u0BB5\u0BBF\u0BA4\u0BCD\u0BA4\u0BB2\u0BCD \u0BAE\u0BA8\u0BCD\u0BA4\u0BBF\u0BB0\u0BCD \u0BAE\u0BA3\u0BCD\u0B9F\u0BAA\u0BAE\u0BCD, \u0BB0\u0BBE\u0BAE\u0B95\u0BBF\u0BB0\u0BC1\u0BB7\u0BCD\u0BA3\u0BAA\u0BC1\u0BB0\u0BAE\u0BCD, \u0BAA\u0BC1\u0BA4\u0BC1\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD 26\u0BB5\u0BA4\u0BC1 \u0BA8\u0B9F\u0BCD\u0BAA\u0BC1\u0B9A\u0BCD \u0B9A\u0B99\u0BCD\u0B95\u0BAE\u0BAE\u0BCD"
            },
            {
                id: 119,
                date: "16 FEB",
                year: "2023",
                titleEn: "IPL President's Daughter Saranya-Rohit Wedding",
                locationEn: "India",
                descriptionEn: "IPL President's family wedding - Heartfelt thanks to all who participated",
                titleTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BCD \u0BAE\u0B95\u0BB3\u0BCD \u0B9A\u0BB0\u0BA3\u0BCD\u0BAF\u0BBE-\u0BB0\u0BCB\u0BB9\u0BBF\u0BA4\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0BAE\u0BA3\u0BAE\u0BCD",
                locationTa: "\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF\u0BBE",
                descriptionTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BCD \u0B95\u0BC1\u0B9F\u0BC1\u0BAE\u0BCD\u0BAA\u0BA4\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0BAE\u0BA3\u0BAE\u0BCD - \u0BAA\u0B99\u0BCD\u0B95\u0BC7\u0BB1\u0BCD\u0BB1 \u0B85\u0BA9\u0BC8\u0BB5\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAE\u0BA9\u0BAE\u0BBE\u0BB0\u0BCD\u0BA8\u0BCD\u0BA4 \u0BA8\u0BA9\u0BCD\u0BB1\u0BBF"
            },
            {
                id: 118,
                date: "16 FEB",
                year: "2023",
                titleEn: "IPL President's Family Wedding",
                locationEn: "Secunderabad",
                descriptionEn: "IPL President's family wedding at Secunderabad",
                titleTa: "\u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BCD \u0B95\u0BC1\u0B9F\u0BC1\u0BAE\u0BCD\u0BAA\u0BA4\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0BAE\u0BA3\u0BAE\u0BCD",
                locationTa: "\u0B9A\u0BC6\u0B95\u0BA8\u0BCD\u0BA4\u0BBF\u0BB0\u0BBE\u0BAA\u0BBE\u0BA4\u0BCD",
                descriptionTa: "\u0B9A\u0BC6\u0B95\u0BA8\u0BCD\u0BA4\u0BBF\u0BB0\u0BBE\u0BAA\u0BBE\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BA8\u0B9F\u0BC8\u0BAA\u0BC6\u0BB1\u0BCD\u0BB1 \u0B90\u0BAA\u0BBF\u0B8E\u0BB2\u0BCD \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BCD \u0B95\u0BC1\u0B9F\u0BC1\u0BAE\u0BCD\u0BAA\u0BA4\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0BAE\u0BA3\u0BAE\u0BCD"
            },
            {
                id: 117,
                date: "05 FEB",
                year: "2023",
                titleEn: "Rajasthan State Branch Friends Meeting",
                locationEn: "Bhiwadi, Rajasthan",
                descriptionEn: "Rajasthan State Branch Friends Meeting at Bhiwadi Bikaner Restaurant",
                titleTa: "\u0BB0\u0BBE\u0B9C\u0BB8\u0BCD\u0BA4\u0BBE\u0BA9\u0BCD \u0BAE\u0BBE\u0BA8\u0BBF\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1",
                locationTa: "\u0BAA\u0BBF\u0BB5\u0BBE\u0B9F\u0BBF, \u0BB0\u0BBE\u0B9C\u0BB8\u0BCD\u0BA4\u0BBE\u0BA9\u0BCD",
                descriptionTa: "\u0BAA\u0BBF\u0BB5\u0BBE\u0B9F\u0BBF \u0BAA\u0BBF\u0B95\u0BBE\u0BA9\u0BC7\u0BB0\u0BCD \u0B89\u0BA3\u0BB5\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BB0\u0BBE\u0B9C\u0BB8\u0BCD\u0BA4\u0BBE\u0BA9\u0BCD \u0BAE\u0BBE\u0BA8\u0BBF\u0BB2 \u0B95\u0BBF\u0BB3\u0BC8 \u0BA8\u0BA3\u0BCD\u0BAA\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"
            }
        ];
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const newsItems = t1;
    let t2;
    if ($[4] !== query) {
        t2 = query.toLowerCase();
        $[4] = query;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const q = t2;
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [
            "photo-1515169067865-5387ec356754",
            "photo-1544531581-9847b68c8c95",
            "photo-1551836022-d5d88e9218df",
            "photo-1520975682031-a4e34a928ad3",
            "photo-1492684223066-81342ee5ff30",
            "photo-1521737604893-d14cc237f11d"
        ];
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const imagePool = t3;
    let t4;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "NewsEventsContent[getImageUrl]": (id)=>{
                const key = imagePool[id % imagePool.length];
                return `https://images.unsplash.com/${key}?auto=format&fit=crop&w=1200&q=60`;
            }
        })["NewsEventsContent[getImageUrl]"];
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const getImageUrl = t4;
    let t5;
    if ($[8] !== lang) {
        t5 = ({
            "NewsEventsContent[getLocalized]": (item, field)=>{
                if (lang === "ta") {
                    return item[`${field}Ta`] || item[`${field}En`];
                }
                return item[`${field}En`];
            }
        })["NewsEventsContent[getLocalized]"];
        $[8] = lang;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    const getLocalized = t5;
    let t6;
    bb0: {
        if (!q) {
            t6 = newsItems;
            break bb0;
        }
        let t7;
        if ($[10] !== getLocalized || $[11] !== q) {
            t7 = newsItems.filter({
                "NewsEventsContent[newsItems.filter()]": (item_0)=>{
                    const title = getLocalized(item_0, "title").toLowerCase();
                    const desc = getLocalized(item_0, "description").toLowerCase();
                    const loc = getLocalized(item_0, "location").toLowerCase();
                    return title.includes(q) || desc.includes(q) || loc.includes(q);
                }
            }["NewsEventsContent[newsItems.filter()]"]);
            $[10] = getLocalized;
            $[11] = q;
            $[12] = t7;
        } else {
            t7 = $[12];
        }
        t6 = t7;
    }
    const filteredNews = t6;
    let t7;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "NewsEventsContent[useEffect()]": ()=>{
                const id_0 = setTimeout({
                    "NewsEventsContent[useEffect() > setTimeout()]": ()=>setCurrentPage(1)
                }["NewsEventsContent[useEffect() > setTimeout()]"], 0);
                return ()=>clearTimeout(id_0);
            }
        })["NewsEventsContent[useEffect()]"];
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== q) {
        t8 = [
            q
        ];
        $[14] = q;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    const itemsPerPage = viewMode === "grid" ? 9 : 10;
    const totalPages = Math.ceil(filteredNews.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t9;
    if ($[16] !== filteredNews || $[17] !== getLocalized || $[18] !== itemsPerPage || $[19] !== startIndex || $[20] !== t || $[21] !== viewMode) {
        const currentItems = filteredNews.slice(startIndex, startIndex + itemsPerPage);
        let t15;
        let t16;
        let t17;
        let t18;
        if ($[28] !== filteredNews || $[29] !== getLocalized || $[30] !== t || $[31] !== viewMode) {
            const featuredEvents = filteredNews.slice(0, 3);
            t11 = "min-h-screen bg-neutral-50";
            let t19;
            if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
                t19 = {
                    minHeight: "320px"
                };
                $[38] = t19;
            } else {
                t19 = $[38];
            }
            let t20;
            if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
                t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 z-0 pointer-events-none",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/Images/iplbanner.png",
                            alt: "News & Events background",
                            fill: true,
                            className: "opacity-40 object-contain",
                            style: {
                                objectPosition: "center"
                            }
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                            lineNumber: 378,
                            columnNumber: 73
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                position: "absolute",
                                inset: 0,
                                backgroundColor: "rgba(0,0,0,0.04)"
                            }
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                            lineNumber: 380,
                            columnNumber: 16
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 378,
                    columnNumber: 15
                }, this);
                $[39] = t20;
            } else {
                t20 = $[39];
            }
            let t21;
            if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
                t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                    className: "w-4 h-4 text-red-600"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 391,
                    columnNumber: 15
                }, this);
                $[40] = t21;
            } else {
                t21 = $[40];
            }
            let t22;
            if ($[41] !== t) {
                t22 = t("news.badge", "Latest Updates");
                $[41] = t;
                $[42] = t22;
            } else {
                t22 = $[42];
            }
            let t23;
            if ($[43] !== t22) {
                t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white border border-neutral-200 shadow-sm mb-8 animate-fade-in",
                    children: [
                        t21,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs font-semibold tracking-wider uppercase text-neutral-600",
                            children: t22
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                            lineNumber: 406,
                            columnNumber: 157
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 406,
                    columnNumber: 15
                }, this);
                $[43] = t22;
                $[44] = t23;
            } else {
                t23 = $[44];
            }
            let t24;
            if ($[45] !== t) {
                t24 = t("news.title", "News & Events");
                $[45] = t;
                $[46] = t24;
            } else {
                t24 = $[46];
            }
            let t25;
            if ($[47] !== t24) {
                t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-5xl md:text-6xl font-extrabold tracking-tight text-neutral-900 mb-6 animate-slide-up",
                    children: t24
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 422,
                    columnNumber: 15
                }, this);
                $[47] = t24;
                $[48] = t25;
            } else {
                t25 = $[48];
            }
            let t26;
            if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
                t26 = {
                    animationDelay: "0.1s"
                };
                $[49] = t26;
            } else {
                t26 = $[49];
            }
            let t27;
            if ($[50] !== t) {
                t27 = t("news.subtitle", "Discover the latest happenings, milestones, and celebrations from the Indian Penpals' League community");
                $[50] = t;
                $[51] = t27;
            } else {
                t27 = $[51];
            }
            let t28;
            if ($[52] !== t27) {
                t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg md:text-xl text-neutral-600 leading-relaxed max-w-3xl mx-auto animate-slide-up",
                    style: t26,
                    children: t27
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 447,
                    columnNumber: 15
                }, this);
                $[52] = t27;
                $[53] = t28;
            } else {
                t28 = $[53];
            }
            let t29;
            if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
                t29 = {
                    animationDelay: "0.2s"
                };
                $[54] = t29;
            } else {
                t29 = $[54];
            }
            let t30;
            if ($[55] !== t) {
                t30 = t("news.search_placeholder", "Search events...");
                $[55] = t;
                $[56] = t30;
            } else {
                t30 = $[56];
            }
            let t31;
            if ($[57] !== t30) {
                t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$components$2f$ui$2f$GlobalSearch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "hero",
                    placeholder: t30
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 472,
                    columnNumber: 15
                }, this);
                $[57] = t30;
                $[58] = t31;
            } else {
                t31 = $[58];
            }
            let t32;
            if ($[59] === Symbol.for("react.memo_cache_sentinel")) {
                t32 = ({
                    "NewsEventsContent[<button>.onClick]": ()=>setViewMode("grid")
                })["NewsEventsContent[<button>.onClick]"];
                $[59] = t32;
            } else {
                t32 = $[59];
            }
            const t33 = `px-5 py-2 rounded-full text-sm font-semibold transition ${viewMode === "grid" ? "bg-red-700 text-white shadow-md" : "text-neutral-600 hover:text-neutral-900"}`;
            let t34;
            if ($[60] !== t) {
                t34 = t("news.view_grid", "Grid");
                $[60] = t;
                $[61] = t34;
            } else {
                t34 = $[61];
            }
            let t35;
            if ($[62] !== t33 || $[63] !== t34) {
                t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: t32,
                    className: t33,
                    children: t34
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 498,
                    columnNumber: 15
                }, this);
                $[62] = t33;
                $[63] = t34;
                $[64] = t35;
            } else {
                t35 = $[64];
            }
            let t36;
            if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
                t36 = ({
                    "NewsEventsContent[<button>.onClick]": ()=>setViewMode("timeline")
                })["NewsEventsContent[<button>.onClick]"];
                $[65] = t36;
            } else {
                t36 = $[65];
            }
            const t37 = `px-5 py-2 rounded-full text-sm font-semibold transition ${viewMode === "timeline" ? "bg-red-700 text-white shadow-md" : "text-neutral-600 hover:text-neutral-900"}`;
            let t38;
            if ($[66] !== t) {
                t38 = t("news.view_timeline", "Timeline");
                $[66] = t;
                $[67] = t38;
            } else {
                t38 = $[67];
            }
            let t39;
            if ($[68] !== t37 || $[69] !== t38) {
                t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: t36,
                    className: t37,
                    children: t38
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 525,
                    columnNumber: 15
                }, this);
                $[68] = t37;
                $[69] = t38;
                $[70] = t39;
            } else {
                t39 = $[70];
            }
            let t40;
            if ($[71] !== t35 || $[72] !== t39) {
                t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 bg-white border border-neutral-200 rounded-full px-2 py-2",
                    children: [
                        t35,
                        t39
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 534,
                    columnNumber: 15
                }, this);
                $[71] = t35;
                $[72] = t39;
                $[73] = t40;
            } else {
                t40 = $[73];
            }
            let t41;
            if ($[74] !== t31 || $[75] !== t40) {
                t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-10 flex flex-col md:flex-row items-center justify-center gap-4 animate-fade-in",
                    style: t29,
                    children: [
                        t31,
                        t40
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 543,
                    columnNumber: 15
                }, this);
                $[74] = t31;
                $[75] = t40;
                $[76] = t41;
            } else {
                t41 = $[76];
            }
            if ($[77] !== t23 || $[78] !== t25 || $[79] !== t28 || $[80] !== t41) {
                t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "relative bg-transparent pt-12 md:pt-16 lg:pt-20 pb-8 overflow-hidden",
                    style: t19,
                    children: [
                        t20,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative z-10 container-custom mx-auto text-center",
                            children: [
                                t23,
                                t25,
                                t28,
                                t41
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                            lineNumber: 551,
                            columnNumber: 122
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 551,
                    columnNumber: 15
                }, this);
                $[77] = t23;
                $[78] = t25;
                $[79] = t28;
                $[80] = t41;
                $[81] = t12;
            } else {
                t12 = $[81];
            }
            t17 = "container-custom mx-auto mt-8 mb-20";
            let t42;
            if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
                t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__["TrendingUp"], {
                    className: "w-6 h-6 text-red-700"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 563,
                    columnNumber: 15
                }, this);
                $[82] = t42;
            } else {
                t42 = $[82];
            }
            let t43;
            if ($[83] !== t) {
                t43 = t("news.featured", "Featured Events");
                $[83] = t;
                $[84] = t43;
            } else {
                t43 = $[84];
            }
            let t44;
            if ($[85] !== t43) {
                t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        t42,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-bold text-neutral-900",
                            children: t43
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                            lineNumber: 578,
                            columnNumber: 61
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 578,
                    columnNumber: 15
                }, this);
                $[85] = t43;
                $[86] = t44;
            } else {
                t44 = $[86];
            }
            let t45;
            if ($[87] !== t) {
                t45 = t("news.featured_sub", "Highlighting recent impactful activities");
                $[87] = t;
                $[88] = t45;
            } else {
                t45 = $[88];
            }
            let t46;
            if ($[89] !== t45) {
                t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-sm text-neutral-500",
                    children: t45
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 594,
                    columnNumber: 15
                }, this);
                $[89] = t45;
                $[90] = t46;
            } else {
                t46 = $[90];
            }
            if ($[91] !== t44 || $[92] !== t46) {
                t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between mb-8",
                    children: [
                        t44,
                        t46
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 601,
                    columnNumber: 15
                }, this);
                $[91] = t44;
                $[92] = t46;
                $[93] = t18;
            } else {
                t18 = $[93];
            }
            t15 = "grid md:grid-cols-3 gap-8";
            t16 = featuredEvents.map({
                "NewsEventsContent[featuredEvents.map()]": (item_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-neutral-200 hover:border-neutral-300 transition-all duration-300 hover:-translate-y-1 cursor-pointer",
                        onClick: {
                            "NewsEventsContent[featuredEvents.map() > <article>.onClick]": ()=>setSelectedItem(item_1)
                        }["NewsEventsContent[featuredEvents.map() > <article>.onClick]"],
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative h-48",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: getImageUrl(item_1.id),
                                        alt: getLocalized(item_1, "title"),
                                        fill: true,
                                        sizes: "(max-width:768px) 100vw, 33vw",
                                        className: "object-cover group-hover:scale-105 transition-transform duration-700"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 106
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute inset-0 bg-black/30 group-hover:bg-black/20 transition"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 311
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-semibold bg-white/80 backdrop-blur-sm text-red-700 shadow",
                                        children: t("news.new_badge", "NEW")
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 394
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute bottom-4 left-4 right-4 text-white drop-shadow",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-bold text-lg line-clamp-2",
                                            children: getLocalized(item_1, "title")
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                            lineNumber: 612,
                                            columnNumber: 634
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 561
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 612,
                                columnNumber: 75
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 mb-4 text-neutral-600 text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                className: "w-4 h-4 text-red-600"
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 612,
                                                columnNumber: 821
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-semibold",
                                                children: [
                                                    item_1.date,
                                                    " ",
                                                    item_1.year
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 612,
                                                columnNumber: 866
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 750
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mb-3 text-sm text-neutral-500",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                className: "w-4 h-4 text-red-600"
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 612,
                                                columnNumber: 1009
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "line-clamp-1",
                                                children: getLocalized(item_1, "location")
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 612,
                                                columnNumber: 1052
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 938
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-neutral-600 mb-5 line-clamp-3 leading-relaxed",
                                        children: getLocalized(item_1, "description")
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 1130
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "inline-flex items-center gap-2 text-red-700 font-semibold text-sm hover:gap-3 transition-all",
                                        children: [
                                            t("news.more_info", "More Info"),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 612,
                                                columnNumber: 1393
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 612,
                                        columnNumber: 1245
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 612,
                                columnNumber: 729
                            }, this)
                        ]
                    }, item_1.id, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                        lineNumber: 610,
                        columnNumber: 62
                    }, this)
            }["NewsEventsContent[featuredEvents.map()]"]);
            $[28] = filteredNews;
            $[29] = getLocalized;
            $[30] = t;
            $[31] = viewMode;
            $[32] = t11;
            $[33] = t12;
            $[34] = t15;
            $[35] = t16;
            $[36] = t17;
            $[37] = t18;
        } else {
            t11 = $[32];
            t12 = $[33];
            t15 = $[34];
            t16 = $[35];
            t17 = $[36];
            t18 = $[37];
        }
        let t19;
        if ($[94] !== t15 || $[95] !== t16) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: t15,
                children: t16
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 634,
                columnNumber: 13
            }, this);
            $[94] = t15;
            $[95] = t16;
            $[96] = t19;
        } else {
            t19 = $[96];
        }
        if ($[97] !== t17 || $[98] !== t18 || $[99] !== t19) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: t17,
                children: [
                    t18,
                    t19
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 642,
                columnNumber: 13
            }, this);
            $[97] = t17;
            $[98] = t18;
            $[99] = t19;
            $[100] = t13;
        } else {
            t13 = $[100];
        }
        let t20;
        if ($[101] !== t) {
            t20 = t("news.all_events", "All Events");
            $[101] = t;
            $[102] = t20;
        } else {
            t20 = $[102];
        }
        let t21;
        if ($[103] !== t20) {
            t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl font-bold text-neutral-900",
                children: t20
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 660,
                columnNumber: 13
            }, this);
            $[103] = t20;
            $[104] = t21;
        } else {
            t21 = $[104];
        }
        let t22;
        if ($[105] !== t) {
            t22 = t("news.all_events_sub", "Browse events in grid or timeline view. Use search to filter results by title, description or location.");
            $[105] = t;
            $[106] = t22;
        } else {
            t22 = $[106];
        }
        let t23;
        if ($[107] !== t22) {
            t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-neutral-500 max-w-xl",
                children: t22
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 676,
                columnNumber: 13
            }, this);
            $[107] = t22;
            $[108] = t23;
        } else {
            t23 = $[108];
        }
        if ($[109] !== t21 || $[110] !== t23) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "container-custom mx-auto mb-10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col md:flex-row md:items-center md:justify-between gap-4",
                    children: [
                        t21,
                        t23
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 683,
                    columnNumber: 65
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 683,
                columnNumber: 13
            }, this);
            $[109] = t21;
            $[110] = t23;
            $[111] = t14;
        } else {
            t14 = $[111];
        }
        t9 = "container-custom mx-auto pb-16";
        t10 = viewMode === "grid" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid md:grid-cols-2 lg:grid-cols-3 gap-8",
            children: currentItems.map({
                "NewsEventsContent[currentItems.map()]": (item_2)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        onClick: {
                            "NewsEventsContent[currentItems.map() > <article>.onClick]": ()=>setSelectedItem(item_2)
                        }["NewsEventsContent[currentItems.map() > <article>.onClick]"],
                        className: "group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-neutral-200 hover:border-neutral-300 transition-all duration-300 flex flex-col hover:-translate-y-1 cursor-pointer",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative h-44",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: getImageUrl(item_2.id),
                                        alt: getLocalized(item_2, "title"),
                                        fill: true,
                                        sizes: "(max-width:768px) 100vw, (max-width:1024px) 50vw, 33vw",
                                        className: "object-cover group-hover:scale-105 transition-transform duration-700",
                                        priority: false
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 314
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute inset-0 bg-black/20 group-hover:bg-black/10 transition"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 561
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute left-3 top-3 inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold text-white bg-white/20 backdrop-blur-sm",
                                        children: item_2.id
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 644
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 694,
                                columnNumber: 283
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-6 flex flex-col flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mb-4 text-neutral-600 text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 text-red-700",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                        lineNumber: 694,
                                                        columnNumber: 999
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold",
                                                        children: item_2.date
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                        lineNumber: 694,
                                                        columnNumber: 1031
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 694,
                                                columnNumber: 945
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-neutral-500",
                                                children: item_2.year
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 694,
                                                columnNumber: 1089
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 864
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-bold text-neutral-900 mb-3 line-clamp-2 group-hover:text-red-700 transition-colors",
                                        children: getLocalized(item_2, "title")
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 1158
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start gap-2 mb-3 text-sm text-neutral-500",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                className: "w-4 h-4 text-red-600 mt-0.5"
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 694,
                                                columnNumber: 1376
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "line-clamp-1",
                                                children: getLocalized(item_2, "location")
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 694,
                                                columnNumber: 1426
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 1306
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-neutral-600 line-clamp-3 leading-relaxed mb-4",
                                        children: getLocalized(item_2, "description")
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 1504
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between pt-3 border-t border-neutral-200 mt-auto",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "inline-flex items-center gap-2 text-red-700 font-semibold text-sm hover:gap-3 transition-all",
                                                children: [
                                                    t("news.more_info", "More Info"),
                                                    " ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                        lineNumber: 694,
                                                        columnNumber: 1859
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 694,
                                                columnNumber: 1711
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-neutral-400",
                                                children: getLocalized(item_2, "location")
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 694,
                                                columnNumber: 1904
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 694,
                                        columnNumber: 1619
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 694,
                                columnNumber: 822
                            }, this)
                        ]
                    }, item_2.id, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                        lineNumber: 692,
                        columnNumber: 60
                    }, this)
            }["NewsEventsContent[currentItems.map()]"])
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
            lineNumber: 691,
            columnNumber: 33
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-4xl mx-auto",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-8 top-0 bottom-0 w-1 bg-linear-to-b from-red-200 via-red-300 to-red-200 rounded-full"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                        lineNumber: 695,
                        columnNumber: 121
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-8",
                        children: currentItems.map({
                            "NewsEventsContent[currentItems.map()]": (item_3)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative flex gap-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative shrink-0",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-14 h-14 bg-linear-to-br from-red-600 to-red-700 rounded-full flex items-center justify-center text-white shadow-md",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                                    className: "w-6 h-6"
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                    lineNumber: 696,
                                                    columnNumber: 286
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 696,
                                                columnNumber: 152
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                            lineNumber: 696,
                                            columnNumber: 117
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            onClick: {
                                                "NewsEventsContent[currentItems.map() > <div>.onClick]": ()=>setSelectedItem(item_3)
                                            }["NewsEventsContent[currentItems.map() > <div>.onClick]"],
                                            className: "flex-1 bg-white rounded-2xl p-6 shadow-sm border border-neutral-200 hover:shadow-xl transition cursor-pointer hover:-translate-y-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-3 mb-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "px-3 py-1 bg-red-50 text-red-700 text-xs font-semibold rounded-full",
                                                            children: item_3.date
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                            lineNumber: 698,
                                                            columnNumber: 264
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-neutral-500",
                                                            children: item_3.year
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                            lineNumber: 698,
                                                            columnNumber: 370
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                    lineNumber: 698,
                                                    columnNumber: 218
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold text-neutral-900 mb-3",
                                                    children: getLocalized(item_3, "title")
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                    lineNumber: 698,
                                                    columnNumber: 439
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-start gap-2 mb-3 text-sm text-neutral-500",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                            className: "w-4 h-4 text-red-600 mt-0.5"
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                            lineNumber: 698,
                                                            columnNumber: 601
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: getLocalized(item_3, "location")
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                            lineNumber: 698,
                                                            columnNumber: 651
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                    lineNumber: 698,
                                                    columnNumber: 531
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm text-neutral-600 leading-relaxed mb-5",
                                                    children: getLocalized(item_3, "description")
                                                }, void 0, false, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                    lineNumber: 698,
                                                    columnNumber: 704
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "inline-flex items-center gap-2 text-red-700 font-semibold text-sm hover:gap-3 transition-all",
                                                    children: [
                                                        t("news.view_details", "View Details"),
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                            className: "w-4 h-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                            lineNumber: 698,
                                                            columnNumber: 960
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                    lineNumber: 698,
                                                    columnNumber: 806
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                            lineNumber: 696,
                                            columnNumber: 327
                                        }, this)
                                    ]
                                }, item_3.id, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                    lineNumber: 696,
                                    columnNumber: 64
                                }, this)
                        }["NewsEventsContent[currentItems.map()]"])
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                        lineNumber: 695,
                        columnNumber: 239
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 695,
                columnNumber: 95
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
            lineNumber: 695,
            columnNumber: 60
        }, this);
        $[16] = filteredNews;
        $[17] = getLocalized;
        $[18] = itemsPerPage;
        $[19] = startIndex;
        $[20] = t;
        $[21] = viewMode;
        $[22] = t10;
        $[23] = t11;
        $[24] = t12;
        $[25] = t13;
        $[26] = t14;
        $[27] = t9;
    } else {
        t10 = $[22];
        t11 = $[23];
        t12 = $[24];
        t13 = $[25];
        t14 = $[26];
        t9 = $[27];
    }
    let t15;
    if ($[112] !== currentPage || $[113] !== t || $[114] !== totalPages) {
        t15 = totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-center items-center gap-2 mt-14",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: {
                        "NewsEventsContent[<button>.onClick]": ()=>setCurrentPage(_NewsEventsContentButtonOnClickSetCurrentPage)
                    }["NewsEventsContent[<button>.onClick]"],
                    disabled: currentPage === 1,
                    className: `px-5 py-2.5 rounded-full text-sm font-semibold transition ${currentPage === 1 ? "bg-neutral-100 text-neutral-400 cursor-not-allowed" : "bg-red-700 text-white hover:bg-red-800 shadow-sm"}`,
                    children: t("pagination.prev", "Previous")
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 722,
                    columnNumber: 91
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: Array.from({
                        length: totalPages
                    }, _NewsEventsContentArrayFrom).map({
                        "NewsEventsContent[(anonymous)()]": (page)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: {
                                    "NewsEventsContent[(anonymous)() > <button>.onClick]": ()=>setCurrentPage(page)
                                }["NewsEventsContent[(anonymous)() > <button>.onClick]"],
                                className: `w-10 h-10 rounded-full text-sm font-semibold transition ${page === currentPage ? "bg-red-700 text-white shadow-sm" : "bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50"}`,
                                children: page
                            }, page, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 727,
                                columnNumber: 55
                            }, this)
                    }["NewsEventsContent[(anonymous)()]"])
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 724,
                    columnNumber: 322
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: {
                        "NewsEventsContent[<button>.onClick]": ()=>setCurrentPage({
                                "NewsEventsContent[<button>.onClick > setCurrentPage()]": (p_0)=>Math.min(totalPages, p_0 + 1)
                            }["NewsEventsContent[<button>.onClick > setCurrentPage()]"])
                    }["NewsEventsContent[<button>.onClick]"],
                    disabled: currentPage === totalPages,
                    className: `px-5 py-2.5 rounded-full text-sm font-semibold transition ${currentPage === totalPages ? "bg-neutral-100 text-neutral-400 cursor-not-allowed" : "bg-red-700 text-white hover:bg-red-800 shadow-sm"}`,
                    children: t("pagination.next", "Next")
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 730,
                    columnNumber: 54
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
            lineNumber: 722,
            columnNumber: 29
        }, this);
        $[112] = currentPage;
        $[113] = t;
        $[114] = totalPages;
        $[115] = t15;
    } else {
        t15 = $[115];
    }
    let t16;
    if ($[116] !== t10 || $[117] !== t15 || $[118] !== t9) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t9,
            children: [
                t10,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
            lineNumber: 744,
            columnNumber: 11
        }, this);
        $[116] = t10;
        $[117] = t15;
        $[118] = t9;
        $[119] = t16;
    } else {
        t16 = $[119];
    }
    let t17;
    if ($[120] !== getLocalized || $[121] !== selectedItem) {
        t17 = selectedItem && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-sm",
            onClick: {
                "NewsEventsContent[<div>.onClick]": ()=>setSelectedItem(null)
            }["NewsEventsContent[<div>.onClick]"],
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-in fade-in zoom-in-95 duration-300",
                onClick: _NewsEventsContentDivOnClick,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "sticky top-0 flex justify-end p-4 bg-white/80 backdrop-blur-sm border-b border-neutral-200 z-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: {
                                "NewsEventsContent[<button>.onClick]": ()=>setSelectedItem(null)
                            }["NewsEventsContent[<button>.onClick]"],
                            className: "w-10 h-10 rounded-full bg-red-50 hover:bg-red-100 text-red-700 hover:text-red-800 flex items-center justify-center transition-colors",
                            "aria-label": "Close modal",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 758,
                                columnNumber: 223
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                            lineNumber: 756,
                            columnNumber: 334
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                        lineNumber: 756,
                        columnNumber: 221
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative h-64 md:h-80 w-full overflow-hidden bg-neutral-200",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: getImageUrl(selectedItem.id),
                                    alt: getLocalized(selectedItem, "title"),
                                    fill: true,
                                    className: "object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                    lineNumber: 758,
                                    columnNumber: 345
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 758,
                                columnNumber: 268
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-6 md:p-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "inline-block px-3 py-1 bg-red-50 rounded-full mb-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-semibold text-red-700 uppercase tracking-wider",
                                            children: "News & Events"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                            lineNumber: 758,
                                            columnNumber: 570
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 758,
                                        columnNumber: 502
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-2xl md:text-3xl font-bold text-neutral-900 mb-2",
                                        children: getLocalized(selectedItem, "title")
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 758,
                                        columnNumber: 678
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap items-center gap-4 text-sm text-neutral-600 mb-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1 font-semibold text-red-700",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                        lineNumber: 758,
                                                        columnNumber: 938
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            selectedItem.date,
                                                            " ",
                                                            selectedItem.year
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                        lineNumber: 758,
                                                        columnNumber: 970
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 758,
                                                columnNumber: 870
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                        className: "w-4 h-4 text-red-700"
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                        lineNumber: 758,
                                                        columnNumber: 1069
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: getLocalized(selectedItem, "location")
                                                    }, void 0, false, {
                                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                        lineNumber: 758,
                                                        columnNumber: 1112
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                                lineNumber: 758,
                                                columnNumber: 1028
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 758,
                                        columnNumber: 789
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-neutral-700 leading-relaxed mb-6 text-base md:text-lg",
                                        children: getLocalized(selectedItem, "description")
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 758,
                                        columnNumber: 1177
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: {
                                            "NewsEventsContent[<button>.onClick]": ()=>setSelectedItem(null)
                                        }["NewsEventsContent[<button>.onClick]"],
                                        className: "inline-flex items-center gap-2 px-6 py-3 bg-red-700 text-white rounded-full font-semibold hover:bg-red-800 transition-colors w-full sm:w-auto justify-center",
                                        children: "Close"
                                    }, void 0, false, {
                                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                        lineNumber: 758,
                                        columnNumber: 1298
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                                lineNumber: 758,
                                columnNumber: 474
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                        lineNumber: 758,
                        columnNumber: 263
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 756,
                columnNumber: 44
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
            lineNumber: 754,
            columnNumber: 27
        }, this);
        $[120] = getLocalized;
        $[121] = selectedItem;
        $[122] = t17;
    } else {
        t17 = $[122];
    }
    let t18;
    if ($[123] !== t11 || $[124] !== t12 || $[125] !== t13 || $[126] !== t14 || $[127] !== t16 || $[128] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t11,
            children: [
                t12,
                t13,
                t14,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
            lineNumber: 769,
            columnNumber: 11
        }, this);
        $[123] = t11;
        $[124] = t12;
        $[125] = t13;
        $[126] = t14;
        $[127] = t16;
        $[128] = t17;
        $[129] = t18;
    } else {
        t18 = $[129];
    }
    return t18;
}
_s(NewsEventsContent, "OLpFX/S1H6UYuXzB9RhiL9MbZ3Q=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = NewsEventsContent;
function _NewsEventsContentDivOnClick(e) {
    return e.stopPropagation();
}
function _NewsEventsContentArrayFrom(_, i) {
    return i + 1;
}
function _NewsEventsContentButtonOnClickSetCurrentPage(p) {
    return Math.max(1, p - 1);
}
function NewsEvents() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "7b173bbdc1b66d2c500ff379a167e8bf1548fa63dda60f953d8a36e5bc3318e6") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7b173bbdc1b66d2c500ff379a167e8bf1548fa63dda60f953d8a36e5bc3318e6";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-h-screen flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-gray-500",
                    children: "Loading..."
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                    lineNumber: 801,
                    columnNumber: 93
                }, void 0)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 801,
                columnNumber: 30
            }, void 0),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NewsEventsContent, {}, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
                lineNumber: 801,
                columnNumber: 148
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/news-events/page.tsx",
            lineNumber: 801,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c1 = NewsEvents;
var _c, _c1;
__turbopack_context__.k.register(_c, "NewsEventsContent");
__turbopack_context__.k.register(_c1, "NewsEvents");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=IPL-Website-test-main_src_app_news-events_page_tsx_1e35c43b._.js.map