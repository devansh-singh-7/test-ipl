(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/IPL-Website-test-main_src_app_news-events_page_tsx_1e35c43b._.js",
  "static/chunks/37e5c_c9e0325e._.js"
],
    source: "dynamic"
});
