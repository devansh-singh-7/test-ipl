(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/37e5c_c5ebcd83._.js",
  "static/chunks/IPL-Website-test-main_src_app_our-team_page_tsx_1c3fddc1._.js"
],
    source: "dynamic"
});
