(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IPL-Website-test-main/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hand$2d$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HandHeart$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/hand-heart.js [app-client] (ecmascript) <export default as HandHeart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$quote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Quote$3e$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/node_modules/lucide-react/dist/esm/icons/quote.js [app-client] (ecmascript) <export default as Quote>");
var __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/IPL-Website-test-main/src/contexts/TranslationContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
// Images referenced from public folder
const img1 = '/Images/carousel-1.jpg';
const img2 = '/Images/carousel-2.jpg';
const img3 = '/Images/carousel-3.jpg';
const ImageCarousel = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(49);
    if ($[0] !== "9b50be85f0d2a8b6e45ece538e47e8087b13e8dfae607a7afe87995757fd69ed") {
        for(let $i = 0; $i < 49; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9b50be85f0d2a8b6e45ece538e47e8087b13e8dfae607a7afe87995757fd69ed";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isTransitioning, setIsTransitioning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t0;
    if ($[1] !== t) {
        t0 = t("home.carousel1_title", "IPL Community Moments");
        $[1] = t;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    if ($[3] !== t0) {
        t1 = {
            src: img1,
            alt: t0
        };
        $[3] = t0;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== t) {
        t2 = t("home.carousel2_title", "Humanitarian Service");
        $[5] = t;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    let t3;
    if ($[7] !== t2) {
        t3 = {
            src: img2,
            alt: t2
        };
        $[7] = t2;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== t) {
        t4 = t("home.carousel3_title", "Friendship Meet Highlights");
        $[9] = t;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== t4) {
        t5 = {
            src: img3,
            alt: t4
        };
        $[11] = t4;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] !== t1 || $[14] !== t3 || $[15] !== t5) {
        t6 = [
            t1,
            t3,
            t5
        ];
        $[13] = t1;
        $[14] = t3;
        $[15] = t5;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    const images = t6;
    let t7;
    if ($[17] !== isTransitioning) {
        t7 = (nextIndex)=>{
            if (isTransitioning) {
                return;
            }
            setIsTransitioning(true);
            setCurrentIndex(nextIndex);
            setTimeout(()=>setIsTransitioning(false), 500);
        };
        $[17] = isTransitioning;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    const changeIndex = t7;
    let t8;
    if ($[19] !== changeIndex || $[20] !== currentIndex || $[21] !== images.length) {
        t8 = ()=>{
            const next = currentIndex === 0 ? images.length - 1 : currentIndex - 1;
            changeIndex(next);
        };
        $[19] = changeIndex;
        $[20] = currentIndex;
        $[21] = images.length;
        $[22] = t8;
    } else {
        t8 = $[22];
    }
    const goToPrevious = t8;
    let t9;
    if ($[23] !== changeIndex || $[24] !== currentIndex || $[25] !== images.length) {
        t9 = ()=>{
            const next_0 = currentIndex === images.length - 1 ? 0 : currentIndex + 1;
            changeIndex(next_0);
        };
        $[23] = changeIndex;
        $[24] = currentIndex;
        $[25] = images.length;
        $[26] = t9;
    } else {
        t9 = $[26];
    }
    const goToNext = t9;
    let t10;
    let t11;
    if ($[27] !== images.length) {
        t10 = ()=>{
            const timer = setInterval(()=>{
                setCurrentIndex((prev)=>prev === images.length - 1 ? 0 : prev + 1);
            }, 5000);
            return ()=>clearInterval(timer);
        };
        t11 = [
            images.length
        ];
        $[27] = images.length;
        $[28] = t10;
        $[29] = t11;
    } else {
        t10 = $[28];
        t11 = $[29];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t10, t11);
    let t12;
    if ($[30] !== currentIndex || $[31] !== images || $[32] !== t) {
        t12 = images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `absolute inset-0 transition-opacity duration-700 ease-in-out ${index === currentIndex ? "opacity-100" : "opacity-0"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-linear-to-t from-black/80 via-black/20 to-transparent z-10"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 165,
                        columnNumber: 186
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: img.src,
                        alt: img.alt ?? "",
                        fill: true,
                        sizes: "100vw",
                        className: "object-cover transform transition-transform duration-[10s] hover:scale-110",
                        priority: index === 0
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 165,
                        columnNumber: 284
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-0 left-0 right-0 p-4 sm:p-6 md:p-8 z-20 text-white transform transition-all duration-500 translate-y-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold mb-2 sm:mb-3 drop-shadow-lg",
                                children: img.alt
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 165,
                                columnNumber: 599
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm sm:text-base md:text-lg text-neutral-200 max-w-2xl drop-shadow-md line-clamp-2 sm:line-clamp-none",
                                children: index === 0 ? t("home.carousel1_desc", "Snapshots from our events and outreach") : index === 1 ? t("home.carousel2_desc", "Medical, education, and welfare support efforts") : t("home.carousel3_desc", "Celebrating bonds that bring people together")
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 165,
                                columnNumber: 711
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 165,
                        columnNumber: 463
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, index, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 165,
                columnNumber: 38
            }, ("TURBOPACK compile-time value", void 0)));
        $[30] = currentIndex;
        $[31] = images;
        $[32] = t;
        $[33] = t12;
    } else {
        t12 = $[33];
    }
    let t13;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
            className: "w-5 h-5 sm:w-6 sm:h-6"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 175,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    let t14;
    if ($[35] !== goToPrevious) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: goToPrevious,
            className: "absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-30 p-2 sm:p-3 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white hover:text-red-700 transition-all opacity-50 sm:opacity-0 group-hover:opacity-100 sm:-translate-x-4 sm:group-hover:translate-x-0",
            children: t13
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 182,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[35] = goToPrevious;
        $[36] = t14;
    } else {
        t14 = $[36];
    }
    let t15;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
            className: "w-5 h-5 sm:w-6 sm:h-6"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 190,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[37] = t15;
    } else {
        t15 = $[37];
    }
    let t16;
    if ($[38] !== goToNext) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: goToNext,
            className: "absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-30 p-2 sm:p-3 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white hover:text-red-700 transition-all opacity-50 sm:opacity-0 group-hover:opacity-100 sm:translate-x-4 sm:group-hover:translate-x-0",
            children: t15
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 197,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[38] = goToNext;
        $[39] = t16;
    } else {
        t16 = $[39];
    }
    let t17;
    if ($[40] !== changeIndex || $[41] !== currentIndex || $[42] !== images) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute bottom-6 right-6 z-30 flex gap-2",
            children: images.map((_, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>changeIndex(index_0),
                    className: `h-2 rounded-full transition-all duration-300 ${index_0 === currentIndex ? "w-8 bg-red-600" : "w-2 bg-white/50 hover:bg-white"}`
                }, index_0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 205,
                    columnNumber: 98
                }, ("TURBOPACK compile-time value", void 0)))
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 205,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[40] = changeIndex;
        $[41] = currentIndex;
        $[42] = images;
        $[43] = t17;
    } else {
        t17 = $[43];
    }
    let t18;
    if ($[44] !== t12 || $[45] !== t14 || $[46] !== t16 || $[47] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative h-[280px] sm:h-[360px] md:h-[420px] lg:h-[520px] w-full overflow-hidden rounded-xl md:rounded-2xl shadow-2xl group",
            children: [
                t12,
                t14,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 215,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[44] = t12;
        $[45] = t14;
        $[46] = t16;
        $[47] = t17;
        $[48] = t18;
    } else {
        t18 = $[48];
    }
    return t18;
};
_s(ImageCarousel, "jHU6G0N/yLNLmALfrXAZwMrsAXE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = ImageCarousel;
function Home() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(114);
    if ($[0] !== "9b50be85f0d2a8b6e45ece538e47e8087b13e8dfae607a7afe87995757fd69ed") {
        for(let $i = 0; $i < 114; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9b50be85f0d2a8b6e45ece538e47e8087b13e8dfae607a7afe87995757fd69ed";
    }
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[1] !== t) {
        const features = [
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hand$2d$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HandHeart$3e$__["HandHeart"],
                link: "/humanitarian-services",
                titleKey: "home.feature1_title",
                descKey: "home.feature1_desc",
                color: "bg-rose-50 text-rose-600"
            },
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
                link: "/friendship-meet",
                titleKey: "home.feature2_title",
                descKey: "home.feature2_desc",
                color: "bg-blue-50 text-blue-600"
            },
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"],
                link: "/news-events",
                titleKey: "home.feature3_title",
                descKey: "home.feature3_desc",
                color: "bg-amber-50 text-amber-600"
            }
        ];
        const recentActivities = [
            {
                dateKey: "home.activity1_date",
                titleKey: "home.activity1_title",
                descKey: "home.activity1_desc",
                image: img1
            },
            {
                dateKey: "home.activity2_date",
                titleKey: "home.activity2_title",
                descKey: "home.activity2_desc",
                image: img2
            },
            {
                dateKey: "home.activity3_date",
                titleKey: "home.activity3_title",
                descKey: "home.activity3_desc",
                image: img3
            }
        ];
        t5 = "bg-neutral-50";
        let t9;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-0 left-0 w-full h-full overflow-hidden z-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute -top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-red-100/50 blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 285,
                        columnNumber: 85
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-[20%] -left-[10%] w-[40%] h-[40%] rounded-full bg-blue-100/50 blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 285,
                        columnNumber: 189
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 285,
                columnNumber: 12
            }, this);
            $[11] = t9;
        } else {
            t9 = $[11];
        }
        let t10;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full mb-10 lg:mb-14",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ImageCarousel, {}, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 292,
                    columnNumber: 52
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 292,
                columnNumber: 13
            }, this);
            $[12] = t10;
        } else {
            t10 = $[12];
        }
        let t11;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                className: "w-4 h-4 text-red-600"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 299,
                columnNumber: 13
            }, this);
            $[13] = t11;
        } else {
            t11 = $[13];
        }
        const t12 = String(t("home.established", "Est. 1995"));
        let t13;
        if ($[14] !== t12) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-neutral-200 shadow-sm mb-6 animate-fade-in",
                children: [
                    t11,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm font-semibold text-neutral-600 tracking-wide uppercase",
                        children: t12
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 307,
                        columnNumber: 155
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 307,
                columnNumber: 13
            }, this);
            $[14] = t12;
            $[15] = t13;
        } else {
            t13 = $[15];
        }
        const t14 = String(t("home.hero_title", "Indian Penpals' League"));
        let t15;
        if ($[16] !== t14) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-extrabold text-neutral-900 leading-tight mb-4 sm:mb-6 tracking-tight animate-slide-up px-2",
                children: t14
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 316,
                columnNumber: 13
            }, this);
            $[16] = t14;
            $[17] = t15;
        } else {
            t15 = $[17];
        }
        let t16;
        if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
            t16 = {
                animationDelay: "0.1s"
            };
            $[18] = t16;
        } else {
            t16 = $[18];
        }
        const t17 = String(t("home.hero_sub", "Love, Friendship & Humanity"));
        let t18;
        if ($[19] !== t17) {
            t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-base sm:text-lg md:text-xl lg:text-2xl text-neutral-600 mb-6 sm:mb-8 leading-relaxed max-w-2xl mx-auto animate-slide-up px-4",
                style: t16,
                children: t17
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 334,
                columnNumber: 13
            }, this);
            $[19] = t17;
            $[20] = t18;
        } else {
            t18 = $[20];
        }
        let t19;
        if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = {
                animationDelay: "0.2s"
            };
            $[21] = t19;
        } else {
            t19 = $[21];
        }
        const t20 = String(t("nav.about", "About Us"));
        let t21;
        if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
            t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 352,
                columnNumber: 13
            }, this);
            $[22] = t21;
        } else {
            t21 = $[22];
        }
        let t22;
        if ($[23] !== t20) {
            t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/about",
                className: "w-full sm:w-auto px-8 py-4 bg-red-700 text-white rounded-full font-bold text-lg shadow-lg shadow-red-700/30 hover:bg-red-800 hover:shadow-red-800/40 hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-2",
                children: [
                    t20,
                    t21
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 359,
                columnNumber: 13
            }, this);
            $[23] = t20;
            $[24] = t22;
        } else {
            t22 = $[24];
        }
        let t23;
        if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
            t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 367,
                columnNumber: 13
            }, this);
            $[25] = t23;
        } else {
            t23 = $[25];
        }
        const t24 = String(t("nav.contact", "Contact"));
        let t25;
        if ($[26] !== t24) {
            t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/contact",
                className: "w-full sm:w-auto px-8 py-4 bg-white text-neutral-700 border border-neutral-200 rounded-full font-bold text-lg hover:bg-neutral-50 hover:border-neutral-300 transition-all duration-300 flex items-center justify-center gap-2",
                children: [
                    t23,
                    t24
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 375,
                columnNumber: 13
            }, this);
            $[26] = t24;
            $[27] = t25;
        } else {
            t25 = $[27];
        }
        let t26;
        if ($[28] !== t22 || $[29] !== t25) {
            t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up",
                style: t19,
                children: [
                    t22,
                    t25
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 383,
                columnNumber: 13
            }, this);
            $[28] = t22;
            $[29] = t25;
            $[30] = t26;
        } else {
            t26 = $[30];
        }
        if ($[31] !== t13 || $[32] !== t15 || $[33] !== t18 || $[34] !== t26) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative pt-4 pb-16 lg:pt-8 lg:pb-28 overflow-hidden",
                children: [
                    t9,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container-custom mx-auto relative z-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center",
                            children: [
                                t10,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full text-center",
                                    children: [
                                        t13,
                                        t15,
                                        t18,
                                        t26
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 391,
                                    columnNumber: 195
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 391,
                            columnNumber: 146
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 391,
                        columnNumber: 90
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 391,
                columnNumber: 12
            }, this);
            $[31] = t13;
            $[32] = t15;
            $[33] = t18;
            $[34] = t26;
            $[35] = t6;
        } else {
            t6 = $[35];
        }
        const t27 = String(t("home.our_activities", "Our Activities"));
        let t28;
        if ($[36] !== t27) {
            t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl lg:text-4xl font-bold text-neutral-900 mb-4",
                children: t27
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 403,
                columnNumber: 13
            }, this);
            $[36] = t27;
            $[37] = t28;
        } else {
            t28 = $[37];
        }
        const t29 = String(t("home.activities_subtitle", "We bring people together through various initiatives aimed at fostering friendship and serving society."));
        let t30;
        if ($[38] !== t29) {
            t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-lg text-neutral-600",
                children: t29
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 412,
                columnNumber: 13
            }, this);
            $[38] = t29;
            $[39] = t30;
        } else {
            t30 = $[39];
        }
        let t31;
        if ($[40] !== t28 || $[41] !== t30) {
            t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center max-w-3xl mx-auto mb-16",
                children: [
                    t28,
                    t30
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 420,
                columnNumber: 13
            }, this);
            $[40] = t28;
            $[41] = t30;
            $[42] = t31;
        } else {
            t31 = $[42];
        }
        const t32 = features.map({
            "Home[features.map()]": (feature, index)=>{
                const Icon = feature.icon;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: feature.link,
                    className: "group relative bg-neutral-50 rounded-2xl p-8 hover:bg-white hover:shadow-xl transition-all duration-300 border border-transparent hover:border-neutral-100",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `w-14 h-14 rounded-xl ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                className: "w-7 h-7"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 430,
                                columnNumber: 372
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 430,
                            columnNumber: 221
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-xl font-bold text-neutral-900 mb-3 group-hover:text-red-700 transition-colors",
                            children: String(t(feature.titleKey))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 430,
                            columnNumber: 406
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-neutral-600 mb-6 leading-relaxed",
                            children: String(t(feature.descKey))
                        }, void 0, false, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 430,
                            columnNumber: 539
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center text-red-700 font-semibold group-hover:gap-2 transition-all",
                            children: [
                                String(t("home.learn_more", "Learn more")),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                    className: "w-4 h-4 ml-1"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 430,
                                    columnNumber: 763
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 430,
                            columnNumber: 624
                        }, this)
                    ]
                }, index, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 430,
                    columnNumber: 16
                }, this);
            }
        }["Home[features.map()]"]);
        let t33;
        if ($[43] !== t32) {
            t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid md:grid-cols-3 gap-8",
                children: t32
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 435,
                columnNumber: 13
            }, this);
            $[43] = t32;
            $[44] = t33;
        } else {
            t33 = $[44];
        }
        if ($[45] !== t31 || $[46] !== t33) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-20 bg-white",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container-custom mx-auto",
                    children: [
                        t31,
                        t33
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 442,
                    columnNumber: 48
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 442,
                columnNumber: 12
            }, this);
            $[45] = t31;
            $[46] = t33;
            $[47] = t7;
        } else {
            t7 = $[47];
        }
        let t34;
        if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
            t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-0 right-0 w-1/3 h-full bg-linear-to-l from-red-900/20 to-transparent"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 451,
                columnNumber: 13
            }, this);
            $[48] = t34;
        } else {
            t34 = $[48];
        }
        let t35;
        if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
            t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute -top-10 -left-10 text-red-700/20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$quote$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Quote$3e$__["Quote"], {
                    className: "w-32 h-32"
                }, void 0, false, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 458,
                    columnNumber: 72
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 458,
                columnNumber: 13
            }, this);
            $[49] = t35;
        } else {
            t35 = $[49];
        }
        const t36 = String(t("home.founder_quote", "Our founder quote"));
        let t37;
        if ($[50] !== t36) {
            t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
                className: "text-3xl lg:text-4xl font-medium leading-tight mb-8 relative z-10",
                children: [
                    "“",
                    t36,
                    "”"
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 466,
                columnNumber: 13
            }, this);
            $[50] = t36;
            $[51] = t37;
        } else {
            t37 = $[51];
        }
        const t38 = String(t("home.founder_name", "Founder"));
        let t39;
        if ($[52] !== t38) {
            t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("cite", {
                className: "text-lg text-red-400 font-style-normal block mb-12",
                children: [
                    "— ",
                    t38
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 475,
                columnNumber: 13
            }, this);
            $[52] = t38;
            $[53] = t39;
        } else {
            t39 = $[53];
        }
        let t40;
        if ($[54] !== t37 || $[55] !== t39) {
            t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lg:w-1/2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative",
                    children: [
                        t35,
                        t37,
                        t39
                    ]
                }, void 0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 483,
                    columnNumber: 39
                }, this)
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 483,
                columnNumber: 13
            }, this);
            $[54] = t37;
            $[55] = t39;
            $[56] = t40;
        } else {
            t40 = $[56];
        }
        const t41 = String(t("home.welcome_title", "Welcome to IPL"));
        let t42;
        if ($[57] !== t41) {
            t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold mb-6",
                children: t41
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 493,
                columnNumber: 13
            }, this);
            $[57] = t41;
            $[58] = t42;
        } else {
            t42 = $[58];
        }
        const t43 = String(t("home.about_intro", "About intro text"));
        let t44;
        if ($[59] !== t43) {
            t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-neutral-300 mb-6 leading-relaxed",
                children: t43
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 502,
                columnNumber: 13
            }, this);
            $[59] = t43;
            $[60] = t44;
        } else {
            t44 = $[60];
        }
        let t45;
        if ($[61] === Symbol.for("react.memo_cache_sentinel")) {
            t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 rounded-lg bg-white/5 border border-white/5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-neutral-400 uppercase tracking-wider mb-1",
                        children: "Registration"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 510,
                        columnNumber: 78
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-mono font-bold text-primary-400",
                        children: "#F23778"
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 510,
                        columnNumber: 164
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 510,
                columnNumber: 13
            }, this);
            $[61] = t45;
        } else {
            t45 = $[61];
        }
        let t46;
        if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
            t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 gap-4 mb-8",
                children: [
                    t45,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 rounded-lg bg-white/5 border border-white/5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-neutral-400 uppercase tracking-wider mb-1",
                                children: "Tax Benefit"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 517,
                                columnNumber: 128
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-mono font-bold text-primary-400",
                                children: "80G Certified"
                            }, void 0, false, {
                                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                lineNumber: 517,
                                columnNumber: 213
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 517,
                        columnNumber: 63
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 517,
                columnNumber: 13
            }, this);
            $[62] = t46;
        } else {
            t46 = $[62];
        }
        const t47 = String(t("home.read_more", "Read full story"));
        let t48;
        if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
            t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                className: "w-5 h-5"
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 525,
                columnNumber: 13
            }, this);
            $[63] = t48;
        } else {
            t48 = $[63];
        }
        let t49;
        if ($[64] !== t47) {
            t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/about",
                className: "inline-flex items-center gap-2 text-white font-semibold hover:text-red-400 transition-colors",
                children: [
                    t47,
                    t48
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 532,
                columnNumber: 13
            }, this);
            $[64] = t47;
            $[65] = t49;
        } else {
            t49 = $[65];
        }
        let t50;
        if ($[66] !== t42 || $[67] !== t44 || $[68] !== t49) {
            t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lg:w-1/2 bg-white/5 backdrop-blur-sm rounded-2xl p-8 lg:p-12 border border-white/10",
                children: [
                    t42,
                    t44,
                    t46,
                    t49
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 540,
                columnNumber: 13
            }, this);
            $[66] = t42;
            $[67] = t44;
            $[68] = t49;
            $[69] = t50;
        } else {
            t50 = $[69];
        }
        if ($[70] !== t40 || $[71] !== t50) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-20 bg-neutral-900 text-white relative overflow-hidden",
                children: [
                    t34,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container-custom mx-auto relative z-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col lg:flex-row items-center gap-16",
                            children: [
                                t40,
                                t50
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 549,
                            columnNumber: 151
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                        lineNumber: 549,
                        columnNumber: 95
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 549,
                columnNumber: 12
            }, this);
            $[70] = t40;
            $[71] = t50;
            $[72] = t8;
        } else {
            t8 = $[72];
        }
        t4 = "py-20 bg-neutral-50";
        t2 = "container-custom mx-auto";
        const t51 = String(t("home.recent_activities", "Recent Activities"));
        let t52;
        if ($[73] !== t51) {
            t52 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl font-bold text-neutral-900 mb-2",
                children: t51
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 561,
                columnNumber: 13
            }, this);
            $[73] = t51;
            $[74] = t52;
        } else {
            t52 = $[74];
        }
        const t53 = String(t("home.recent_subtitle", "Stay updated with our latest events and initiatives"));
        let t54;
        if ($[75] !== t53) {
            t54 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-neutral-600",
                children: t53
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 570,
                columnNumber: 13
            }, this);
            $[75] = t53;
            $[76] = t54;
        } else {
            t54 = $[76];
        }
        let t55;
        if ($[77] !== t52 || $[78] !== t54) {
            t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    t52,
                    t54
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 578,
                columnNumber: 13
            }, this);
            $[77] = t52;
            $[78] = t54;
            $[79] = t55;
        } else {
            t55 = $[79];
        }
        const t56 = String(t("home.view_all", "View All"));
        let t57;
        if ($[80] !== t56) {
            t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/news-events",
                className: "px-6 py-2 bg-white border border-neutral-200 rounded-full text-neutral-700 font-medium hover:bg-neutral-50 hover:border-neutral-300 transition-all",
                children: t56
            }, void 0, false, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 588,
                columnNumber: 13
            }, this);
            $[80] = t56;
            $[81] = t57;
        } else {
            t57 = $[81];
        }
        if ($[82] !== t55 || $[83] !== t57) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row justify-between items-end mb-12 gap-4",
                children: [
                    t55,
                    t57
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 595,
                columnNumber: 12
            }, this);
            $[82] = t55;
            $[83] = t57;
            $[84] = t3;
        } else {
            t3 = $[84];
        }
        t0 = "grid md:grid-cols-3 gap-8";
        t1 = recentActivities.map({
            "Home[recentActivities.map()]": (activity, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-48 overflow-hidden relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors z-10"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 604,
                                    columnNumber: 258
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: activity.image,
                                    alt: String(t(activity.titleKey)),
                                    fill: true,
                                    sizes: "(max-width: 768px) 100vw, 33vw",
                                    className: "object-cover transform group-hover:scale-110 transition-transform duration-700"
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 604,
                                    columnNumber: 356
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute top-4 left-4 z-20 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-red-700 uppercase tracking-wider shadow-sm",
                                    children: String(t(activity.dateKey))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 604,
                                    columnNumber: 563
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 604,
                            columnNumber: 211
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xl font-bold text-neutral-900 mb-3 group-hover:text-red-700 transition-colors line-clamp-2",
                                    children: String(t(activity.titleKey))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 604,
                                    columnNumber: 787
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-neutral-600 text-sm leading-relaxed line-clamp-3 mb-4",
                                    children: String(t(activity.descKey))
                                }, void 0, false, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 604,
                                    columnNumber: 934
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-red-700 text-sm font-semibold flex items-center gap-1 group-hover:gap-2 transition-all",
                                    children: [
                                        "Read more ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                            className: "w-4 h-4"
                                        }, void 0, false, {
                                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                            lineNumber: 604,
                                            columnNumber: 1161
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                                    lineNumber: 604,
                                    columnNumber: 1041
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                            lineNumber: 604,
                            columnNumber: 766
                        }, this)
                    ]
                }, index_0, true, {
                    fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                    lineNumber: 604,
                    columnNumber: 62
                }, this)
        }["Home[recentActivities.map()]"]);
        $[1] = t;
        $[2] = t0;
        $[3] = t1;
        $[4] = t2;
        $[5] = t3;
        $[6] = t4;
        $[7] = t5;
        $[8] = t6;
        $[9] = t7;
        $[10] = t8;
    } else {
        t0 = $[2];
        t1 = $[3];
        t2 = $[4];
        t3 = $[5];
        t4 = $[6];
        t5 = $[7];
        t6 = $[8];
        t7 = $[9];
        t8 = $[10];
    }
    let t9;
    if ($[85] !== t0 || $[86] !== t1) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t0,
            children: t1
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 629,
            columnNumber: 10
        }, this);
        $[85] = t0;
        $[86] = t1;
        $[87] = t9;
    } else {
        t9 = $[87];
    }
    let t10;
    if ($[88] !== t2 || $[89] !== t3 || $[90] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: [
                t3,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 638,
            columnNumber: 11
        }, this);
        $[88] = t2;
        $[89] = t3;
        $[90] = t9;
        $[91] = t10;
    } else {
        t10 = $[91];
    }
    let t11;
    if ($[92] !== t10 || $[93] !== t4) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t4,
            children: t10
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 648,
            columnNumber: 11
        }, this);
        $[92] = t10;
        $[93] = t4;
        $[94] = t11;
    } else {
        t11 = $[94];
    }
    let t12;
    if ($[95] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
            className: "w-12 h-12 text-red-600 mx-auto mb-6 animate-pulse"
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 657,
            columnNumber: 11
        }, this);
        $[95] = t12;
    } else {
        t12 = $[95];
    }
    let t13;
    if ($[96] !== t) {
        t13 = t("home.mother_teresa_quote", "Spread love everywhere you go. Let no one ever come to you without leaving happier.");
        $[96] = t;
        $[97] = t13;
    } else {
        t13 = $[97];
    }
    const t14 = String(t13);
    let t15;
    if ($[98] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
            className: "text-2xl md:text-4xl font-serif italic text-neutral-800 mb-8 leading-tight",
            children: [
                "“",
                t14,
                "”"
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 673,
            columnNumber: 11
        }, this);
        $[98] = t14;
        $[99] = t15;
    } else {
        t15 = $[99];
    }
    let t16;
    if ($[100] !== t) {
        t16 = t("home.mother_teresa", "Mother Teresa");
        $[100] = t;
        $[101] = t16;
    } else {
        t16 = $[101];
    }
    const t17 = String(t16);
    let t18;
    if ($[102] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("cite", {
            className: "text-lg font-semibold text-neutral-500 not-italic",
            children: [
                "— ",
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 690,
            columnNumber: 11
        }, this);
        $[102] = t17;
        $[103] = t18;
    } else {
        t18 = $[103];
    }
    let t19;
    if ($[104] !== t15 || $[105] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-20 bg-white border-t border-neutral-100",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container-custom mx-auto text-center max-w-4xl",
                children: [
                    t12,
                    t15,
                    t18
                ]
            }, void 0, true, {
                fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
                lineNumber: 698,
                columnNumber: 75
            }, this)
        }, void 0, false, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 698,
            columnNumber: 11
        }, this);
        $[104] = t15;
        $[105] = t18;
        $[106] = t19;
    } else {
        t19 = $[106];
    }
    let t20;
    if ($[107] !== t11 || $[108] !== t19 || $[109] !== t5 || $[110] !== t6 || $[111] !== t7 || $[112] !== t8) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t5,
            children: [
                t6,
                t7,
                t8,
                t11,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/IPL-Website-test-main/src/app/page.tsx",
            lineNumber: 707,
            columnNumber: 11
        }, this);
        $[107] = t11;
        $[108] = t19;
        $[109] = t5;
        $[110] = t6;
        $[111] = t7;
        $[112] = t8;
        $[113] = t20;
    } else {
        t20 = $[113];
    }
    return t20;
}
_s1(Home, "vu2xTFBfHkv41zWfADiErp1aWcA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$IPL$2d$Website$2d$test$2d$main$2f$src$2f$contexts$2f$TranslationContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c1 = Home;
var _c, _c1;
__turbopack_context__.k.register(_c, "ImageCarousel");
__turbopack_context__.k.register(_c1, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=IPL-Website-test-main_src_app_page_tsx_59ddf00c._.js.map